#!/usr/bin/env python3
"""Independent decode evidence for the fixed 600-frame HTML study (writes evidence)."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--ffmpeg', required=True)
    parser.add_argument('--ffprobe', required=True)
    args = parser.parse_args()
    project = args.project.resolve(strict=True)
    output = args.output.absolute()
    evidence = output.with_name(output.stem + '.evidence')
    if output.exists() or output.is_symlink():
        parser.error('output must be new')
    evidence.mkdir(exist_ok=False)
    report = {'schema': 'framivra.html-study-quality/1', 'project': str(project),
              'status': 'failed', 'errors': [], 'commands': [], 'png': {},
              'probe': None, 'decoded_video': None, 'decoded_audio': None, 'no_black': None,
              'limitations': ['Not strict QC, human visual acceptance, or Verified Exact.',
                              'Audio hash is normalized stereo 48kHz s16le PCM.']}

    def check(ok, message):
        if not ok:
            report['errors'].append(message)

    def command(name, argv):
        stdout, stderr = evidence / (name + '.stdout'), evidence / (name + '.stderr')
        row = {'argv': argv, 'stdout': str(stdout), 'stderr': str(stderr),
               'exit_code': None, 'duration_seconds': None}
        report['commands'].append(row)
        start = time.monotonic()
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                row['exit_code'] = subprocess.run(argv, stdout=out, stderr=err).returncode
        except Exception as exc:
            row['error'] = str(exc)
        finally:
            row['duration_seconds'] = time.monotonic() - start
        check(row['exit_code'] == 0, name + ' command failed')
        row['stdout_sha256'] = sha(stdout) if stdout.exists() else None
        row['stderr_sha256'] = sha(stderr) if stderr.exists() else None
        return row, stdout, stderr

    try:
        from PIL import Image, __version__ as pillow_version
        report['pillow_version'] = pillow_version
        inventory = []
        paths = sorted((project / 'cache' / 'gfx').rglob('f*.png'))
        check(len(paths) == 600, 'expected exactly 600 cached PNG files')
        check(len({p.parent for p in paths}) == 1, 'expected one gfx frame directory')
        check([p.name for p in paths] == ['f%04d.png' % i for i in range(600)],
              'PNG frame names must cover f0000..f0599 exactly')
        for path in paths:
            row = {'path': str(path.relative_to(project)), 'file_sha256': sha(path)}
            try:
                with Image.open(path) as image:
                    check(image.format == 'PNG', 'not PNG: ' + row['path'])
                    image.load()
                    rgba = image.convert('RGBA')
                    row.update(size=list(rgba.size), rgba_sha256=hashlib.sha256(rgba.tobytes()).hexdigest())
                    check(rgba.size == (1920, 1080), 'wrong PNG size: ' + row['path'])
            except Exception as exc:
                row['error'] = str(exc)
                check(False, 'PNG decode failed: ' + row['path'])
            inventory.append(row)
        report['png'] = {'frames': inventory,
                         'file_aggregate_sha256': digest([[Path(p['path']).name, p['file_sha256']] for p in inventory]),
                         'rgba_aggregate_sha256': digest([[Path(p['path']).name, p.get('rgba_sha256')] for p in inventory])}
    except Exception as exc:
        check(False, 'PNG inventory failed: ' + str(exc))
    final = project / 'out' / 'final.mp4'
    original_hash = sha(final) if final.is_file() else None
    row, out, _ = command('ffprobe', [args.ffprobe, '-v', 'error', '-count_frames',
                          '-show_streams', '-show_format', '-of', 'json', str(final)])
    try:
        probe = json.loads(out.read_text())
        report['probe'] = probe
        video = [s for s in probe['streams'] if s['codec_type'] == 'video']
        audio = [s for s in probe['streams'] if s['codec_type'] == 'audio']
        check(len(video) == 1 and len(audio) == 1, 'expected one video and one audio stream')
        v = video[0]
        check((v['width'], v['height'], int(v['nb_read_frames'])) == (1920, 1080, 600),
              'ffprobe geometry or decoded frame count mismatch')
        check(Fraction(v['avg_frame_rate']) == 30 and Fraction(v['r_frame_rate']) == 30,
              'ffprobe frame rate mismatch')
        check(Fraction(v['time_base']) > 0 and Fraction(v.get('start_time', '0')) == 0,
              'invalid video time base/start')
    except Exception as exc:
        check(False, 'ffprobe validation failed: ' + str(exc))
    common = [args.ffmpeg, '-nostdin', '-v', 'error', '-xerror', '-i', str(final)]
    row, out, _ = command('video-framemd5', common + ['-map', '0:v:0', '-an', '-vsync', '0', '-f', 'framemd5', '-'])
    try:
        text = out.read_text()
        tb = Fraction(re.search(r'^#tb 0:\s*(\S+)', text, re.M).group(1))
        frames = [[x.strip() for x in line.split(',')] for line in text.splitlines()
                  if line.strip() and not line.startswith('#')]
        valid = len(frames) == 600 and all(len(f) == 6 and int(f[0]) == 0 and
                    int(f[1]) == int(f[2]) and int(f[2]) * tb == Fraction(i, 30) and
                    int(f[3]) * tb == Fraction(1, 30) and int(f[4]) > 0 and
                    re.fullmatch('[0-9a-f]{32}', f[5]) for i, f in enumerate(frames))
        report['decoded_video'] = {'framemd5_sha256': sha(out), 'frames': len(frames),
                                   'time_base': str(tb), 'timing_valid': bool(valid)}
        check(valid, 'full video decode frame count/PTS/duration invalid')
    except Exception as exc:
        check(False, 'video framemd5 validation failed: ' + str(exc))
    row, out, _ = command('audio-pcm', common + ['-map', '0:a:0', '-vn', '-ac', '2',
                          '-ar', '48000', '-c:a', 'pcm_s16le', '-f', 's16le', '-'])
    size = out.stat().st_size if out.exists() else 0
    report['decoded_audio'] = {'pcm_sha256': sha(out) if out.exists() else None,
                              'bytes': size, 'sample_frames': size // 4,
                              'format': 's16le', 'sample_rate': 48000, 'channels': 2}
    check(size > 0 and size % 4 == 0 and abs(size // 4 - 960000) <= 1024,
          'decoded audio length outside 20s plus/minus 1024 samples')
    row, _, err = command('blackdetect', [args.ffmpeg, '-nostdin', '-v', 'info', '-xerror',
                              '-i', str(final), '-map', '0:v:0', '-an', '-vf',
                              'blackdetect=d=0:pix_th=0.10:pic_th=0.98', '-f', 'null', '-'])
    if row['exit_code'] == 0:
        report['no_black'] = 'black_start:' not in err.read_text(errors='replace')
        check(report['no_black'], 'blackdetect found black frames')
    check(original_hash is not None and final.is_file() and sha(final) == original_hash,
          'final movie missing or changed during quality checks')
    report['final_sha256'] = original_hash
    report['status'] = 'passed' if not report['errors'] else 'failed'
    with output.open('x') as stream:
        json.dump(report, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
