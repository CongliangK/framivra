# EE-PERF-4 RGB in-place row decoder evaluation

结论：FUNCTIONAL_TARGETED_REGRESSION_PASS / NO_STABLE_NATIVE_WALL_BENEFIT / DO_NOT_INTEGRATE。

候选保留在独立工作树 `/home/liangruochong/.codex/worktrees/electron-codec-row-perf/framivra`，HEAD保持d32310853d6136f3f621a356b0c2718c7fab1a25；无add/commit/reset/checkout/stash/push/安装/联网。原片、实验原HTML、其他工作树只读，未重启整片。该候选不是组合补丁通过，也不构成性能准入。

## 实际修改和分配

唯一生产源码修改 `experiments/gfx_electron_worker/pixel_codec.mjs` 的decode函数，tracked diff +26/-19。唯一新增仓内文件 `experiments/gfx_electron_worker/test_pixel_codec_rows.py`（独立unittest，未改共享test入口）。实际完整补丁 `candidate.diff`；原样候选 `candidate-pixel_codec.mjs` 和 `candidate-test_pixel_codec_rows.py`。

RGB在zlib新生成的decoder私有raw中原位unfilter，保留每行filter byte，前行引用步长stride+1；每行重建后立即全像素RGB展开到最终零初始化RGBA。过滤器0..4、首行/首像素、Paeth原tie顺序、字节模256、Up四lane、每行最后RGB像素不越界、alpha255全部保留。RGBA重建仍使用独立连续decoded输出，预测器逻辑原样；单IDAT直接喂inflate，multi-IDAT仍concat。签名/几何/格式/长度/坏filter/zlib拒绝路径未削弱。decode以外导出和NativePngDecoder类/线程schema逐字节等于d323基线。

1080 RGB每次decode静态移除6,220,800字节的全幅RGB Buffer.alloc；主要显式图像buffer字节由20,737,080降至14,516,280（约30.0%，不含zlib内部/PNG输入/线程拷贝/运行时开销），还避免单IDAT的压缩数据concat。每帧六decode意味着少请求37,324,800字节RGB分配，但这是累计分配量推导，不是RSS峰值实测。未测完整进程树RSS，不能把少分配推成常驻内存节省。

## 正式真实native AB/BA

主控授予串行native窗口后才运行；预备实现者已暂停，未同时测量。基线worker三件从git show d323冻结在本E/baseline-worker，避免引用任何后来改变的工作树。候选源码运行前后SHA强校验不变。沿用受限bwrap：rootRO、private net/PID/dev、仅本E可写、物理独立tmp、X11 socket只读；实际argv和白名单环境见每项 `*.command.json`。SDK SHA433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f，Electron44.7.2/Node24.21.0；没有用系统Node微测冒充真实收益。

同三真实实验原HTML nav_two_pillars/open_source_card/u2_backends，frames30/60/90，1920×1080，PAGES1/b0/electron_native_topng/15s，单render worker+既有单host decoder线程。每侧两轮各18帧、总36帧，每次新profile/output，包含启动；没有清OS/font缓存，不宣称物理盘冷态。所有36frame receipt四witness/六decode/完整语义/error fence通过。

| 页 | base fps | candidate fps | base/candidate wall |
|---|---:|---:|---:|
| nav_two_pillars | 1.991576 | 2.060531 | 1.034623× |
| open_source_card | 1.707445 | 1.707138 | 0.999820× |
| u2_backends | 2.060844 | 2.059970 | 0.999576× |

总wall 9.438139709→9.339189021s，名义1.010595×。AB第一轮0.999957×，BA第二轮1.021118×；open/u2基本持平，不能声称稳定改善。18对PNG字节以及独立Pillow全RGBA字节完全相等。详 `final-native-results.json`、`final-rgba-comparisons.json`、`summary.json`。

observed child user CPU 6.360756→6.234333s；child system 3.527854→3.398930s；Python self user 0.044425→0.031780s、system 0.024535→0.036233s。rusage可能漏非本父链reap的renderer后代，不是完整树CPU；小幅CPU下降也不证明持续收益。没有为保留补丁再挑大样本或反复找收益；未跑450。

## 正确性验证

- 旧42独立stdlib PNG reference全过；新增137例覆盖RGB/RGBA、宽1/2/3/4/5/7/8/9/31/64/65、五filter单种/混合、不同unaligned行尾、单与拆分IDAT、重复decode与PNG输入保持不变；另RGBA每filter精确覆盖alpha0..255，包含预测器tie/回绕。24坏输入覆盖RGB和RGBA短/超长/空payload、首末行坏filter、截断PNG、坏zlib。合计4轻量unittest0.167s rc0，原pixel witness node测试rc0；不是性能基准。
- 真实原HTML fractional/overlay：e1_pain_card f81/82/84 alpha范围[0,0]/[0,31]/[0,94]；llm_post f414/415/417 alpha234/213/170；w_title f0/1/3 alpha范围[0,255]。九对PNG与RGBA零差。额外1080 alpha128fixture f0/1/3每帧5000个alpha128像素、范围[0,128]，三对PNG/RGBA零差。详 `alpha-original-fractional-run2-comparisons.json`。脚本输出路径沿用前棒run2名字，本任务实际只执行一次alpha且成功，没有旧证据冒用。
- 完整旧46+新增2=48项，35.616s，rc0/OK/0skip，包含真实一秒all/QC/Blender、页面exception/Promise/三子节点、decoder线程协议/所有权、alpha/wrong document、kill/timeout清理、cache/readonly/failclosed。仅Electron相关套件，未宣称全仓门通过。测试log中故意伪造failed receipt的拒绝输出属于预期反例。

## 冻结、退出码和交还

- `final_bench.py.exit.json`:0；`alpha.py.exit.json`:0；`regression_final.py.exit.json`:0。所有session亲收结束后交回主控native窗口，无未收尾native后台任务。
- setup/patch/测试生成脚本均0；轻量reference/row/witness/diff-check均0。本候选正式native没有失败尝试；所有raw receipt/profile/output/log均保留。
- 源码冻结SHA pixel_codec `eac4fc4b95f638b5f15a4ad46b0dc52ced31b7a5424dcbdbbb51ef204a92ee9b`；新test `a36a1c8ccfff9f0b577be5d2b1e9283aeb0ee2968c225af54921df6f059e7af6`。nav/gate与基线相等；完整快照 `candidate-source-snapshot.json`、结束 `final-freeze.json`。
- 证据运行器仅本E的 `run.py`、`final_bench.py`、`alpha.py`、`regression_final.py`；这些不是仓内生产文件。没有修改共享导航/Python生产/HTML/阈值/线程协议/见证。

推荐不集成该候选：已有host decode与paint重叠后，少一次RGB中间分配没有带来可复现的端到端wall提升；少分配仍可作为后续内存专项参考。候选和全部证据冻结，停止写入，交fresh审查/归档；不与预备流水线组合，不声称当前慢于CEF的问题已解决。
