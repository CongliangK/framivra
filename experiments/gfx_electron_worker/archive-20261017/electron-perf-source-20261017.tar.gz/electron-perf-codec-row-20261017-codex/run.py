import os,json,subprocess,sys,hashlib
from pathlib import Path
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-codec-row-20261017-codex');T=Path('/home/liangruochong/.codex/worktrees/electron-codec-row-perf/framivra');B=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron/dist/electron')
assert hashlib.sha256(B.read_bytes()).hexdigest()=='433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f'
for p in ['home','tmp']: (E/p).mkdir(exist_ok=True)
env={k:os.environ[k] for k in ['PATH','USER','LOGNAME','LANG'] if k in os.environ};env.update(DISPLAY=':0',XAUTHORITY='/run/user/1000/.mutter-Xwaylandauth.9B7LX3',XDG_SESSION_TYPE='x11',ELECTRON_OZONE_PLATFORM_HINT='x11',VTX_ELECTRON_BIN=str(B),PYTHONPATH=str(T),PYTHONDONTWRITEBYTECODE='1',HOME=str(E/'home'),TMPDIR='/tmp',VTX_GFX_PAGES='1')
script=sys.argv[1]
pins=json.loads((E/'candidate-source-snapshot.json').read_text())['files']
for name,expected in pins.items(): assert hashlib.sha256((T/name).read_bytes()).hexdigest()==expected,name
cmd=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--unshare-pid','--ro-bind','/','/','--proc','/proc','--dev','/dev','--bind',str(E),str(E),'--bind',str(E/'tmp'),'/tmp','--ro-bind','/tmp/.X11-unix','/tmp/.X11-unix','--chdir',str(T),'--','/usr/bin/python3','-B',str(E/script)]
(E/(script+'.command.json')).write_text(json.dumps(dict(argv=cmd,environment=env),indent=2))
with (E/(script+'.log')).open('wb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
for name,expected in pins.items(): assert hashlib.sha256((T/name).read_bytes()).hexdigest()==expected,name
(E/(script+'.exit.json')).write_text(json.dumps({'exit_code':r.returncode}));print(r.returncode);sys.exit(r.returncode)
