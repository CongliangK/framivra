import json,base64,struct,zlib,subprocess,sys,importlib.util
from pathlib import Path
E=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ref',E/'reference_encoder.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
def b64(x):return base64.b64encode(x).decode()
cases=[]
for c in (3,4):
 for w,h in ((1,1),(2,5),(65,7),(127,9)):
  for f in range(5):
   p,r=ref.png_case(w,h,c,[f],1000+w+f+c);cases.append(dict(w=w,h=h,png=b64(p),rgba=b64(r),label=f'reference-{c}-{w}-{h}-{f}'))
 p,r=ref.png_case(192,23,c,[0,1,2,3,4],42);cases.append(dict(w=192,h=23,png=b64(p),rgba=b64(r),label=f'reference-mixed-{c}'))
def encode(w,h,c,pixels,filters):
 raw=bytearray();stride=w*c;ties=0
 for y in range(h):
  f=filters[y%len(filters)];raw.append(f)
  for x in range(stride):
   i=y*stride+x;a=pixels[i-c] if x>=c else 0;b=pixels[i-stride] if y else 0;v=pixels[i-stride-c] if y and x>=c else 0
   pp=a+b-v;dd=[abs(pp-a),abs(pp-b),abs(pp-v)];ties+=int(f==4 and dd.count(min(dd))>1)
   pred=[0,a,b,(a+b)//2,[a,b,v][dd.index(min(dd))]][f];raw.append((pixels[i]-pred)&255)
 header=struct.pack('>IIBBBBB',w,h,8,6 if c==4 else 2,0,0,0)
 return b'\x89PNG\r\n\x1a\n'+ref.chunk(b'IHDR',header)+ref.chunk(b'IDAT',zlib.compress(raw))+ref.chunk(b'IEND',b''),ties
for label,w,h,c,pixels,filters in [('hidden-rgb-and-all-alpha',256,5,4,bytes(v for y in range(5) for x in range(256) for v in (x,255-x,(x*13)%256,x)),[0,1,2,3,4]),('paeth-ties',65,3,4,bytes(65*3*4),[4]),('width-max',3840,2,3,bytes(3840*2*3),[1,4]),('height-max',1,2160,4,bytes(2160*4),[0,1,2,3,4])]:
 p,ties=encode(w,h,c,pixels,filters);r=pixels if c==4 else b''.join(pixels[i:i+3]+b'\xff' for i in range(0,len(pixels),3));cases.append(dict(w=w,h=h,png=b64(p),rgba=b64(r),label=label,paeth_ties=ties))
p,r=ref.png_case(65,7,4,[0,1,2,3,4],51);n=struct.unpack('>I',p[33:37])[0];payload=p[41:41+n]
multi=p[:33]+b''.join(ref.chunk(b'IDAT',payload[i:i+7]) for i in range(0,len(payload),7))+ref.chunk(b'IEND',b'')
cases.append(dict(w=65,h=7,png=b64(multi),rgba=b64(r),label='multiple-IDAT'))
gamma=p[:33]+ref.chunk(b'gAMA',struct.pack('>I',100000))+p[33:];cases.append(dict(w=65,h=7,png=b64(gamma),rgba=b64(r),label='gamma-no-transform'))
bad=[]
def reject(label,png,w=65,h=7):bad.append(dict(label=label,png=b64(png),w=w,h=h))
reject('CRC',p[:42]+bytes([p[42]^1])+p[43:]);reject('truncated',p[:-1]);reject('trailer',p+b'x');reject('geometry',p,66,7);reject('width-over-limit',p,3841,7);reject('zero-width',p,0,7);reject('missing-IEND',p[:-12]);reject('duplicate-IHDR',p[:33]+p[8:33]+p[33:]);reject('unknown-critical',p[:33]+ref.chunk(b'ABCD',b'')+p[33:]);reject('noncontinuous-IDAT',p[:33]+ref.chunk(b'IDAT',payload[:10])+ref.chunk(b'tEXt',b'a\0b')+ref.chunk(b'IDAT',payload[10:])+p[-12:])
for label,pos,value in [('depth',8,16),('palette',9,3),('interlace',12,1)]:
 ih=bytearray(p[16:29]);ih[pos]=value;reject(label,p[:8]+ref.chunk(b'IHDR',ih)+p[33:])
for label,raw in [('invalid-filter',b'\x05'+bytes((65*4+1)*7-1)),('short-payload',b'\0'),('excess-payload',bytes((65*4+1)*7+1))]:reject(label,p[:33]+ref.chunk(b'IDAT',zlib.compress(raw))+p[-12:])
reject('oversize-chunk',p[:33]+struct.pack('>I',0x7fffffff)+b'IDAT'+bytes(4)+p[-12:]);reject('signature',bytes(len(p)))
(E/'unit-cases.json').write_text(json.dumps(dict(positive=cases,negative=bad)))
code="""const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const E=__dirname,addon=require('./native_png.node');
async function test(){const old=await import('./old/pixel_codec.mjs');const cases=JSON.parse(fs.readFileSync(path.join(E,'unit-cases.json')));for(const c of cases.positive){const p=Buffer.from(c.png,'base64'),expected=Buffer.from(c.rgba,'base64');assert.deepEqual(addon.decode(p,c.w,c.h),expected,c.label);assert.deepEqual(old.decodeNativePng(p,c.w,c.h),expected,c.label);assert.throws(()=>addon.decode(p,c.w+1,c.h));}for(const c of cases.negative)assert.throws(()=>addon.decode(Buffer.from(c.png,'base64'),c.w,c.h),c.label);
const report={positive:cases.positive.length,negative:cases.negative.length,exactRGBA:true,versions:process.versions,paeth_ties:cases.positive.filter(c=>c.paeth_ties).map(c=>({label:c.label,ties:c.paeth_ties}))};fs.writeFileSync(path.join(E,'unit-'+process.versions.node+'.json'),JSON.stringify(report,null,2));fs.writeFileSync(path.join(E,'unit-'+process.versions.node+'.maps'),fs.readFileSync('/proc/self/maps'));console.log(JSON.stringify(report));}
module.exports=test;if(require.main===module)test().catch(e=>{console.error(e);process.exitCode=1});
"""
(E/'unit.cjs').write_text(code)
(E/'electron-unit.cjs').write_text("const {app}=require('electron');app.disableHardwareAcceleration();app.whenReady().then(()=>require('./unit.cjs')()).then(()=>app.exit(0)).catch(e=>{console.error(e);app.exit(1)});")
result=subprocess.run(['node',str(E/'unit.cjs')],text=True,capture_output=True);(E/'node-unit.log').write_text(result.stdout+result.stderr);print(result.stdout+result.stderr);assert result.returncode==0
B=__import__('os').environ['VTX_ELECTRON_BIN'];cmd=[B,'--no-sandbox','--disable-gpu','--no-zygote',str(E/'electron-unit.cjs'),f'--user-data-dir={E}/electron-unit-profile'];(E/'electron-unit-command.json').write_text(json.dumps(cmd,indent=2));r=subprocess.run(cmd,text=True,capture_output=True,timeout=30);(E/'electron-unit.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);assert r.returncode==0
