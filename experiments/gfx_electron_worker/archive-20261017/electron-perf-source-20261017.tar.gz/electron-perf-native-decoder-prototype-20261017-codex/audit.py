from pathlib import Path
import json,subprocess,os,hashlib,shutil
E=Path(__file__).resolve().parent
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
s=(T/'experiments/gfx_electron_worker/test_decoder_thread.mjs').read_text()
s=s.replace("data.copy(b,8); return b;", "data.copy(b,8); let crc=0xffffffff;for(const byte of b.subarray(4,8+data.length)){crc^=byte;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}b.writeUInt32BE((crc^0xffffffff)>>>0,8+data.length); return b;")
(E/'new/protocol.mjs').write_text(s)
files=sorted(str(p) for p in E.glob('final-native-round*/*/*/f*.png'))+sorted(str(p) for p in E.glob('alpha-original-fractional-run2/*/*/f*.png'))
assert len(files)==60,len(files)
(E/'real-files.json').write_text(json.dumps(files))
(E/'audit.cjs').write_text("""const fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path'),crypto=require('node:crypto');
module.exports=async()=>{const old=await import('./old/pixel_codec.mjs'),addon=require('./native_png.node');let rows=[];for(const p of JSON.parse(fs.readFileSync(path.join(__dirname,'real-files.json')))){const png=fs.readFileSync(p),w=png.readUInt32BE(16),h=png.readUInt32BE(20),a=old.decodeNativePng(png,w,h),b=addon.decode(png,w,h);assert.deepEqual(a,b);rows.push({file:p,exactRGBA:true,rgba_sha256:crypto.createHash('sha256').update(b).digest('hex')});}fs.writeFileSync(path.join(__dirname,'real-decode-audit.json'),JSON.stringify(rows,null,2));await import('./new/protocol.mjs');console.log('REAL60_AND_PROTOCOL_PASS');};
""")
(E/'audit-app.cjs').write_text("const {app}=require('electron');app.disableHardwareAcceleration();app.whenReady().then(()=>require('./audit.cjs')()).then(()=>app.exit(0)).catch(e=>{console.error(e);app.exit(1)});")
B=os.environ['VTX_ELECTRON_BIN'];cmd=[B,'--no-sandbox','--disable-gpu','--no-zygote',str(E/'audit-app.cjs'),f'--user-data-dir={E}/audit-profile'];(E/'audit-app-command.json').write_text(json.dumps(cmd,indent=2));r=subprocess.run(cmd,text=True,capture_output=True,timeout=30);(E/'audit-app.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);assert r.returncode==0
# Separate negative source copy; never alter the timed source.
d=E/'missing-addon';d.mkdir(exist_ok=True)
s=(E/'new/pixel_codec.mjs').read_text().replace("'../native_png.node'","'../deliberately-missing-native_png.node'")
(d/'pixel_codec.mjs').write_text(s)
(E/'missing-test.mjs').write_text("import assert from 'node:assert/strict';import {NativePngDecoder} from './missing-addon/pixel_codec.mjs';const d=new NativePngDecoder(64,2);d.begin(0,1);try{await assert.rejects(d.decode(Buffer.from('broken'),'baseline'),/decoder_error:.*Cannot find module/);assert.throws(()=>d.assertComplete());}finally{await d.close();}console.log('MISSING_ADDON_FAILCLOSED_PASS');")
r=subprocess.run(['node',str(E/'missing-test.mjs')],text=True,capture_output=True,timeout=15);(E/'missing-test.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);assert r.returncode==0
meta={}
for cmd in [['cc','--version'],['pkg-config','--modversion','libpng'],['pkg-config','--cflags','--libs','libpng'],['ldd',str(E/'native_png.node')],['readelf','-d',str(E/'native_png.node')]]:
 r=subprocess.run(cmd,capture_output=True,text=True);meta[' '.join(cmd)]={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr};assert r.returncode==0
paths=['/usr/include/png.h','/usr/include/pngconf.h','/usr/include/pnglibconf.h','/usr/include/zlib.h','/usr/include/zconf.h','/usr/include/node/node_api.h','/usr/include/node/js_native_api.h','/usr/include/node/node_version.h','/usr/lib64/libpng16.so.16.58.0','/usr/lib64/libz.so.1.3.1.zlib-ng']
meta['file_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
meta['runtime_loaded_libraries']=sorted(set(line.split()[-1] for p in (E/'maps').glob('new-*.maps') for line in p.read_text().splitlines() if 'libpng16.so' in line or 'libz.so' in line))
meta['source_frozen_sha256']={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [E/'native_png.c',E/'native_png.node',*E.glob('old/*.mjs'),*E.glob('new/*.mjs')] if p.name!='protocol.mjs'}
(E/'supply-chain.json').write_text(json.dumps(meta,indent=2))
