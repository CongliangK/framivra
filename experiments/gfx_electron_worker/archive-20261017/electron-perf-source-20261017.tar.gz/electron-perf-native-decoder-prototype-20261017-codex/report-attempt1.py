from pathlib import Path
import hashlib,json,difflib,subprocess
E=Path(__file__).resolve().parent
rows=json.loads((E/'final-native-results.json').read_text());summ=json.loads((E/'final-native-summary.json').read_text());supply=json.loads((E/'supply-chain.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for r in rows:
 for name,digest in r['worker_hashes'].items():assert sha(E/r['backend']/name)==digest
assert (E/'old/navigation_worker.mjs').read_bytes()==(E/'new/navigation_worker.mjs').read_bytes()
assert (E/'old/page_error_gate.mjs').read_bytes()==(E/'new/page_error_gate.mjs').read_bytes()
receipts=[]
for p in E.glob('**/result.json'):
 raw=json.loads(p.read_text());assert raw['failed']==[],p
 assert raw['source_sha256']==sha(raw['page']),p
 for r in raw['frames']:
  assert r['png_decode_count']==6 and r['witnesses']==4 and all(r[k] for k in ['baseline_veto_passed','png_semantics_passed','page_error_fence_passed']),p
  receipts.append({'result':str(p),'frame':r['frame'],'png_decode_count':r['png_decode_count'],'witnesses':r['witnesses']})
assert len(receipts)==60,len(receipts)
(E/'receipt-audit.json').write_text(json.dumps({'frame_receipts':60,'decode_completions':360,'all_source_bound':True,'receipts':receipts},indent=2))
metrics={b:{'wall_s':sum(r['wall_s'] for r in rows if r['backend']==b),'cpu_s':{k:sum(r['cpu_delta_s'][k] for r in rows if r['backend']==b) for k in ['child_user','child_system','self_user','self_system']}} for b in ['old','new']}
metrics['speedup']=metrics['old']['wall_s']/metrics['new']['wall_s'];(E/'aggregate-metrics.json').write_text(json.dumps(metrics,indent=2))
a=(E/'old/pixel_codec.mjs').read_text().splitlines(True);b=(E/'new/pixel_codec.mjs').read_text().splitlines(True);(E/'decoder-only.diff').write_text(''.join(difflib.unified_diff(a,b,fromfile='old/pixel_codec.mjs',tofile='new/pixel_codec.mjs')))
exitfiles=list(E.glob('*exit.json'));ledger={p.name:json.loads(p.read_text()) for p in exitfiles};assert all(v['exit_code']==0 for v in ledger.values());(E/'command-exit-ledger.json').write_text(json.dumps(ledger,indent=2))
report=f'''# EE-PERF-5 极薄 N-API/libpng decoder POC

结论：POC_PIXEL_EQUIVALENCE_PASS / SMALL_SAMPLE_SPEEDUP_{metrics['speedup']:.3f}x / BELOW_HISTORICAL_CEF / DO_NOT_INTEGRATE_PRODUCTION。

仅证据目录原型；冻结 d32310853d6136f3f621a356b0c2718c7fab1a25 树和所有原片/实验副本只读，没有修改 manifest、依赖、缓存身份、仓库、PR或整片。收益约11%，不足以解决性能准入；考虑动态 native 构建/部署/安全维护成本，本次建议停止此方向，不接生产。并非证明所有其他平台都没有收益。

## 实现与安全边界

`native_png.c` 是 C11/N-API8 薄层。仅在原有单host decoder worker内同步 require 和decode；主线程仍执行原paint/encode，线程数不变；worker协议/六独立完整RGBA完成计数未改。`decoder-only.diff` 两侧唯一区别是worker内加载addon并调用C实现。双侧共同增加一次 `/proc/self/maps` 与versions写盘，用于证明真实加载系统库；该一次仪表开销包含在计时内，未声称零开销。

低层libpng read API，仅RGB/RGBA8/noninterlaced及精确几何，RGB补255，RGBA原样。无gamma/ICC/background/premultiply转换；使用Node自有`napi_create_buffer`作为全部RGBA输出。输入64MiB、chunk数4096、chunk边界与全CRC、IHDR唯一、连续IDAT、IEND尾界，3840×2160/8294400像素上限；libpng内部累计分配上限64MiB、chunk cache128。所有warning/error longjmp清理libpng内部内存后转JS throw；Node输出buffer由GC所有，失败不发布。无独立decode fallback；缺addon明确decoder_error。额外严格CRC拒绝旧人工全零CRC fixture合理；协议正例仅在本E把CRC补合法，像素期望/负例不变。

## 正确性与实际Electron加载

系统Node22.23.3仅辅助。真实Electron44.7.2/Node24.21.0 app和真实渲染worker都成功加载相同`.node`。

- 独立Python标准库encoder原42例，覆盖5filters/RGB/RGBA/边界/mixed；另6例 hiddenRGB在alpha0、全部256alpha、Paeth ties、max维度、multiIDAT、gAMA无色变，共48正例，两运行时均与期望及oldJS全RGBA逐字节全等。
- 18坏输入两运行时均throw：CRC/截断/尾数据/错geometry/超限/零width/缺IEND/重复IHDR/未知critical/非连续IDAT/depth16/palette/interlace/非法filter/短或过量解压/超大chunk/错签名。不是fuzz或形式验证。
- 真实Electron对60份真实输出PNG分别执行oldJS与addon完整RGBA decode，逐字节全等。协议alpha/copy所有权/跨代/错frame-op-geometry/短RGBA/额外字段/坏PNG/异常退出测试通过。缺addon单独副本明确失败，无fallback。
- 60个真实帧receipt核验source SHA、四witness、baseline veto、error fence与六decode，合360个完成计数。原40/100ms/15s/Promise三child fence都来自完全相同冻结navigation/gate源码，未削弱。本POC未重跑完整46项目标生产回归，不能据此称生产准入。

## 冷1080真实AB/BA36帧

同三份原实验HTML、frame30/60/90、1920×1080、b0、electron_native_topng、PAGES1、15s，AB后BA各18帧，共36帧。每次独立新profile/output，包含启动，无artifact命中；OS/font缓存未清，不代表物理磁盘冷态。rootRO bwrap、private net/PID/dev/tmp、X11socket RO、仅本E RW；实际argv/白名单env见各command.json，使用XDG_CONFIG_HOME/CACHE_HOME，未重定义HOME。

| 页 | d323 fps | addon fps | ratio |
|---|---:|---:|---:|
'''
for r in summ['results']:report+=f"| {r['page']} | {r['old_fps']:.3f} | {r['new_fps']:.3f} | {r['speedup']:.3f}× |\n"
report+=f'''
合计wall {metrics['old']['wall_s']:.6f}→{metrics['new']['wall_s']:.6f}s，{metrics['speedup']:.6f}×。18对PNG字节与全RGBA全等。CEF 3.186/1.911/3.845fps是前棒历史参照，未新跑CEF；三页仍低于其历史参照。样本有限，没有CI区间/持续450帧/整片结果；不宣称达到性能目标。

CPU分列（36帧，两侧各18帧，observed rusage；不等于完整进程树CPU）：

| 类别 | d323 s | addon s |
|---|---:|---:|
'''
for k in ['child_user','child_system','self_user','self_system']:report+=f"| {k} | {metrics['old']['cpu_s'][k]:.6f} | {metrics['new']['cpu_s'][k]:.6f} |\n"
report+='''
真实透明额外12对：e1_pain_card81/82/84 alpha[0,0]/[0,31]/[0,94]；llm_post414/415/417 [234,234]/[213,213]/[170,170]；w_title0/1/3 [0,255]；128alpha fixture0/1/3各5000个128alpha像素。12对PNG及全RGBA全等，原HTML未改。见alpha-original-fractional-run2-comparisons.json。

## 可复建与供应链证据

构建命令唯一home=`build-command.json`，编译器GCC16.2.1、libpng header1.6.58、zlib header1.3.1.zlib-ng；无安装/联网/sudo。编译-Wall/-Wextra/-Werror rc0；精确compiler/pkg-config/ldd/readelf输出及header SHA见supply-chain.json。`build.log`为空代表无warning，不代表没执行。

'''
for p in ['native_png.c','native_png.node']:report+=f"- {p}: `{sha(E/p)}`\n"
for p in supply['runtime_loaded_libraries']:report+=f"- 实际Electron maps `{p}` SHA256 `{sha(p)}`\n"
report+='''
实际maps保留于maps/new-*.maps和unit-24.21.0.maps，证明真实Electron worker/app加载路径，不仅引用版本字符串。动态系统库可在系统更新时变化；当前binary+库SHA只是POC证据，尚无生产identity/平台构建/装载完整性接线。严禁把本POC输出当current cache，严禁未把binary及动态库绑定身份就宣布生产通过。另平台、缺件部署、供应链更新、持久内存/完整树RSS、crash-fuzz、native安全审计未覆盖。

## 退出码与冻结

build、validation.py、bench.py、alpha.py、audit.py 均亲收rc0，逐命令exit和日志均保留，ledger见command-exit-ledger.json；没有失败重试或被抹掉的失败。unit/协议执行日志含受限环境DBus连接错误，实际exit0且所有断言通过，没有把stderr无内容当通过标准。

源码计时前冻结；bench记录的两侧worker SHA已逐项与当前重新核对。navigation_worker/page_error_gate双侧字节全等。sup​​ply-chain.json保存全部源码/binary SHA；补充protocol测试文件在bench结束后新建，不影响任何计时源码。报告完成后停止写入；不接生产、不重启整片、不建PR。
'''
(E/'REPORT.md').write_text(report)
print(json.dumps(metrics,indent=2));print('REPORT_DONE')
