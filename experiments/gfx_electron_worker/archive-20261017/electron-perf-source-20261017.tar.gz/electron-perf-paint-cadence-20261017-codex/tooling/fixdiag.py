from pathlib import Path
import hashlib,json
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-paint-cadence-20261017-codex')
p=E/'diagnostic.py';s=p.read_text().replace('for rnd in (1,2):','for rnd in (1,):');p.write_text(s)
(E/'diagnostic-freeze.json').write_text(json.dumps({str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['diag-old','diag-new'] for p in (E/d).glob('*.mjs')}|{'diagnostic.py':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
