from pathlib import Path
import hashlib,json,statistics,difflib
from PIL import Image
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-paint-cadence-20261017-codex');r=json.loads((E/'final-native-results.json').read_text());d=json.loads((E/'diagnostic-native-results.json').read_text())
def stats(v):return dict(n=len(v),min=min(v),median=statistics.median(v),max=max(v),mean=statistics.mean(v))
rows=[]
for x in d:
 for f in x['frame_receipts']:
  ev=f['timing'];get=lambda e,op=None:next(z for z in ev if z['event']==e and (op is None or z.get('operation')==op))['t']
  accepted={op:get('accepted',op) for op in ['a','b','aa','bb']}
  # accepted marks are after marker scan; the immediately preceding paint mark is callback entry.
  paint={op:next(ev[i-1]['t'] for i,z in enumerate(ev) if z['event']=='accepted' and z['operation']==op) for op in accepted}
  quiet=next(z for z in ev if z['event']=='quiet_end')
  rows.append(dict(backend=x['backend'],page=x['page'],frame=f['frame'],rate=ev[0],delay40_ms=get('delay40_end')-get('delay40_start'),b_paint_to_aa_request_ms=get('request','aa')-paint['b'],a_to_aa_paint_ms=paint['aa']-paint['a'],b_to_bb_paint_ms=paint['bb']-paint['b'],quiet_wait_ms=get('quiet_end')-get('quiet_start'),quiet_age_ms=quiet['now']-quiet['changed'],b_encode_ms=get('encoded','b')-accepted['b']))
metrics={}
for side in ['old','new']:
 z=[x for x in r if x['backend']==side];q=[x for x in rows if x['backend']==side]
 metrics[side]=dict(wall_s=sum(x['wall_s'] for x in z),cpu_s={k:sum(x['cpu_delta_s'][k] for x in z) for k in z[0]['cpu_delta_s']},paints=sum(f['paints'] for x in z for f in x['frame_receipts']),rejected_paints=sum(f['rejected_paints'] for x in z for f in x['frame_receipts']),actual_getFrameRate=sorted(set(x['rate']['actual'] for x in q)),timing={k:stats([x[k] for x in q]) for k in ['delay40_ms','b_paint_to_aa_request_ms','a_to_aa_paint_ms','b_to_bb_paint_ms','quiet_wait_ms','quiet_age_ms','b_encode_ms']})
metrics['aggregate_speedup']=metrics['old']['wall_s']/metrics['new']['wall_s']
metrics['per_round_speedup']={str(n):{p:next(x['wall_s'] for x in r if x['round']==n and x['page']==p and x['backend']=='old')/next(x['wall_s'] for x in r if x['round']==n and x['page']==p and x['backend']=='new') for p in ['nav_two_pillars','open_source_card','u2_backends']} for n in [1,2]}
alpha=[]
for rnd in [1,2]:
 for side in ['old','new']:
  for page in ['nav_two_pillars','open_source_card','u2_backends']:
   for f in [30,60,90]:
    p=E/f'final-native-round{rnd}'/side/page/f'f{f:04d}.png';a=Image.open(p).convert('RGBA').getchannel('A');alpha.append(dict(round=rnd,backend=side,page=page,frame=f,alpha_extrema=a.getextrema()))
assert all(f['witnesses']==4 and f['png_decode_count']==6 and f['baseline_veto_passed'] and f['png_semantics_passed'] and f['page_error_fence_passed'] for x in r for f in x['frame_receipts'])
(E/'metrics.json').write_text(json.dumps(metrics,indent=2));(E/'timing-rows.json').write_text(json.dumps(rows,indent=2));(E/'alpha-audit.json').write_text(json.dumps(alpha,indent=2))
pins=json.loads((E/'frozen-pins.json').read_text());assert all(hashlib.sha256((E/p).read_bytes()).hexdigest()==h for p,h in pins.items() if p!='source_head' and p!='diagnostic.py')
ledger=[dict(command='setup attempt1',exit_code=1,reason='nonexistent protocol.mjs copy entry; no native job started'),dict(command='setup attempt2',exit_code=0),dict(command='diagnostic single-round comparison index correction',exit_code=0)]+[dict(command=s,**json.loads((E/(s+'.exit.json')).read_text())) for s in ['bench.py','diagnostic.py']]
(E/'command-exit-ledger.json').write_text(json.dumps(ledger,indent=2))
(E/'diagnostic.diff').write_text(''.join(difflib.unified_diff((E/'old/navigation_worker.mjs').read_text().splitlines(True),(E/'diag-old/navigation_worker.mjs').read_text().splitlines(True),fromfile='old',tofile='diag-old')))
text='''# EE-PERF-6 OSR paint cadence experiment

Decision: NO_STABLE_MATERIAL_GAIN / STOP_DIRECTION. This is evidence-only POC; no repository or production integration. Frozen d32310853d6136f3f621a356b0c2718c7fab1a25 source remains read-only and clean. No full-film restart, PR change, dependency install, network or git writes.

## Method and source

`old/` is an exact copy of frozen worker, codec, page_error_gate. `new/` changes only `wc.setFrameRate(60)` to `wc.setFrameRate(240)`; candidate.diff and frozen-pins.json provide exact diff/hashes. All four nonce A/B/A/B witnesses, baseline veto, six native encodes and six full RGBA decoder operations, page/Promise/three-child fences, 40/100ms and 15s remain untouched. Timeline fps remains30, original HTML/fonts/styles/audio untouched. max_inflight1, one fresh BrowserWindow/document per frame, one host decoder thread.

SDK SHA256 433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f. rootRO bwrap private net/PID/dev/physical tmp, host X11 socket RO; only this E writable. HOME not overridden; XDG_CONFIG_HOME/CACHE_HOME under E. DISPLAY=:0, verified XAUTHORITY. Exact argv/env in *.command.json. All jobs personally reaped exit0; setup first copy attempt failed before native because nonexistent protocol.mjs was listed, corrected to actual three modules. command-exit-ledger.json retains it.

## Native uninstrumented AB/BA36

Three original experiment HTML pages nav_two_pillars/open_source_card/u2_backends, frames30/60/90, 1920x1080/b0/PAGES1/native_topng/15s. Each batch new profile/output, no artifact reuse; includes startup, OS/font caches not flushed. Two rounds old-new then new-old, 36 frames total. final-native-results.json retains raw CPU, adapter and frame receipts. final-rgba-comparisons.json:18 pairs PNG bytes and independently Pillow decoded full RGBA exactly equal. All36 output alpha extrema [255,255] (alpha-audit.json); fractional/zero alpha is NOT covered here.

| page |60fps|240fps|speedup|
|---|---:|---:|---:|
'''
for x in json.loads((E/'final-native-summary.json').read_text())['results']:text+=f"|{x['page']}|{x['old_fps']:.4f}|{x['new_fps']:.4f}|{x['speedup']:.4f}x|\n"
text+=f"\nAggregate wall {metrics['old']['wall_s']:.6f}→{metrics['new']['wall_s']:.6f}s = {metrics['aggregate_speedup']:.4f}x. Per-round speedup {json.dumps(metrics['per_round_speedup'])}. open second round is essentially equal; u2 no gain. Stop without120/extra-alpha/46 regression because this condition did not earn further adoption validation. Historical CEF is not fresh synchronous control.\n\n"
for side in ['old','new']:text+=f"{side}: CPU observed seconds {metrics[side]['cpu_s']}; paints {metrics[side]['paints']}, rejected {metrics[side]['rejected_paints']}. These resource.getrusage CHILDREN values may miss renderer descendants reaped elsewhere, not complete process-tree CPU.\n\n"
text+='''## Separate instrumented cadence/timing diagnostic

Same source and conditions in diag-old/diag-new, only in-memory performance.now marks and receipt fields added symmetrically; diagnostic.diff + diagnostic-freeze.json disclose it. Single AB18 additional frames; diagnostic-native-results.json raw receipt marks; timing-rows.json derived per frame; metrics.json min/median/max/mean. Diagnostic wall is not used as final native throughput. getFrameRate is read from actual WebContents after setting, not inferred from configuration.

'''
for side in ['old','new']:
 text+=f"{side}: declared {60 if side=='old' else 240}; actual getFrameRate {metrics[side]['actual_getFrameRate']}.\n\n"
 for k,v in metrics[side]['timing'].items():text+=f"- {k}: min/median/max {v['min']:.3f}/{v['median']:.3f}/{v['max']:.3f}\n"
 text+='\n'
text+='''Quiet age is wall-clock elapsed since the actual last resource-change event; quiet wait may be zero when already quiet >=100ms. Explicit delay remains original setTimeout(40). High resolution actual setTimeout duration can fluctuate near40; all B accepted-paint callback→AA request intervals exceed40, with same-phase witnesses farther apart. No threshold/code change or timing reduction was used to produce speedup. Accepted paint timestamp uses callback entry immediately preceding successful nonce scan, avoiding PNG encoding being mislabeled paint time. Main bench did not contain these marks.

## Scheduling hypotheses (analysis only)

The current delay40 begins after B synchronous image.toPNG, decoder submission and witness promise unwinding. Starting an absolute deadline at the actual nonce-attested B paint could count these host costs while still requiring AA request >= B paint+40ms. The measured B encode durations bound a possible savings, not proof of safe equivalence. B timestamp must be tied to the successful token/operation and callback, never a rejected paint; an absolute wait must recheck monotonic time to avoid early setTimeout. It would preserve nominal B→AA40ms but shorten the existing effective observation interval, so it changes current practical stability coverage and needs explicit main-controller semantic approval and independent adversarial tests; NOT implemented here.

capturePage() default stayHidden=false can treat a hidden page as visible during capture. Existing per-frame baseline call may alter capturer/visibility scheduling and impose cost; it may also affect interactions with overlapping hidden windows in the rejected double-document experiment. That is a plausible hypothesis, not established cause or verified alpha fix. Suggest an independent E-only stayHidden=true experiment only after controller authorization, retaining baseline solely veto and all6 encodes/full decodes/4nonce/error gates. This experiment does not change capturePage or attribute its effects to frameRate.

## Limits and closeout

Small36-frame native sample plus separate18-frame diagnostics, no full-film throughput, no new fractional-alpha or full46 regression, no complete-tree CPU/RSS. Browser nominal OSR rate does not prove events arrive at that rate (invalidations, hidden OSR, compositor/CPU dominate); actual getFrameRate240 is accepted but no reliable corresponding throughput benefit. Raw rejected paints remain identical counts; no fail-open route. No source changes during either job. All native jobs stopped and window released. Original repository source hash checks unchanged.
'''
(E/'REPORT.md').write_text(text)
print(json.dumps(metrics,indent=2))
