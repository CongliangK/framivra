from pathlib import Path
import shutil,hashlib,json,difflib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-paint-cadence-20261017-codex')
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
P=E.parent/'electron-perf-pipeline-20261017-codex'
E.mkdir(exist_ok=True);(E/'tmp').mkdir(exist_ok=True)
src=T/'experiments/gfx_electron_worker';s=(src/'navigation_worker.mjs').read_text()
for side,rate in [('old',60),('new',240),('diag-old',60),('diag-new',240)]:
 d=E/side;d.mkdir(exist_ok=True)
 for name in ['navigation_worker.mjs','pixel_codec.mjs','page_error_gate.mjs']:shutil.copy2(src/name,d/name)
 x=s.replace('wc.setFrameRate(60);',f'wc.setFrameRate({rate});')
 if side.startswith('diag'):
  x=x.replace('let errorGate;', 'let errorGate; const timing=[]; const mark=(event,detail={})=>timing.push({event,t:performance.now(),...detail}); mark("rate",{declared:'+str(rate)+',actual:wc.getFrameRate()});')
  x=x.replace('paints++;','paints++; mark("paint",{operation:active?.operation||null});')
  x=x.replace('const png = image.toPNG();','mark("accepted",{operation:active.operation}); const png = image.toPNG(); mark("encoded",{operation:active.operation});')
  x=x.replace('const token = crypto.randomBytes(48);','mark("request",{operation}); const token = crypto.randomBytes(48);')
  x=x.replace("await deadline((async () => {\n      while", "mark('quiet_start',{changed:ses._vtxChanged,now:Date.now()}); await deadline((async () => {\n      while")
  x=x.replace("})(), timeoutMs, 'resource_quiet');", "})(), timeoutMs, 'resource_quiet'); mark('quiet_end',{changed:ses._vtxChanged,now:Date.now()});")
  x=x.replace('await delay(40);',"mark('delay40_start'); await delay(40); mark('delay40_end');")
  x=x.replace('return {frame:f,generation,url:expectedUrl,paints,','return {timing,frame:f,generation,url:expectedUrl,paints,')
 (d/'navigation_worker.mjs').write_text(x)
(E/'candidate.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),(E/'new/navigation_worker.mjs').read_text().splitlines(True),fromfile='d323/navigation_worker.mjs',tofile='new/navigation_worker.mjs')))
r=(E.parent/'electron-perf-native-decoder-prototype-20261017-codex/run.py').read_text();(E/'run.py').write_text(r)
b=(P/'final_bench.py').read_text().replace("WORKERS={'old':ROOT/'alpha-electron-perf-20261017/experiments/gfx_electron_worker','new':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker'}", "WORKERS={'old':E/'old','new':E/'new'}")
(E/'bench.py').write_text(b)
d=b.replace("WORKERS={'old':E/'old','new':E/'new'}", "WORKERS={'old':E/'diag-old','new':E/'diag-new'}").replace("(('old','new'),('new','old'))","(('old','new'),)").replace("final-native", "diagnostic-native").replace("final-rgba", "diagnostic-rgba")
(E/'diagnostic.py').write_text(d)
pins={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for p in E.rglob('*') if p.is_file()}
pins['source_head']='d32310853d6136f3f621a356b0c2718c7fab1a25'
(E/'frozen-pins.json').write_text(json.dumps(pins,indent=2))
print(E)
