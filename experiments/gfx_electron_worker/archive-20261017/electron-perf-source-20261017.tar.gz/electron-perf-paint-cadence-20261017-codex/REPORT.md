# EE-PERF-6 OSR paint cadence experiment

Decision: NO_STABLE_MATERIAL_GAIN / STOP_DIRECTION. This is evidence-only POC; no repository or production integration. Frozen d32310853d6136f3f621a356b0c2718c7fab1a25 source remains read-only and clean. No full-film restart, PR change, dependency install, network or git writes.

## Method and source

`old/` is an exact copy of frozen worker, codec, page_error_gate. `new/` changes only `wc.setFrameRate(60)` to `wc.setFrameRate(240)`; candidate.diff and frozen-pins.json provide exact diff/hashes. All four nonce A/B/A/B witnesses, baseline veto, six native encodes and six full RGBA decoder operations, page/Promise/three-child fences, 40/100ms and 15s remain untouched. Timeline fps remains30, original HTML/fonts/styles/audio untouched. max_inflight1, one fresh BrowserWindow/document per frame, one host decoder thread.

SDK SHA256 433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f. rootRO bwrap private net/PID/dev/physical tmp, host X11 socket RO; only this E writable. HOME not overridden; XDG_CONFIG_HOME/CACHE_HOME under E. DISPLAY=:0, verified XAUTHORITY. Exact argv/env in *.command.json. All jobs personally reaped exit0; setup first copy attempt failed before native because nonexistent protocol.mjs was listed, corrected to actual three modules. command-exit-ledger.json retains it.

## Native uninstrumented AB/BA36

Three original experiment HTML pages nav_two_pillars/open_source_card/u2_backends, frames30/60/90, 1920x1080/b0/PAGES1/native_topng/15s. Each batch new profile/output, no artifact reuse; includes startup, OS/font caches not flushed. Two rounds old-new then new-old, 36 frames total. final-native-results.json retains raw CPU, adapter and frame receipts. final-rgba-comparisons.json:18 pairs PNG bytes and independently Pillow decoded full RGBA exactly equal. All36 output alpha extrema [255,255] (alpha-audit.json); fractional/zero alpha is NOT covered here.

| page |60fps|240fps|speedup|
|---|---:|---:|---:|
|nav_two_pillars|1.9274|2.0615|1.0696x|
|open_source_card|1.6832|1.7073|1.0143x|
|u2_backends|2.0971|2.0963|0.9996x|

Aggregate wall 9.538651→9.286796s = 1.0271x. Per-round speedup {"1": {"nav_two_pillars": 1.1030737436705946, "open_source_card": 1.0289343360741094, "u2_backends": 0.9995834917847201}, "2": {"nav_two_pillars": 1.0350139743495368, "open_source_card": 1.000111087740924, "u2_backends": 0.9996468024820423}}. open second round is essentially equal; u2 no gain. Stop without120/extra-alpha/46 regression because this condition did not earn further adoption validation. Historical CEF is not fresh synchronous control.

old: CPU observed seconds {'child_user': 6.432494, 'child_system': 4.0147129999999995, 'self_user': 0.034803999999999974, 'self_system': 0.032799999999999996}; paints 220, rejected 72. These resource.getrusage CHILDREN values may miss renderer descendants reaped elsewhere, not complete process-tree CPU.

new: CPU observed seconds {'child_user': 6.232296, 'child_system': 3.922302, 'self_user': 0.03447900000000004, 'self_system': 0.03205399999999999}; paints 226, rejected 72. These resource.getrusage CHILDREN values may miss renderer descendants reaped elsewhere, not complete process-tree CPU.

## Separate instrumented cadence/timing diagnostic

Same source and conditions in diag-old/diag-new, only in-memory performance.now marks and receipt fields added symmetrically; diagnostic.diff + diagnostic-freeze.json disclose it. Single AB18 additional frames; diagnostic-native-results.json raw receipt marks; timing-rows.json derived per frame; metrics.json min/median/max/mean. Diagnostic wall is not used as final native throughput. getFrameRate is read from actual WebContents after setting, not inferred from configuration.

old: declared 60; actual getFrameRate [60].

- delay40_ms: min/median/max 39.422/39.959/40.766
- b_paint_to_aa_request_ms: min/median/max 53.841/57.330/67.948
- a_to_aa_paint_ms: min/median/max 87.055/95.406/120.675
- b_to_bb_paint_ms: min/median/max 83.398/90.794/128.699
- quiet_wait_ms: min/median/max 0.022/80.607/102.692
- quiet_age_ms: min/median/max 100.000/104.000/134.000
- b_encode_ms: min/median/max 11.294/14.308/24.917

new: declared 240; actual getFrameRate [240].

- delay40_ms: min/median/max 39.521/40.139/40.884
- b_paint_to_aa_request_ms: min/median/max 54.729/57.413/69.091
- a_to_aa_paint_ms: min/median/max 91.123/95.918/117.422
- b_to_bb_paint_ms: min/median/max 87.535/93.518/112.248
- quiet_wait_ms: min/median/max 0.022/80.660/101.049
- quiet_age_ms: min/median/max 101.000/116.000/136.000
- b_encode_ms: min/median/max 11.483/13.988/25.594

Quiet age is wall-clock elapsed since the actual last resource-change event; quiet wait may be zero when already quiet >=100ms. Explicit delay remains original setTimeout(40). High resolution actual setTimeout duration can fluctuate near40; all B accepted-paint callback→AA request intervals exceed40, with same-phase witnesses farther apart. No threshold/code change or timing reduction was used to produce speedup. Accepted paint timestamp uses callback entry immediately preceding successful nonce scan, avoiding PNG encoding being mislabeled paint time. Main bench did not contain these marks.

## Scheduling hypotheses (analysis only)

The current delay40 begins after B synchronous image.toPNG, decoder submission and witness promise unwinding. Starting an absolute deadline at the actual nonce-attested B paint could count these host costs while still requiring AA request >= B paint+40ms. The measured B encode durations bound a possible savings, not proof of safe equivalence. B timestamp must be tied to the successful token/operation and callback, never a rejected paint; an absolute wait must recheck monotonic time to avoid early setTimeout. It would preserve nominal B→AA40ms but shorten the existing effective observation interval, so it changes current practical stability coverage and needs explicit main-controller semantic approval and independent adversarial tests; NOT implemented here.

capturePage() default stayHidden=false can treat a hidden page as visible during capture. Existing per-frame baseline call may alter capturer/visibility scheduling and impose cost; it may also affect interactions with overlapping hidden windows in the rejected double-document experiment. That is a plausible hypothesis, not established cause or verified alpha fix. Suggest an independent E-only stayHidden=true experiment only after controller authorization, retaining baseline solely veto and all6 encodes/full decodes/4nonce/error gates. This experiment does not change capturePage or attribute its effects to frameRate.

## Limits and closeout

Small36-frame native sample plus separate18-frame diagnostics, no full-film throughput, no new fractional-alpha or full46 regression, no complete-tree CPU/RSS. Browser nominal OSR rate does not prove events arrive at that rate (invalidations, hidden OSR, compositor/CPU dominate); actual getFrameRate240 is accepted but no reliable corresponding throughput benefit. Raw rejected paints remain identical counts; no fail-open route. No source changes during either job. All native jobs stopped and window released. Original repository source hash checks unchanged.
