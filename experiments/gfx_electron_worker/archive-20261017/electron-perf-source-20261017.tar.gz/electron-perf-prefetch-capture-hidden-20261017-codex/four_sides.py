import os,json,time,hashlib,importlib,sys,argparse
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
from vtx import gfx_electron as base_adapter
from vtx import _early_adapter as early_adapter
E=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--repeats',type=int,default=12);args=parser.parse_args()
assert 1<=args.repeats<=40
source_pins=json.loads((E/'source-pins.json').read_text())['files']
def verify_pins():
 for rel,digest in source_pins.items():assert hashlib.sha256((E/rel).read_bytes()).hexdigest()==digest,rel
verify_pins()
ctx=SimpleNamespace(root=E/'context',cache=E/'context/cache',out=E/'context/out');ctx.root.mkdir(exist_ok=True)
ARMS=['base_default','base_stay_hidden','early_default','early_stay_hidden']
rows=[];comparisons=[]
for case,repeats in [('navigation_fixture',args.repeats),('visibility_sensitive',2)]:
 page=E/'inputs'/(case+'.html');source_sha=hashlib.sha256(page.read_bytes()).hexdigest()
 for repeat in range(repeats):
  # Alternating forward/reverse order avoids always placing stayHidden last.
  order=ARMS if repeat%2==0 else list(reversed(ARMS))
  for arm in order:
   adapter=base_adapter if arm.startswith('base_') else early_adapter
   adapter.WORKER_DIR=E/'workers'/arm;out=E/'runs'/case/str(repeat)/arm
   before=time.monotonic();st=adapter.render_page(page,out,4,width=192,height=96,frames=[3,0,2],ctx=ctx,timeout_s=15,mode='b0',output='electron_native_topng')
   raw_path=Path(st['evidence_dir'])/'result.json';raw=json.loads(raw_path.read_text()) if raw_path.exists() else None
   row=dict(case=case,repeat=repeat,arm=arm,adapter=st,wall_s=time.monotonic()-before,raw_result=raw,source_sha256=source_sha)
   rows.append(row);(E/'results.json').write_text(json.dumps(rows,indent=2));print(case,repeat,arm,st['exit_code'],st['failed'],flush=True)
   assert hashlib.sha256(page.read_bytes()).hexdigest()==source_sha
  for arm in ARMS:
   for frame in [3,0,2]:
    paths=[E/'runs'/case/str(repeat)/a/f'f{frame:04d}.png' for a in ['base_default',arm]]
    exists=[p.exists() for p in paths]
    r=dict(case=case,repeat=repeat,arm=arm,frame=frame,outputs_exist=exists)
    if all(exists):
     decoded=[Image.open(p).convert('RGBA') for p in paths];rgba=[im.tobytes() for im in decoded]
     r.update(png_bytes_equal=paths[0].read_bytes()==paths[1].read_bytes(),rgba_equal=rgba[0]==rgba[1],different_rgba_channels=sum(x!=y for x,y in zip(*rgba)),alpha_extrema=[im.getchannel('A').getextrema() for im in decoded],png_sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths])
    comparisons.append(r)
  (E/'comparisons.json').write_text(json.dumps(comparisons,indent=2))
verify_pins()
summary={}
for r in rows:
 key=r['case']+'/'+r['arm'];z=summary.setdefault(key,dict(runs=0,failed=[],exit_codes=[],published=0));z['runs']+=1;z['failed']+=r['adapter']['failed'];z['exit_codes'].append(r['adapter']['exit_code']);z['published']+=r['adapter']['rendered']
(E/'summary.json').write_text(json.dumps({'arms':summary,'source_pins_unchanged':True,'note':'Experiment rc0 means all observations were collected, NOT that every arm passed. Native failures and genuine pixel differences remain in results/comparisons.'},indent=2))
print('OBSERVATIONS_COMPLETE',flush=True)
