from pathlib import Path
import json,hashlib,collections
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-capture-hidden-20261017-codex')
rows=json.loads((E/'results.json').read_text());pairs=json.loads((E/'comparisons.json').read_text())
observations={};failure_analysis=[]
for p in E.glob('runs/*/*/*/visibility-f*.json'):
 arm=p.parent.name;case=p.parents[2].name
 for r in json.loads(p.read_text()):
  key=case+'/'+arm+'/'+r['stage'];count=observations.setdefault(key,collections.Counter());count[json.dumps({k:r.get(k) for k in ['frame_visibility','being_captured','window_visible','observation_error']},sort_keys=True)]+=1
for p in E.glob('runs/*/*/*/diag-*-baseline.bin'):
 a=p.read_bytes();b=p.with_name(p.name.replace('baseline','expected')).read_bytes();ids=[i//4 for i in range(0,len(a),4) if a[i:i+4]!=b[i:i+4]]
 failure_analysis.append({'path':str(p.relative_to(E)),'differing_pixels':len(ids),'bbox':[min(j%192 for j in ids),min(j//192 for j in ids),max(j%192 for j in ids),max(j//192 for j in ids)],'first_8_differences':[[j%192,j//192,list(a[j*4:j*4+4]),list(b[j*4:j*4+4])] for j in ids[:8]],'baseline_rgba_sha256':hashlib.sha256(a).hexdigest(),'witness_rgba_sha256':hashlib.sha256(b).hexdigest()})
(E/'host-state-summary.json').write_text(json.dumps({k:dict(v) for k,v in observations.items()},indent=2))
(E/'failure-analysis.json').write_text(json.dumps(failure_analysis,indent=2))
assert len(failure_analysis)==11 and all(r['differing_pixels']==18021 for r in failure_analysis)
assert all(p.get('rgba_equal') is not False and p.get('png_bytes_equal') is not False for p in pairs)
source=json.loads((E/'source-pins.json').read_text());assert all(hashlib.sha256((E/p).read_bytes()).hexdigest()==h for p,h in source['files'].items())
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  argv=(p/'cmdline').read_bytes().split(b'\0')
  if 'electron' in Path(argv[0].decode(errors='replace')).name and any(str(E).encode() in a for a in argv):active.append(int(p.name))
 except (OSError,IndexError):pass
cleanup={'matching_native_pids':active,'remaining_runtime_profiles':[str(p.relative_to(E)) for p in E.glob('context/cache/tmp/*')],'source_pins_unchanged':True}
assert not active and not cleanup['remaining_runtime_profiles']
(E/'cleanup-check.json').write_text(json.dumps(cleanup,indent=2))
report='''# EE-PERF-3-HIDDEN — stayHidden is NOT a sufficient fix

Task: read-only analysis and new-E-only causal experiment. No repository or old evidence directory was changed; archived worktree was not restored. Native timing window was explicitly granted by controller, the single group was collected with exit 0, then released. No performance expansion, 450, full film, or PR action.

## Local SDK fact and falsifiable hypothesis

Exact SDK: `/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron`. `sdk-evidence.json` preserves local `electron.d.ts` excerpts/full SHA, package version and binary SHA. Binary `433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f` was verified before execution.

The type docs at 18199–18206 and Opts at 23439–23447 state capturePage default stayHidden=false; a hidden window's page is considered visible while capturer count is nonzero, and stayHidden=true keeps it hidden. Another documented qualifier at 6700–6705: paintWhenInitiallyHidden defaults true, and show:false does not establish hidden document.visibilityState on first load. We did not change paintWhenInitiallyHidden.

Hypothesis: default baseline capture could alter native capturer/visibility state during another OSR document's creation/navigation, influencing later nonce-paint alpha compositing. This was plausible API-grounded causation, not a known root cause. The four-arm experiment tests whether changing only capturePage's stayHidden option is sufficient. **It is not.**

## Four sides and preserved gates

Within each base/early pair the only configuration delta is `wc.capturePage()` versus `wc.capturePage(undefined, {stayHidden:true})`; byte comparison verified this before execution. Base is d323-equivalent serial decoder-thread runtime, early is the rejected one-document-ahead source. Both carry identical host state sampling and failure-only native byte dumps. Full source/dependency copies are under runtime/ and workers/, with 72 input/source SHA pins validated before/after. Original navigation fixture is an unchanged copy.

No page source/listener injection for observations. Public host getters wc.mainFrame.visibilityState, wc.isBeingCaptured(), win.isVisible() are sampled in memory at window creation, paint callbacks, witness requests, just before baseline call, synchronously after initiating the capture and after awaiting it, and close. Samples are written only on frame close. No extra await is inserted. Transient native states between callbacks may be missed; these are host observations, not continuous compositor tracing.

All four nonce A/B/A/B witnesses, six native PNG encodes and six full RGBA decodes, baseline solely veto, document/error/Promise/child fences, 40ms/100ms/15s, and failclosed output binding remain. No baseline pixels recover output. Each worker run has new profile/output; bwrap rootRO/private PID+net+dev/physical tmp/X11 socket RO and only this new E writable. Actual argv/environment are saved. HOME was not repurposed.

## Actual result

192×96 unchanged fractional-alpha navigation fixture, frames3/0/2, 12 repetitions per side (36 requested frames each), alternating forward/reverse arm order:

| Arm | Native runs rc1 | Failed frames | Published frames |
|---|---:|---:|---:|
| base default | 0/12 | 0/36 | 36 |
| base stayHidden | 0/12 | 0/36 | 36 |
| early default | 7/12 | 7/36, all f0 | 29 |
| early stayHidden | 4/12 | 4/36, all f0 | 32 |

All eleven are the same true alpha veto signature: 18,021 differing pixels, bbox x0..191/y1..94; representative native baseline RGBA [199,100,40,128] versus witness-derived RGBA [227,177,147,255], with alpha0 background becoming opaque white. The early-stayHidden failures occur at repetitions 4,7,9,11. `failure-analysis.json` pins each full byte buffer; original baseline PNG/ar/br/clean/expected dumps remain next to every failing run. White-compositing-like output is observed; its native root cause remains unproven. The finite failure-count difference 7 vs4 is not a reliable rate/performance claim and does not make the option acceptable.

The separate visibility-sensitive NEW fixture encodes document visibility plus visibilitychange count into pixels; two repetitions/side, six frames/side, all four arms rc0/no failure. Every available published arm output was compared to its round's base-default PNG and full RGBA: 157 comparisons including 42 base self-comparisons; **115 non-self comparisons have zero PNG-byte and full-RGBA differences**. Eleven missing outputs remain failures and are not substituted. The absence of differences for the visibility-sensitive fixture is limited to current paintWhenInitiallyHidden=true behavior; do not generalize to arbitrary visibility-dependent pages.

## Host visibility/capture observations

Four sides consistently begin with host main-frame state hidden at window creation, but are visible by baseline_before_call. At baseline_after_call_before_await, isBeingCaptured=true; by baseline_resolved it is false. Frame visibility remains visible across baseline and witness samples; window-visible remains false. Thus a simple observed JavaScript visibility-state flip caused by the baseline is **not supported** in this setup. stayHidden does not remove capturer-count activity and did not prevent alpha failure. Native/compositor effects that this sparse public state sampling cannot observe remain UNKNOWN. `host-state-summary.json` and every per-frame visibility JSON preserve the raw facts.

## Exit, cleanup and limits

One controller-authorized experiment group: run.py --repeats=12, outer exit0; 56 native worker invocations with each actual exit preserved in results/summary. Outer rc0 means all observations collected, not candidate success. Initial syntax checks and single-factor/pins checks exit0. No source changed during execution; post-run pins passed. cleanup-check.json shows zero matching live native PIDs and zero runtime profiles. Native window was explicitly released after collecting exit.

This rejects stayHidden as a sufficient correction for early prefetch. Do not change production, reuse the early exploratory speedups as qualified performance, or enlarge this direction to formal perf/450/full film based on this group. All failed states remain. Work stops after this report and final SHA seal.
'''
(E/'REPORT.md').write_text(report)
(E/'analyze.py').write_bytes(Path('/tmp/ee-hidden-report.py').read_bytes())
manifest={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for p in E.rglob('*') if p.is_file() and (p.suffix in ['.py','.mjs'] or p.name in ['REPORT.md','source-pins.json','sdk-evidence.json','summary.json','failure-analysis.json','host-state-summary.json','cleanup-check.json','four_sides.command.json','four_sides.exit.json'])}
(E/'final-sha256.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'report_sha256':hashlib.sha256((E/'REPORT.md').read_bytes()).hexdigest(),'final_manifest_sha256':hashlib.sha256((E/'final-sha256.json').read_bytes()).hexdigest(),'outer_exit':json.loads((E/'four_sides.exit.json').read_text()),'cleanup':cleanup,'independent_comparisons':sum(p['arm']!='base_default' and all(p['outputs_exist']) for p in pairs)},indent=2))
