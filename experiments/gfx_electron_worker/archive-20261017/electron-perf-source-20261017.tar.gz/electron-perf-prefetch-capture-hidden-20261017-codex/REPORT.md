# EE-PERF-3-HIDDEN — stayHidden is NOT a sufficient fix

Task: read-only analysis and new-E-only causal experiment. No repository or old evidence directory was changed; archived worktree was not restored. Native timing window was explicitly granted by controller, the single group was collected with exit 0, then released. No performance expansion, 450, full film, or PR action.

## Local SDK fact and falsifiable hypothesis

Exact SDK: `/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron`. `sdk-evidence.json` preserves local `electron.d.ts` excerpts/full SHA, package version and binary SHA. Binary `433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f` was verified before execution.

The type docs at 18199–18206 and Opts at 23439–23447 state capturePage default stayHidden=false; a hidden window's page is considered visible while capturer count is nonzero, and stayHidden=true keeps it hidden. Another documented qualifier at 6700–6705: paintWhenInitiallyHidden defaults true, and show:false does not establish hidden document.visibilityState on first load. We did not change paintWhenInitiallyHidden.

Hypothesis: default baseline capture could alter native capturer/visibility state during another OSR document's creation/navigation, influencing later nonce-paint alpha compositing. This was plausible API-grounded causation, not a known root cause. The four-arm experiment tests whether changing only capturePage's stayHidden option is sufficient. **It is not.**

## Four sides and preserved gates

Within each base/early pair the only configuration delta is `wc.capturePage()` versus `wc.capturePage(undefined, {stayHidden:true})`; byte comparison verified this before execution. Base is d323-equivalent serial decoder-thread runtime, early is the rejected one-document-ahead source. Both carry identical host state sampling and failure-only native byte dumps. Full source/dependency copies are under runtime/ and workers/, with 72 input/source SHA pins validated before/after. Original navigation fixture is an unchanged copy.

No page source/listener injection for observations. Public host getters wc.mainFrame.visibilityState, wc.isBeingCaptured(), win.isVisible() are sampled in memory at window creation, paint callbacks, witness requests, just before baseline call, synchronously after initiating the capture and after awaiting it, and close. Samples are written only on frame close. No extra await is inserted. Transient native states between callbacks may be missed; these are host observations, not continuous compositor tracing.

All four nonce A/B/A/B witnesses, six native PNG encodes and six full RGBA decodes, baseline solely veto, document/error/Promise/child fences, 40ms/100ms/15s, and failclosed output binding remain. No baseline pixels recover output. Each worker run has new profile/output; bwrap rootRO/private PID+net+dev/physical tmp/X11 socket RO and only this new E writable. Actual argv/environment are saved. HOME was not repurposed.

## Actual result

192×96 unchanged fractional-alpha navigation fixture, frames3/0/2, 12 repetitions per side (36 requested frames each), alternating forward/reverse arm order:

| Arm | Native runs rc1 | Failed frames | Published frames |
|---|---:|---:|---:|
| base default | 0/12 | 0/36 | 36 |
| base stayHidden | 0/12 | 0/36 | 36 |
| early default | 7/12 | 7/36, all f0 | 29 |
| early stayHidden | 4/12 | 4/36, all f0 | 32 |

All eleven are the same true alpha veto signature: 18,021 differing pixels, bbox x0..191/y1..94; representative native baseline RGBA [199,100,40,128] versus witness-derived RGBA [227,177,147,255], with alpha0 background becoming opaque white. The early-stayHidden failures occur at repetitions 4,7,9,11. `failure-analysis.json` pins each full byte buffer; original baseline PNG/ar/br/clean/expected dumps remain next to every failing run. White-compositing-like output is observed; its native root cause remains unproven. The finite failure-count difference 7 vs4 is not a reliable rate/performance claim and does not make the option acceptable.

The separate visibility-sensitive NEW fixture encodes document visibility plus visibilitychange count into pixels; two repetitions/side, six frames/side, all four arms rc0/no failure. Every available published arm output was compared to its round's base-default PNG and full RGBA: 157 comparisons including 42 base self-comparisons; **115 non-self comparisons have zero PNG-byte and full-RGBA differences**. Eleven missing outputs remain failures and are not substituted. The absence of differences for the visibility-sensitive fixture is limited to current paintWhenInitiallyHidden=true behavior; do not generalize to arbitrary visibility-dependent pages.

## Host visibility/capture observations

Four sides consistently begin with host main-frame state hidden at window creation, but are visible by baseline_before_call. At baseline_after_call_before_await, isBeingCaptured=true; by baseline_resolved it is false. Frame visibility remains visible across baseline and witness samples; window-visible remains false. Thus a simple observed JavaScript visibility-state flip caused by the baseline is **not supported** in this setup. stayHidden does not remove capturer-count activity and did not prevent alpha failure. Native/compositor effects that this sparse public state sampling cannot observe remain UNKNOWN. `host-state-summary.json` and every per-frame visibility JSON preserve the raw facts.

## Exit, cleanup and limits

One controller-authorized experiment group: run.py --repeats=12, outer exit0; 56 native worker invocations with each actual exit preserved in results/summary. Outer rc0 means all observations collected, not candidate success. Initial syntax checks and single-factor/pins checks exit0. No source changed during execution; post-run pins passed. cleanup-check.json shows zero matching live native PIDs and zero runtime profiles. Native window was explicitly released after collecting exit.

This rejects stayHidden as a sufficient correction for early prefetch. Do not change production, reuse the early exploratory speedups as qualified performance, or enlarge this direction to formal perf/450/full film based on this group. All failed states remain. Work stops after this report and final SHA seal.
