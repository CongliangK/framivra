import os,sys,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent
SDK=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron');binary=SDK/'dist/electron'
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f'
for rel,digest in json.loads((E/'source-pins.json').read_text())['files'].items():assert hashlib.sha256((E/rel).read_bytes()).hexdigest()==digest,rel
for p in ['xdg-config','xdg-cache','physical-tmp']:(E/p).mkdir(exist_ok=True)
auths=list(Path('/run/user/1000').glob('.mutter-Xwaylandauth.*'));assert len(auths)==1,auths
assert Path('/tmp/.X11-unix').is_dir()
env={k:os.environ[k] for k in ['PATH','USER','LOGNAME','LANG'] if k in os.environ}
env.update(DISPLAY=':0',XAUTHORITY=str(auths[0]),XDG_SESSION_TYPE='x11',ELECTRON_OZONE_PLATFORM_HINT='x11',VTX_ELECTRON_BIN=str(binary),PYTHONPATH=str(E/'runtime'),PYTHONDONTWRITEBYTECODE='1',XDG_CONFIG_HOME=str(E/'xdg-config'),XDG_CACHE_HOME=str(E/'xdg-cache'),TMPDIR='/tmp',VTX_GFX_PAGES='1')
cmd=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--unshare-pid','--ro-bind','/','/','--proc','/proc','--dev','/dev','--bind',str(E),str(E),'--bind',str(E/'physical-tmp'),'/tmp','--ro-bind','/tmp/.X11-unix','/tmp/.X11-unix','--chdir',str(E),'--','/usr/bin/python3','-B',str(E/'four_sides.py'),*sys.argv[1:]]
(E/'four_sides.command.json').write_text(json.dumps({'argv':cmd,'environment':env},indent=2))
with (E/'four_sides.log').open('xb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(E/'four_sides.exit.json').write_text(json.dumps({'exit_code':r.returncode}));print(r.returncode);raise SystemExit(r.returncode)
