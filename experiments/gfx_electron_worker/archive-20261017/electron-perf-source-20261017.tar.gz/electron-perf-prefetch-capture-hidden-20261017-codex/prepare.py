from pathlib import Path
import shutil,hashlib,json
OLD=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
E=OLD.parent/'electron-perf-prefetch-capture-hidden-20261017-codex'
BASE=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
SDK=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron')
E.mkdir(exist_ok=False)
(E/'inputs').mkdir();(E/'runtime').mkdir()
shutil.copytree(BASE/'vtx',E/'runtime/vtx',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copyfile(OLD/'run2-source/vtx/gfx_electron.py',E/'runtime/vtx/_early_adapter.py')
shutil.copyfile(BASE/'experiments/gfx_electron_worker/pages/navigation_fixture.html',E/'inputs/navigation_fixture.html')
(E/'inputs/visibility_sensitive.html').write_text('''<!doctype html><style>html,body{margin:0;background:transparent}canvas{display:block}</style><canvas id=c></canvas><script>
const f=Number(new URL(location.href).searchParams.get('f')||0);c.width=innerWidth;c.height=innerHeight;
let changes=0;
function draw(){const g=c.getContext('2d');g.clearRect(0,0,c.width,c.height);g.fillStyle=document.visibilityState==='hidden'?'rgba(20,180,40,0.5019607843137255)':'rgba(200,100,40,0.5019607843137255)';g.fillRect(40,20,80,50);g.fillStyle='rgb('+((f*37)%256)+','+(changes%256)+',80)';g.fillRect(40,80,80,8);}
document.addEventListener('visibilitychange',()=>{changes++;draw()});draw();</script>''')
# Four sides differ within each pair ONLY at the capturePage options call.
for prefix,src in [('base',OLD/'diag-base'),('early',OLD/'diag-no_refresh')]:
 original=(src/'navigation_worker.mjs').read_text()
 assert original.count('const baselineImage = await wc.capturePage();')==1
 instrumented=original.replace('  const wc = win.webContents;', '''  const wc = win.webContents;
  const visibilitySamples=[];
  const observeVisibility=stage => {
    const row={stage,frame:f,generation,monotonic_ms:Number(process.hrtime.bigint())/1e6};
    try { row.frame_visibility=wc.mainFrame.visibilityState; row.being_captured=wc.isBeingCaptured(); row.window_visible=win.isVisible(); }
    catch(e) { row.observation_error=String(e); }
    if(visibilitySamples.length<10000) visibilitySamples.push(row);
  };
  observeVisibility('window_created');''')
 instrumented=instrumented.replace('    paints++;','    paints++; observeVisibility(\'paint\');')
 instrumented=instrumented.replace("  const fail = reason => { fatal ||= Error(reason); active?.reject(fatal); };", "  const fail = reason => { observeVisibility('page_failure'); fatal ||= Error(reason); active?.reject(fatal); };")
 instrumented=instrumented.replace('    const token = crypto.randomBytes(48);',"    observeVisibility('witness_requested:'+operation);\n    const token = crypto.randomBytes(48);")
 instrumented=instrumented.replace('    const baselineImage = await wc.capturePage();', "    observeVisibility('baseline_before_call');\n    const baselineCapture = wc.capturePage();\n    observeVisibility('baseline_after_call_before_await');\n    const baselineImage = await baselineCapture;\n    observeVisibility('baseline_resolved');")
 instrumented=instrumented.replace("    errorGate?.close(); if (!win.isDestroyed()) win.destroy();", "    observeVisibility('closing');\n    atomicWrite(path.join(job.out_dir,`visibility-f${String(f).padStart(4,'0')}.json`),JSON.stringify(visibilitySamples,null,2));\n    errorGate?.close(); if (!win.isDestroyed()) win.destroy();")
 assert instrumented.count('const baselineCapture = wc.capturePage();')==1
 assert instrumented.count('visibility-f${String(f)')==1
 for hidden in [False,True]:
  name=prefix+('_stay_hidden' if hidden else '_default');d=E/'workers'/name;d.mkdir(parents=True)
  for module in ['pixel_codec.mjs','page_error_gate.mjs']:shutil.copyfile(src/module,d/module)
  s=instrumented.replace('const baselineCapture = wc.capturePage();','const baselineCapture = wc.capturePage(undefined, {stayHidden:true});') if hidden else instrumented
  (d/'navigation_worker.mjs').write_text(s)
# Exact official local SDK excerpts and full-file pin, no network assertions.
text=(SDK/'electron.d.ts').read_text().splitlines()
excerpts={str(a)+'-'+str(b):'\n'.join(text[a-1:b]) for a,b in [(18199,18207),(23439,23449),(6697,6707),(18499,18506),(19498,19509)]}
(E/'sdk-evidence.json').write_text(json.dumps({'sdk_path':str(SDK),'electron_d_ts_sha256':hashlib.sha256((SDK/'electron.d.ts').read_bytes()).hexdigest(),'electron_binary_sha256':hashlib.sha256((SDK/'dist/electron').read_bytes()).hexdigest(),'package':json.loads((SDK/'package.json').read_text()),'excerpts':excerpts},indent=2))
# Controlled harness is copied into the NEW E. No old E or repository writes.
script=r'''import os,json,time,hashlib,importlib,sys,argparse
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
from vtx import gfx_electron as base_adapter
from vtx import _early_adapter as early_adapter
E=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--repeats',type=int,default=12);args=parser.parse_args()
assert 1<=args.repeats<=40
source_pins=json.loads((E/'source-pins.json').read_text())['files']
def verify_pins():
 for rel,digest in source_pins.items():assert hashlib.sha256((E/rel).read_bytes()).hexdigest()==digest,rel
verify_pins()
ctx=SimpleNamespace(root=E/'context',cache=E/'context/cache',out=E/'context/out');ctx.root.mkdir(exist_ok=True)
ARMS=['base_default','base_stay_hidden','early_default','early_stay_hidden']
rows=[];comparisons=[]
for case,repeats in [('navigation_fixture',args.repeats),('visibility_sensitive',2)]:
 page=E/'inputs'/(case+'.html');source_sha=hashlib.sha256(page.read_bytes()).hexdigest()
 for repeat in range(repeats):
  # Alternating forward/reverse order avoids always placing stayHidden last.
  order=ARMS if repeat%2==0 else list(reversed(ARMS))
  for arm in order:
   adapter=base_adapter if arm.startswith('base_') else early_adapter
   adapter.WORKER_DIR=E/'workers'/arm;out=E/'runs'/case/str(repeat)/arm
   before=time.monotonic();st=adapter.render_page(page,out,4,width=192,height=96,frames=[3,0,2],ctx=ctx,timeout_s=15,mode='b0',output='electron_native_topng')
   raw_path=Path(st['evidence_dir'])/'result.json';raw=json.loads(raw_path.read_text()) if raw_path.exists() else None
   row=dict(case=case,repeat=repeat,arm=arm,adapter=st,wall_s=time.monotonic()-before,raw_result=raw,source_sha256=source_sha)
   rows.append(row);(E/'results.json').write_text(json.dumps(rows,indent=2));print(case,repeat,arm,st['exit_code'],st['failed'],flush=True)
   assert hashlib.sha256(page.read_bytes()).hexdigest()==source_sha
  for arm in ARMS:
   for frame in [3,0,2]:
    paths=[E/'runs'/case/str(repeat)/a/f'f{frame:04d}.png' for a in ['base_default',arm]]
    exists=[p.exists() for p in paths]
    r=dict(case=case,repeat=repeat,arm=arm,frame=frame,outputs_exist=exists)
    if all(exists):
     decoded=[Image.open(p).convert('RGBA') for p in paths];rgba=[im.tobytes() for im in decoded]
     r.update(png_bytes_equal=paths[0].read_bytes()==paths[1].read_bytes(),rgba_equal=rgba[0]==rgba[1],different_rgba_channels=sum(x!=y for x,y in zip(*rgba)),alpha_extrema=[im.getchannel('A').getextrema() for im in decoded],png_sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths])
    comparisons.append(r)
  (E/'comparisons.json').write_text(json.dumps(comparisons,indent=2))
verify_pins()
summary={}
for r in rows:
 key=r['case']+'/'+r['arm'];z=summary.setdefault(key,dict(runs=0,failed=[],exit_codes=[],published=0));z['runs']+=1;z['failed']+=r['adapter']['failed'];z['exit_codes'].append(r['adapter']['exit_code']);z['published']+=r['adapter']['rendered']
(E/'summary.json').write_text(json.dumps({'arms':summary,'source_pins_unchanged':True,'note':'Experiment rc0 means all observations were collected, NOT that every arm passed. Native failures and genuine pixel differences remain in results/comparisons.'},indent=2))
print('OBSERVATIONS_COMPLETE',flush=True)
'''
(E/'four_sides.py').write_text(script)
runner=r'''import os,sys,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent
SDK=Path(SDK_LITERAL);binary=SDK/'dist/electron'
assert hashlib.sha256(binary.read_bytes()).hexdigest()=='433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f'
for rel,digest in json.loads((E/'source-pins.json').read_text())['files'].items():assert hashlib.sha256((E/rel).read_bytes()).hexdigest()==digest,rel
for p in ['xdg-config','xdg-cache','physical-tmp']:(E/p).mkdir(exist_ok=True)
auths=list(Path('/run/user/1000').glob('.mutter-Xwaylandauth.*'));assert len(auths)==1,auths
assert Path('/tmp/.X11-unix').is_dir()
env={k:os.environ[k] for k in ['PATH','USER','LOGNAME','LANG'] if k in os.environ}
env.update(DISPLAY=':0',XAUTHORITY=str(auths[0]),XDG_SESSION_TYPE='x11',ELECTRON_OZONE_PLATFORM_HINT='x11',VTX_ELECTRON_BIN=str(binary),PYTHONPATH=str(E/'runtime'),PYTHONDONTWRITEBYTECODE='1',XDG_CONFIG_HOME=str(E/'xdg-config'),XDG_CACHE_HOME=str(E/'xdg-cache'),TMPDIR='/tmp',VTX_GFX_PAGES='1')
cmd=['/usr/bin/bwrap','--die-with-parent','--unshare-net','--unshare-pid','--ro-bind','/','/','--proc','/proc','--dev','/dev','--bind',str(E),str(E),'--bind',str(E/'physical-tmp'),'/tmp','--ro-bind','/tmp/.X11-unix','/tmp/.X11-unix','--chdir',str(E),'--','/usr/bin/python3','-B',str(E/'four_sides.py'),*sys.argv[1:]]
(E/'four_sides.command.json').write_text(json.dumps({'argv':cmd,'environment':env},indent=2))
with (E/'four_sides.log').open('xb') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(E/'four_sides.exit.json').write_text(json.dumps({'exit_code':r.returncode}));print(r.returncode);raise SystemExit(r.returncode)
'''.replace('SDK_LITERAL',repr(str(SDK)))
(E/'run.py').write_text(runner)
(E/'PREPARATION.md').write_text('''# EE-PERF-3-HIDDEN — prepared, native NOT RUN

Hypothesis: the baseline capturePage() default stayHidden=false enters a temporary capturer/visibility state which, when another OSR document is created/navigated concurrently, can influence later native alpha compositing. Earlier experiments observed baseline fractional alpha while four nonce witnesses became opaque white-composited; native root cause remains unproven.

Local electron.d.ts documents stayHidden default false and hidden window capturer-count visibility. It also documents paintWhenInitiallyHidden default true: current show:false alone does not establish hidden document.visibilityState. No arm changes paintWhenInitiallyHidden, background, timing thresholds, page source, nonce count, PNG encodes/decodes, or error gates.

Four arms: d323-equivalent serial default/stayHidden=true; rejected early-prefetch default/stayHidden=true. Within each pair the ONLY configuration delta is wc.capturePage(undefined, {stayHidden:true}). Shared diagnostic instrumentation samples public wc.mainFrame.visibilityState/wc.isBeingCaptured()/win.isVisible at window creation, native paint, witness request, before baseline call, immediately after initiating baseline capture, after its Promise resolves, and closing. No extra await or page listener is inserted. Samples are stored in memory and written only on frame close. Transient states between host event callbacks may be missed; no claim of continuous native capturer-count tracing.

Each arm retains baseline only as veto, four nonce A/B/A/B paint witnesses, six native PNG encodes and full RGBA decodes, 40ms repeat wait, 100ms resources quiet, 15s deadline, document/error fences. Failed baseline/expected/ar/br/clean native buffers are retained. The default-side copies already contain these failure-only dumps from previous diagnostics.

Prepared default: 12 repetitions of unchanged 192x96 navigation fixture at frames3/0/2, plus two repetitions of a NEW visibility-sensitive fixture. Four arms alternate forward/reverse order, use new profiles/outputs and retain every failure. Visibility-sensitive pixels encode hidden/visible state and event count. Every published result is compared with that repeat's base_default PNG bytes and full RGBA; a genuine pixel difference is recorded, never ignored as expected. A missing output remains a failure, never substituted. The harness rc0 means observation collection completed, not that the candidate passed. This is a causal correctness experiment, not a production performance benchmark.

Falsification: if early_stay_hidden still has the same alpha veto, stayHidden is insufficient. If early_default no longer reproduces, the instrumented group is inconclusive about curing the prior failure. If base_stay_hidden changes pixels/failure/visibility behavior, the option is not behavior-neutral for these inputs. If all frame visibility samples remain visible, the simple visibility-transition subhypothesis is unsupported, though a capturer-native path may remain unobserved. A zero-failure group would narrow the cause, not prove correctness over arbitrary pages.

No native invocation has been made. Await controller's explicit native window release. Only this NEW E was written; old E and all repositories remain read-only. The managed failed worktree was not restored.
''')
shutil.copyfile('/tmp/ee-hidden-prepare.py',E/'prepare.py')
files={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for p in E.rglob('*') if p.is_file()}
(E/'source-pins.json').write_text(json.dumps({'task':'EE-PERF-3-HIDDEN','status':'PREPARED_NOT_RUN','files':files},indent=2))
print(json.dumps({'directory':str(E),'files':len(files),'source_pins_sha256':hashlib.sha256((E/'source-pins.json').read_bytes()).hexdigest()},indent=2))
