# EE-PERF-2 单host PNG decoder线程候选

结论：FUNCTIONAL_TARGETED_REGRESSION_PASS / PERFORMANCE_IMPROVED_BUT_STILL_BELOW_HISTORICAL_CEF。稳定源码已冻结，等待fresh独立审查；不得据此重启整片或推进PR合并。

任务ID：EE-PERF-2。工作树：`/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017`；HEAD仍`0b1b78bf4472d133ccfb89e14803f832f0d2ef29`，无add/commit/分支切换/push/merge。未改原片、HTML、timeline、fonts/style/audio/thresholds。旧receipts/perf工作树和历史失败证据保持只读。

## 实际补丁与边界

- `pixel_codec.mjs`：保持0b1完整RGB/RGBA8解码算法，新增单host `worker_threads` decoder；同文件bootstrap仅在显式workerData标记的worker中运行，普通import不启动线程。无需新依赖，现有identity已经包含该文件。
- `navigation_worker.mjs`：六次原生PNG encode全部保留；baseline/a/b/aa/bb decode与paint/40ms等待重叠，收齐五份完整RGBA后做原比较/merge/baseline veto，final decode收齐后原page/resource fence和同步assertComplete再原子发布。baseline仅veto，四nonce A/B/A/B及40ms/100ms/15s全部保留；没有新document预取或navfree。
- 请求与回复严格绑定frame/generation/op/geometry，op顺序固定六个、每帧使用次数和完成计数必须六，pending容量硬上限六；未知/重复/迟到/错误几何/短RGBA/崩溃/退出均failclosed。PNG经postMessage复制、compositor bitmap不转移；仅decoder自有RGBA ArrayBuffer转移回host。
- 原单inflight frame、单fresh BrowserWindow/WebContents/document路径保留。真实声明`max_inflight=1, decoder_threads=1, max_pending_decodes=6`；每帧receipt新增`png_decode_count=6`，发布前检查真实完成计数。没有renderer并发扩容；独立可信host线程不是额外render worker。
- 失败page的已提交decode在finally drain，仍由同一整帧15s watchdog约束；允许worker跳过没有提交decode的失败generation，host begin仍严格+1，旧pending排空后才能下一帧。正常end terminate decoder；超时/parent-death跟随受监督进程树退出，原SIGKILL清理回归通过。
- `test_decoder_thread.mjs`新增真实线程完整alpha/copy所有权、跨代、错frame/op/几何、短数据、额外字段、坏PNG、异常退出反例；`test_navigation.py`接入。Python生产reader/adapter没有改动。

## 当前真实1080 profile与方向选择

基线0b1三帧open_source_card profile rc0。六decode合计176.37/171.10/128.81ms；六encode114.49/146.57/155.08ms。另一次独立细分诊断decode内部六次inflate33–35ms、unfilter67–102ms、RGB展开27–68ms。这些是嵌套诊断值，不能相加当总wall。当前encode已与decode相当，单纯少分配不能承诺接近CEF，因此本棒选择让可信decode与原等待/paint重叠。

候选诊断三帧总wall557.88/496.39/528.58ms。相邻marks的非重叠区间保存在`profile-summary.json`：blank+file导航约107/43/43ms；quiet20/81/101ms；baseline段119/63/51ms；AB段93/95/98ms；原40ms等待40/41/40ms；AA/BB及收齐段111/99/111ms；重建+final decode45/50/57ms。每操作encode/decode/CPU与这些区间嵌套或并发，不能再相加。诊断副本不是无仪表candidate验收。

## 最终受控native AB/BA（冻结SHA）

rootRO bwrap/private net+PID+dev+physical tmp/host X11socket RO/仅本E可写，隔离与旧报告范式一致；实际argv与白名单env逐次在`*.command.json`。DISPLAY=:0，XAUTHORITY已核，unset WAYLAND_DISPLAY/ELECTRON_RUN_AS_NODE；SDK SHA433b343...未改。单worker/PAGES1/b0/electron_native_topng/15s/1920×1080，同三份只读实验原HTML、frames30/60/90。AB后BA两轮各侧18帧，共36帧，冷新profile/output，无artifact命中，包含启动。OS/font缓存未清除，不冒充物理磁盘冷态。

| 页 | 0b1 fps | 候选fps | 加速 | 旧/新 observed child user CPU s（各6f） |
|---|---:|---:|---:|---:|
| nav_two_pillars | 1.661 | 2.060 | 1.241× | 1.962/2.119 |
| open_source_card | 1.458 | 1.707 | 1.171× | 2.344/2.513 |
| u2_backends | 1.708 | 1.991 | 1.166× | 1.940/2.141 |

合计wall11.241462→9.440475s，**1.19077×**。18对PNG字节及decoded全RGBA逐字节零差；最终bench逐页worker SHA与冻结源码一致，raw receipts每帧四witness/六decode，声明均核过。CPU不是下降：observed child user6.2463→6.7731s，system3.7880→3.8793s；Python self user0.0388→0.0321s、system0.0312→0.0377s。rusage可能漏非本父链reap的renderer后代；不是完整树CPU。诊断process.cpuUsage包含host和decoder线程，不是main-thread独占CPU。

CEF3.186/1.911/3.845fps为**前棒历史同机样本**，不是本棒同步新测CEF；当前候选仍低于该参照，尤其nav/u2。不能凭1.19×宣布性能达标。后续性能准入需新鲜CEF对照。

## Alpha与真实失败保留

- 真实128alpha fixture：1080 f0/1/3每帧5000个alpha128像素，alpha范围[0,128]，旧新PNG和全RGBA全等。
- 最终额外真实原HTML9对零差（`alpha-original-fractional-run2-comparisons.json`）：e1_pain_card f81[0,0]/82[0,31]/84[0,94]；llm_post f414[234,234]/415[213,213]/417[170,170]（从旧44RGBA来源定位）；w_title f0/1/3[0,255]。逐字节PNG及全RGBA均全等，没有修改HTML或时间参数。
- 早期g6a_title f0/1/3虽有body fade，但html自带opaque底，alpha全255；只作为opaque fade证据，不能充透明覆盖。早期e1 f0/1/3尚未入场，alpha全0；保留为零alpha证据。
- 分数alpha第一次实际尝试在旧0b1的首全透明e1 f81遇native `UnknownVizError`，rc1/failed81；未删除。随后完全相同样本全新profile/output原样run2 rc0，未降低任何门、未忽略失败、未修改候选。该既有native瞬态仍是未归因限制。

## 回归与反例

最终完整46项（旧45+新协议测试）35.981s/rc0/OK/0skip，含真实一秒all/QC/Blender saved strip path audit、页面错误/Promise/三子节点、alpha、wrong-document、SIGKILL与卡死清理、readonly caller source/config绑定、cache/failclosed/strict/零fallback。仅目标Electron相关套件；未宣称全仓门全过。

八类native decoder错误每个先 genuine rc0 control，之后只在本E独立worker副本tamper。wrong_generation/wrong_frame/crash/exit/badRGBA/shortRGBA/duplicate全部rc1；missing reply rc72，总wall15.198s，证明整帧15s watchdog仍封闭静默线程。所有failed[0]/rendered0，预置旧PNG SHA未变，profile清理检查过；详`negative-results.json`。

修复/失败历程均保留：首回归rc1（44项，1failure+1error）：失败f1没有decode导致worker期望generation2拒后续3，已修为上述安全跳代+drain。该修复在首回归尾段仍运行时落笔，使Blender audit观察到source identity变化而failclosed；这是执行纪律错误，不能算产品Blender通过。随后源码冻结再跑46全绿并重做最终36帧bench；后续所有native不再改生产源码。另旧诊断生成器首次匹配旧witness调用失败rc1，改本E生成器后成功，未触候选。初测36帧、旧profile、首FAIL及所有raw均保留。

## 真实450帧连续诊断

原u2_backends时间线dur896，合法连续0..449，1080、单worker、原源只读；用独立仪表副本保留全部真实native路径，450 PNG/raw receipts/2700 decode事件全部收齐、rc0/failed[]。wall200.854745s，约2.240fps；这是**仪表450诊断**，不是最终无仪表吞吐、不是全片完成、没有450帧旧新全像素比较。observed child user120.4665/system68.8656s，self user0.5623/system0.1670s。

host进程（含decoder线程）RSS峰789.47MiB，末665.18MiB；这不含renderer/utility，不能冒充树RSS。首30帧均389.53ms，末30均462.54ms；中间300..399范围有最大1075.19ms。源内容随f变化，未做同内容重复控制，不能归因纯性能退化。RSS区间反复回落而非单调增长。decoder isolate GC2169次、合765.23ms、最大13.785ms；main与renderer GC UNKNOWN。详`tail-analysis.json`与原始`candidate-thread-{events,gc}.jsonl`，每帧六op顺序已机验。

## Identity、快照与收尾

新identity SHA：`4e4fe52557ea1d1171885a1e149bc4c2cb61a7ce22c89fb216aa4a1c0cb93866`，与0b1的ca6b221...不同，不能把旧native缓存当新current缓存。源码SHA：

- `experiments/gfx_electron_worker/navigation_worker.mjs`：`779cef67cf9e0a848afb6f0f08e797b77dfcc1386b2cbc9ce1de084c7810d5e2`
- `experiments/gfx_electron_worker/pixel_codec.mjs`：`9a8a4cc448dccfc0d541f56977150272a058d61adba1cbf0d2cb50c9c13c2142`
- `experiments/gfx_electron_worker/test_navigation.py`：`65e5c879e656ead39d8350a446ed7e9046c01b596fa27f3ad86d2f607e00c9b7`
- `experiments/gfx_electron_worker/test_decoder_thread.mjs`：`d40b206bcea874a0f7a9a6868107f010e3488d7278cdd22f7115bac31ae1c932`

`candidate.diff`包含tracked diff和新增test文件；`candidate-source-snapshot.json`保存HEAD/脏树状态与hash。没有commit；不是新HEAD CI证明。`tooling/`保留实际实现/运行/统计脚本。执行入口均为`python3 tooling/run.py <name.py>`（run脚本中实际路径仍指本E），各次精确bwrap argv/env见`<name.py>.command.json`，退出码见同名exit.json和`command-exit-ledger.json`：

- `alpha_fractional.py`：1
- `alpha_fractional_run2.py`：0
- `alpha_transparent.py`：0
- `candidate_profile.py`：0
- `candidate_tail.py`：0
- `detail.py`：0
- `final_bench.py`：0
- `identity.py`：0
- `native_bench.py`：0
- `profile.py`：0
- `regression.py`：1
- `regression_final.py`：0
- `validation.py`：0

额外源码/脚本操作：setup/instrument初始成功0；instrument_candidate首次匹配失败1、修正后0；patch/harden/tests/fix_isolation均0；纯host `node test_decoder_thread.mjs` 0；git diff --check 0。仅授权工作树相关runtime/tests与本E写入；所有后台session均亲收退出码。最终冻结复核不变后停止写入，交主控fresh审查。

未解决：仍明显低于历史CEF，整片未重启/PR未推进；UnknownVizError旧基线瞬态未归因；450只诊断未做无仪表双侧持续比较；完整树RSS/CPU与main/renderer GC未测。下一棒可在独立审查认可后评估有界一document-ahead，隔离session/resources/errors、按序capture/receipt、预备起始15s预算不重置，必须显式升级声明与Pythonreader，不能静默重解释max1。约120ms预备可隐藏的1.3×只是乐观上界，不是承诺。
