from pathlib import Path
import shutil,hashlib,json
E=Path(__file__).resolve().parent;S=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/experiments/gfx_electron_worker');D=E/'candidate-instrumented';D.mkdir(exist_ok=True)
for n in ('page_error_gate.mjs',):shutil.copyfile(S/n,D/n)
s=(S/'pixel_codec.mjs').read_text();s=s.replace('export function decodeNativePng(png, width, height) {','function decodeNativePngCore(png, width, height) {',1)
s+='\nexport function decodeNativePng(...args){let t=process.hrtime.bigint(),c=process.cpuUsage();try{return decodeNativePngCore(...args)}finally{let d=process.cpuUsage(c);(globalThis.__vtxPerf ||= []).push({phase:"decode",ms:Number(process.hrtime.bigint()-t)/1e6,cpu_ms:(d.user+d.system)/1000});}}\n'
(D/'pixel_codec.mjs').write_text(s)
s=(S/'navigation_worker.mjs').read_text()
helpers='''
function mark(label){(globalThis.__vtxMarks ||= []).push({label,ns:String(process.hrtime.bigint()),cpu:process.cpuUsage()});}
function timed(label,fn){let t=process.hrtime.bigint(),c=process.cpuUsage();try{return fn()}finally{let d=process.cpuUsage(c);(globalThis.__vtxPerf ||= []).push({phase:label,ms:Number(process.hrtime.bigint()-t)/1e6,cpu_ms:(d.user+d.system)/1000});}}
function atomicWrite(...args){return timed('atomic_write',()=>atomicWriteCore(...args));}
'''
s=s.replace('function samePhase(',helpers+'\nfunction samePhase(',1).replace('function atomicWrite(target, data) {','function atomicWriteCore(target, data) {',1)
s=s.replace('  const start = Date.now();','  globalThis.__vtxPerf=[];globalThis.__vtxMarks=[];mark("frame_start");\n  const start = Date.now();',1)
for old,new in [('image.toPNG()',"timed('encode_witness',()=>image.toPNG())"),('image.toBitmap()',"timed('bitmap_witness',()=>image.toBitmap())"),('baselineImage.toPNG()',"timed('encode_baseline',()=>baselineImage.toPNG())"),('rebuilt.toPNG()',"timed('encode_final',()=>rebuilt.toPNG())")]:
 assert old in s,old;s=s.replace(old,new)
for token,label in [("    await deadline(wc.loadURL('data:",'blank_start'),('    errorGate = await installPageErrorGate','blank_end_gate_start'),('    await deadline(wc.loadURL(expectedUrl)','gate_end_navigation_start'),('    await deadline(isolated(wc, `${checkDocumentCode','navigation_end_resources_start'),('    // Track actual browser resource requests','resources_end_quiet_start'),('    if (ses._vtxErrors.length) throw Error(`resource_error:','quiet_end'),('    const baselineImage = await wc.capturePage();','baseline_start'),("    const a = await witness('a','a');",'baseline_end_witness_start'),('    await delay(40);','stable_wait_start'),("    const aa = await witness('a','aa');",'stable_wait_end'),('    const clean = mergeWitnesses','witness_end_merge_start'),('    const rebuilt = nativeImage.createFromBitmap','merge_end_rebuild_start'),('    await checkPageErrors();\n    if (ses._vtxEpoch','rebuild_end_final_fence_start')]:
 assert token in s,token;s=s.replace(token,'    mark('+json.dumps(label)+');\n'+token,1)
s=s.replace('     atomicWrite(job.result,JSON.stringify(result,null,2));','     atomicWrite(job.result,JSON.stringify(result,null,2));')
needle='    atomicWrite(job.result,JSON.stringify(result,null,2));\n  }'
assert needle in s
s=s.replace(needle,'    atomicWrite(job.result,JSON.stringify(result,null,2));\n    mark("frame_and_result_end");fs.writeFileSync(path.join(job.out_dir,`timing-${f}.json`),JSON.stringify({frame:f,marks:globalThis.__vtxMarks,operations:globalThis.__vtxPerf}));\n  }',1)
(D/'navigation_worker.mjs').write_text(s)
(E/'candidate-instrumentation-hashes.json').write_text(json.dumps({n:{'original':hashlib.sha256((S/n).read_bytes()).hexdigest(),'instrumented':hashlib.sha256((D/n).read_bytes()).hexdigest()} for n in ('navigation_worker.mjs','pixel_codec.mjs','page_error_gate.mjs')},indent=2))
