from pathlib import Path
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-pipeline-20261017-codex')
s=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-optimization-20261017/native_bench.py').read_text().replace("'old':ROOT/'alpha-electron-receipts-20261017/experiments/gfx_electron_worker','new':ROOT/'alpha-electron-perf-20261017/experiments/gfx_electron_worker'", "'old':ROOT/'alpha-electron-perf-20261017/experiments/gfx_electron_worker','new':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker'")
(E/'native_bench.py').write_text(s)
