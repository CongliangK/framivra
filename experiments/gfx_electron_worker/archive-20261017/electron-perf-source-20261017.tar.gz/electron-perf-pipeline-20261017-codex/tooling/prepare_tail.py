from pathlib import Path
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-pipeline-20261017-codex')
s=(E/'instrument.py').read_text().replace("D=E/'instrumented'", "D=E/'candidate-instrumented'").replace("E/'instrumentation-hashes.json'", "E/'candidate-instrumentation-hashes.json'")
(E/'instrument_candidate.py').write_text(s)
