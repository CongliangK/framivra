from pathlib import Path
import subprocess,json,hashlib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-pipeline-20261017-codex');T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
files=['experiments/gfx_electron_worker/'+n for n in ['navigation_worker.mjs','pixel_codec.mjs','test_navigation.py','test_decoder_thread.mjs']]
hashes={n:hashlib.sha256((T/n).read_bytes()).hexdigest() for n in files};(E/'candidate-source-snapshot.json').write_text(json.dumps(dict(task_id='EE-PERF-2',tree=str(T),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=T,text=True),files=hashes),indent=2))
patch=subprocess.check_output(['git','diff','--binary'],cwd=T);patch+=subprocess.run(['git','diff','--no-index','--','/dev/null',files[-1]],cwd=T,capture_output=True).stdout;(E/'candidate.diff').write_bytes(patch)
for r in json.loads((E/'final-native-results.json').read_text()):
 if r['backend']=='new':
  for n in ['navigation_worker.mjs','pixel_codec.mjs']:assert r['worker_hashes'][n]==hashes['experiments/gfx_electron_worker/'+n]
  assert all(x['png_decode_count']==6 for x in r['frame_receipts'])
(E/'identity.py').write_text('''import json,hashlib\nfrom vtx.gfx_backend import identity\ns=identity();print(json.dumps(dict(identity=s,identity_sha256=hashlib.sha256(s.encode()).hexdigest()),indent=2))\n''')
print(hashes)
