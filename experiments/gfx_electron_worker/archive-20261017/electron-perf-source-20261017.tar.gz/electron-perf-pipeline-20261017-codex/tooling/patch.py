from pathlib import Path
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/experiments/gfx_electron_worker')
p=T/'pixel_codec.mjs';s=p.read_text();s=s.replace("import zlib from 'node:zlib';", "import zlib from 'node:zlib';\nimport { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';")
s+='''

// One host decoder thread, never a page/render worker. Six independently encoded
// PNGs still undergo the same full RGBA decoder. Only immutable PNG copies cross
// the boundary; compositor bitmaps remain owned by the main thread.
const DECODE_OPERATIONS = ['baseline', 'a', 'b', 'aa', 'bb', 'final'];
export class NativePngDecoder {
  constructor(width, height) {
    this.width = width; this.height = height; this.pending = new Map();
    this.generation = 0; this.used = new Set(); this.failure = null; this.closed = false;
    this.worker = new Worker(new URL(import.meta.url), {workerData:{vtxNativePngDecoder:1}});
    this.worker.on('message', message => {
      if (this.closed) return;
      const entry = this.pending.get(message?.operation);
      if (!entry || message.generation !== this.generation || message.frame !== this.frame ||
          message.width !== this.width || message.height !== this.height ||
          !(message.rgba instanceof Uint8Array) || message.rgba.byteLength !== this.width*this.height*4 ||
          Object.keys(message).sort().join(',') !== 'frame,generation,height,operation,rgba,width') {
        this.fail(Error('decoder_protocol')); return;
      }
      this.pending.delete(message.operation);
      entry.resolve(Buffer.from(message.rgba.buffer, message.rgba.byteOffset, message.rgba.byteLength));
    });
    this.worker.on('error', e => this.fail(Error(`decoder_error:${e.message}`)));
    this.worker.on('exit', code => { if (!this.closed) this.fail(Error(`decoder_exit:${code}`)); });
  }
  fail(error) {
    this.failure ||= error;
    for (const entry of this.pending.values()) entry.reject(this.failure);
    this.pending.clear();
  }
  begin(frame, generation) {
    if (this.closed || this.failure) throw this.failure || Error('decoder_closed');
    if (this.pending.size || !Number.isInteger(frame) || !Number.isInteger(generation) || generation !== this.generation+1) throw Error('decoder_generation');
    this.frame = frame; this.generation = generation; this.used.clear();
  }
  decode(png, operation) {
    if (this.closed || this.failure) return Promise.reject(this.failure || Error('decoder_closed'));
    if (!this.generation || !Buffer.isBuffer(png) || !DECODE_OPERATIONS.includes(operation) || this.used.has(operation) || this.pending.size >= 6) return Promise.reject(Error('decoder_operation'));
    this.used.add(operation);
    const promise = new Promise((resolve,reject) => {
      this.pending.set(operation, {resolve,reject});
      try { this.worker.postMessage({generation:this.generation, frame:this.frame, operation,
        width:this.width, height:this.height, png}); }
      catch (e) { this.fail(e); }
    });
    // Errors may arrive while Chromium is painting; fence them when collected.
    promise.catch(() => {});
    return promise;
  }
  close() {
    if (this.closed) return;
    this.closed = true; this.fail(Error('decoder_closed'));
    return this.worker.terminate();
  }
}
if (!isMainThread && workerData?.vtxNativePngDecoder === 1) {
  let generation = 0, frame = -1, used = new Set();
  parentPort.on('message', message => {
    const {generation:g, frame:f, operation, width, height, png} = message;
    if (!Number.isInteger(g) || !Number.isInteger(f) || f < 0 ||
        !Number.isInteger(width) || !Number.isInteger(height) || width < 64 || height < 2 ||
        width > 3840 || height > 2160 || width*height > 8294400 ||
        !(png instanceof Uint8Array) || !DECODE_OPERATIONS.includes(operation) ||
        Object.keys(message).sort().join(',') !== 'frame,generation,height,operation,png,width') throw Error('decoder_request');
    if (g === generation+1) { generation = g; frame = f; used = new Set(); }
    if (g !== generation || f !== frame || used.has(operation)) throw Error('decoder_request_generation');
    used.add(operation);
    const rgba = decodeNativePng(Buffer.from(png.buffer,png.byteOffset,png.byteLength),width,height);
    parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);
  });
}
''';p.write_text(s)
p=T/'navigation_worker.mjs';s=p.read_text().replace('decodeNativePng, markerMatches','NativePngDecoder, markerMatches');s=s.replace('async function renderFrame(f, generation, ses, pageErrors)', 'async function renderFrame(f, generation, ses, pageErrors, decoder)');s=s.replace('  const start = Date.now();','  const start = Date.now();\n  decoder.begin(f, generation);',1);s=s.replace('ready.resolve({bitmap, rgba:decodeNativePng(png,width,height)});','ready.resolve({bitmap, rgba:decoder.decode(png,ready.operation)});');s=s.replace('async function witness(phase)', 'async function witness(phase, operation)');s=s.replace('active = {phase, token, resolve, reject};','active = {phase, token, operation, resolve, reject};');s=s.replace('const baseline = decodeNativePng(baselineImage.toPNG(),width,height);',"const baselinePending = decoder.decode(baselineImage.toPNG(),'baseline');");s=s.replace("const a = await witness('a'); const b = await witness('b');","const a = await witness('a','a'); const b = await witness('b','b');");s=s.replace("const aa = await witness('a');", "const aa = await witness('a','aa');");s=s.replace(" || !samePhase(a.rgba,aa.rgba,'a',width,height)", '');s=s.replace("const bb = await witness('b');", "const bb = await witness('b','bb');");s=s.replace(" || !samePhase(b.rgba,bb.rgba,'b',width,height)", '');s=s.replace("    if (fatal) throw fatal;\n    if (ses._vtxEpoch !== resourceEpoch", "    const [baseline, ar, br, aar, bbr] = await Promise.all([baselinePending,a.rgba,b.rgba,aa.rgba,bb.rgba]);\n    if (!samePhase(ar,aar,'a',width,height)) throw Error('unstable_page:repeated_a');\n    if (!samePhase(br,bbr,'b',width,height)) throw Error('unstable_page:repeated_b');\n    if (fatal) throw fatal;\n    if (ses._vtxEpoch !== resourceEpoch",1);s=s.replace('mergeWitnesses(a.rgba,b.rgba,width,height)', 'mergeWitnesses(ar,br,width,height)');s=s.replace('if (!decodeNativePng(png,width,height).equals(expected))',"if (!(await decoder.decode(png,'final')).equals(expected))");s=s.replace('    max_inflight:1,shared_memory:false,', '    max_inflight:1,decoder_threads:1,max_pending_decodes:6,shared_memory:false,');s=s.replace('  let generation=0;', '  const decoder = new NativePngDecoder(width,height);\n  let generation=0;');s=s.replace('renderFrame(f,++generation,ses,result.page_errors[f])','renderFrame(f,++generation,ses,result.page_errors[f],decoder)');s=s.replace('  app.exit(result.failed.length ? 1 : 0);','  await decoder.close();\n  app.exit(result.failed.length ? 1 : 0);');p.write_text(s)
