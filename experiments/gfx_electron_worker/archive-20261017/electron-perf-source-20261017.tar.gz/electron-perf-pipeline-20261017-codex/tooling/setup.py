from pathlib import Path
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-pipeline-20261017-codex')
E.mkdir(exist_ok=True)
old=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/instrument.py').read_text()
old=old.replace("E=Path(__file__).resolve().parent;S=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-receipts-20261017/experiments/gfx_electron_worker')", "E=Path(__file__).resolve().parent;S=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/experiments/gfx_electron_worker')")
(E/'instrument.py').write_text(old)
bench=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/bench.py').read_text()
start=bench.index('rows=[]\nfor backend')
end=bench.index('# Diagnostic-only')
bench=bench[:start]+bench[end:]
(E/'profile.py').write_text(bench)
