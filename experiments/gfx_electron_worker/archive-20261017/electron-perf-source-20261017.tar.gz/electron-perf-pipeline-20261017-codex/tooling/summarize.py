from pathlib import Path
import json,statistics,collections,hashlib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-pipeline-20261017-codex')
def write(n,d):(E/n).write_text(json.dumps(d,indent=2))
def marks(directory):
 rows=[]
 for p in sorted((E/directory).glob('timing-*.json'),key=lambda p:int(p.stem.split('-')[-1])):
  d=json.loads(p.read_text());m=d['marks'];r={'frame':d['frame'],'wall_ms':(int(m[-1]['ns'])-int(m[0]['ns']))/1e6,'intervals_ms':{b['label']:(int(b['ns'])-int(a['ns']))/1e6 for a,b in zip(m,m[1:])},'operations':d['operations']};rows.append(r)
 return rows
write('profile-summary.json',{'baseline':marks('instrumented-output'),'candidate':marks('candidate-profile-output'),'scope':'Adjacent marks are nonoverlapping wall intervals. Per-operation encode/decode/CPU measures are nested or concurrent and MUST NOT be added to these intervals. Diagnostic copies only, not final candidate throughput.'})
if (E/'candidate-tail-summary.json').exists():
 raw=json.loads((E/'candidate-tail-summary.json').read_text());rr=json.loads((Path(raw['adapter']['evidence_dir'])/'result.json').read_text());assert len(rr['frames'])==450 and rr['failed']==[] and all(f['png_decode_count']==6 and f['witnesses']==4 for f in rr['frames']);assert [f['frame'] for f in rr['frames']]==list(range(450));assert len(list((E/'candidate-tail-output').glob('f*.png')))==450
 events=[json.loads(x) for x in (E/'candidate-thread-events.jsonl').read_text().splitlines()];tail=events[18:];assert len(tail)==2700;group=collections.defaultdict(list)
 for e in tail:group[e['frame']].append(e['operation'])
 assert len(group)==450 and all(x==['baseline','a','b','aa','bb','final'] for x in group.values())
 rows=marks('candidate-tail-output');assert len(rows)==450
 memory=[]
 for a,b in [(0,29),(30,99),(100,199),(200,299),(300,399),(420,449)]:
  es=[r for r in tail if a<=r['frame']<=b];times=[r['wall_ms'] for r in rows if a<=r['frame']<=b];rss=[r['memory']['rss']/1048576 for r in es]
  memory.append(dict(frames=[a,b],frame_wall_mean_ms=statistics.mean(times),frame_wall_median_ms=statistics.median(times),frame_wall_max_ms=max(times),process_rss_min_mib=min(rss),process_rss_max_mib=max(rss),process_rss_end_mib=rss[-1]))
 gc=[json.loads(x) for x in (E/'candidate-thread-gc.jsonl').read_text().splitlines()];splits=[i for i in range(1,len(gc)) if gc[i]['start']<gc[i-1]['start']];tailgc=gc[splits[-1]:] if splits else gc
 write('tail-analysis.json',dict(scope='450 contiguous real u2_backends source frames 0..449 of original N896; diagnostic source copies retain real capture/semantics; not final uninstrumented performance or full-film claim',adapter=raw['adapter'],raw_declarations={k:rr[k] for k in ['max_inflight','decoder_threads','max_pending_decodes']},decode_events=len(tail),each_frame_operations_exact=True,process_rss_scope='Electron host process including decoder thread; excludes renderer/utility processes. Heap/external from decoder isolate. Not full-tree RSS.',process_rss_peak_mib=max(x['memory']['rss'] for x in tail)/1048576,windows=memory,thread_gc=dict(count=len(tailgc),total_ms=sum(x['duration'] for x in tailgc),max_ms=max(x['duration'] for x in tailgc),kind_counts=dict(collections.Counter(str(x['detail']) for x in tailgc)),split_indices=splits,scope='decoder isolate GC only; main/renderer GC UNKNOWN'),source_sha256=hashlib.sha256(Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx/u2_backends.html').read_bytes()).hexdigest()))
print('SUMMARIES_DONE')
