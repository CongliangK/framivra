import os,json,hashlib,shutil,time
from pathlib import Path
from PIL import Image
from vtx import gfx_electron as ee
from vtx.infra import Ctx
E=Path(__file__).resolve().parent
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/experiments/gfx_electron_worker')
OLD=T.parents[1].parent/'alpha-electron-perf-20261017/experiments/gfx_electron_worker'
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
c=Ctx(E/'context/timeline.json')
fixture=E/'context/alpha128.html';fixture.write_text('<!doctype html><style>html,body{margin:0;background:transparent}div{position:absolute;left:50px;top:20px;width:100px;height:50px;background:rgba(200,100,40,0.5019607843137255)}</style><div></div>')
rows=[]
for label,page,frames in [('fade',SRC/'g6a_title.html',[0,1,3]),('alpha128',fixture,[0,1,3])]:
 for backend,worker in [('old',OLD),('new',T)]:
  ee.WORKER_DIR=worker;out=E/'alpha'/label/backend
  st=ee.render_page(page,out,4,width=1920,height=1080,frames=frames,ctx=c,timeout_s=15)
  assert st['exit_code']==0 and st['failed']==[],st
 for f in frames:
  paths=[E/'alpha'/label/b/f'f{f:04d}.png' for b in ('old','new')];ims=[Image.open(p).convert('RGBA') for p in paths];pixels=[im.tobytes() for im in ims]
  assert pixels[0]==pixels[1];assert paths[0].read_bytes()==paths[1].read_bytes()
  if label=='alpha128':assert ims[1].getpixel((90,48))[3]==128
  rows.append(dict(label=label,frame=f,source_sha256=hashlib.sha256(page.read_bytes()).hexdigest(),png_equal=True,rgba_equal=True,alpha_extrema=ims[1].getchannel('A').getextrema(),alpha128_count=sum(a==128 for a in ims[1].getchannel('A').tobytes()),rgba_sha256=hashlib.sha256(pixels[1]).hexdigest()))
(E/'alpha-comparisons.json').write_text(json.dumps(rows,indent=2))
# Each injected worker has a genuine native rc0 control FIRST, then mutation.
fixture=E/'context/protocol.html';fixture.write_text('<style>html,body{margin:0;background:rgb(90,120,160)}</style>')
mutants={
 'wrong_generation':("parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);","parentPort.postMessage({generation:g+1,frame:f,operation,width,height,rgba},[rgba.buffer]);"),
 'wrong_frame':("parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);","parentPort.postMessage({generation:g,frame:f+1,operation,width,height,rgba},[rgba.buffer]);"),
 'missing':("    used.add(operation);","    if(operation==='bb') return;\n    used.add(operation);"),
 'crash':("    used.add(operation);","    if(operation==='a') throw Error('injected_decoder_crash');\n    used.add(operation);"),
 'exit':("    used.add(operation);","    if(operation==='a') process.exit(0);\n    used.add(operation);"),
 'bad_rgba':("    parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);","    if(operation==='final') rgba[0]^=1;\n    parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);"),
 'short_rgba':("parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);","parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba:rgba.subarray(0,1)},[rgba.buffer]);"),
 'duplicate':("parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba},[rgba.buffer]);","parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba}); parentPort.postMessage({generation:g,frame:f,operation,width,height,rgba});")}
results=[]
for label,(before,after) in mutants.items():
 worker=E/'mutants'/label;worker.mkdir(parents=True)
 for name in ['navigation_worker.mjs','pixel_codec.mjs','page_error_gate.mjs']:shutil.copyfile(T/name,worker/name)
 ee.WORKER_DIR=worker
 control=ee.render_page(fixture,E/'negative'/label/'control',1,width=192,height=96,frames=[0],ctx=c,timeout_s=15)
 assert control['exit_code']==0 and control['failed']==[],control
 p=worker/'pixel_codec.mjs';s=p.read_text();assert s.count(before)==1,(label,s.count(before));p.write_text(s.replace(before,after))
 out=E/'negative'/label/'tampered';out.mkdir(parents=True);stale=out/'f0000.png';stale.write_bytes((E/'negative'/label/'control/f0000.png').read_bytes());sha=hashlib.sha256(stale.read_bytes()).hexdigest();start=time.monotonic()
 st=ee.render_page(fixture,out,1,width=192,height=96,frames=[0],ctx=c,timeout_s=15)
 assert st['exit_code']!=0 and st['failed']==[0] and st['rendered']==0,st
 assert hashlib.sha256(stale.read_bytes()).hexdigest()==sha
 assert not list((c.cache/'tmp').glob('*'))
 results.append(dict(case=label,control=control,tampered=st,wall_s=time.monotonic()-start,stale_unchanged=True))
 (E/'negative-results.json').write_text(json.dumps(results,indent=2))
 print('NEGATIVE',label,st['exit_code'],st['errors'],flush=True)
print('VALIDATION_DONE',flush=True)
