import os,unittest
from pathlib import Path
os.environ['VTX_TEST_ELECTRON']='1'
os.environ['VTX_ELECTRON_EVIDENCE_DIR']=str(Path(__file__).resolve().parent/'regression')
suite=unittest.defaultTestLoader.loadTestsFromNames(['experiments.gfx_electron_worker.test_navigation','experiments.gfx_electron_worker.test_page_errors','experiments.gfx_electron_worker.test_promise_checkpoints','tests.test_electron_integration'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
