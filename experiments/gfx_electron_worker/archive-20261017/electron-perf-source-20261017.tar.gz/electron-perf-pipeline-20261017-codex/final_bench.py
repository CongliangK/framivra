import os,sys,json,time,hashlib,resource
from pathlib import Path
from PIL import Image
from vtx.infra import Ctx
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
ROOT=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees')
WORKERS={'old':ROOT/'alpha-electron-perf-20261017/experiments/gfx_electron_worker','new':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker'}
PAGES=['nav_two_pillars','open_source_card','u2_backends'];FRAMES=[30,60,90]
root=E/'context';root.mkdir(exist_ok=True)
(root/'page.html').write_text('<html><body></body></html>')
(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))
c=Ctx(root/'timeline.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cpu():
 a=resource.getrusage(resource.RUSAGE_CHILDREN);b=resource.getrusage(resource.RUSAGE_SELF)
 return dict(child_user=a.ru_utime,child_system=a.ru_stime,self_user=b.ru_utime,self_system=b.ru_stime)
rows=[]
for round_id,order in enumerate((('old','new'),('new','old')),1):
 for backend in order:
  ee.WORKER_DIR=WORKERS[backend]
  for name in PAGES:
   page=SRC/(name+'.html');before=sha(page);out=E/f'final-native-round{round_id}'/backend/name
   t=time.perf_counter();b=cpu();print('BEGIN',round_id,backend,name,flush=True)
   st=ee.render_page(page,out,91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15,mode='b0',output='electron_native_topng')
   assert st['exit_code']==0 and st['failed']==[] and st['errors']=={},st
   a=cpu();raw=json.loads((Path(st['evidence_dir'])/'result.json').read_text())
   assert all(x['witnesses']==4 and x['baseline_veto_passed'] and x['png_semantics_passed'] and x['page_error_fence_passed'] for x in raw['frames'])
   r=dict(round=round_id,backend=backend,page=name,frames=FRAMES,source_sha256=before,wall_s=time.perf_counter()-t,cpu_delta_s={k:a[k]-b[k] for k in a},adapter=st,frame_receipts=raw['frames'],worker_hashes={p.name:sha(p) for p in WORKERS[backend].glob('*.mjs') if p.name in ('navigation_worker.mjs','pixel_codec.mjs','page_error_gate.mjs')})
   assert sha(page)==before
   rows.append(r);(E/'final-native-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('END',round_id,backend,name,r['wall_s'],flush=True)
comparisons=[]
for rnd in (1,2):
 for name in PAGES:
  for f in FRAMES:
   paths=[E/f'final-native-round{rnd}'/b/name/f'f{f:04d}.png' for b in ('old','new')]
   pixels=[Image.open(p).convert('RGBA').tobytes() for p in paths]
   assert pixels[0]==pixels[1],(rnd,name,f)
   comparisons.append(dict(round=rnd,page=name,frame=f,png_sha256=[sha(p) for p in paths],rgba_sha256=hashlib.sha256(pixels[0]).hexdigest(),exact_rgba=True,png_bytes_equal=paths[0].read_bytes()==paths[1].read_bytes()))
(E/'final-rgba-comparisons.json').write_text(json.dumps(comparisons,indent=2))
summary=[]
for name in PAGES:
 old=[r for r in rows if r['backend']=='old' and r['page']==name];new=[r for r in rows if r['backend']=='new' and r['page']==name]
 ow=sum(r['wall_s'] for r in old);nw=sum(r['wall_s'] for r in new)
 summary.append(dict(page=name,old_wall_s=ow,new_wall_s=nw,speedup=ow/nw,old_fps=6/ow,new_fps=6/nw,old_child_user_s=sum(r['cpu_delta_s']['child_user'] for r in old),new_child_user_s=sum(r['cpu_delta_s']['child_user'] for r in new)))
(E/'final-native-summary.json').write_text(json.dumps({'scope':'two AB/BA rounds, same three original HTML pages, same 1920x1080 frames30/60/90, one worker; small sample includes startup and is not full-film throughput','results':summary,'exact_rgba_comparisons':len(comparisons),'all_png_bytes_equal':all(x['png_bytes_equal'] for x in comparisons)},indent=2))
print('ALL_DONE',flush=True)
