import json,hashlib,os
os.environ['VTX_GFX']='electron'
from vtx.gfx_backend import identity
s=identity();print(json.dumps(dict(identity=s,identity_sha256=hashlib.sha256(s.encode()).hexdigest()),indent=2))
