from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-20261017-codex');P=E.parent/'electron-perf-pipeline-20261017-codex';T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
for w in ('new','old'):
 for p in (T/'experiments/gfx_electron_worker').glob('test*'):shutil.copyfile(p,E/w/p.name)
 shutil.copytree(T/'experiments/gfx_electron_worker/pages',E/w/'pages')
s=(P/'tooling/run.py').read_text().replace(str(P),str(E)).replace("for p in ['home','tmp']", "for p in ['config','cache','tmp']").replace("HOME=str(E/'home'),", "XDG_CONFIG_HOME=str(E/'config'),XDG_CACHE_HOME=str(E/'cache'),")
(E/'tooling/run.py').write_text(s)
s=(P/'final_bench.py').read_text();start=s.index("WORKERS=");end=s.index('\nPAGES=',start)
s=s[:start]+"WORKERS={'old':E/'old','new':E/'new'}"+s[end:]
s=s.replace("x['page_error_fence_passed'] for", "x['page_error_fence_passed'] and x['png_decode_count']==6 for")
(E/'bench.py').write_text(s)
s=(P/'validation.py').read_text();start=s.index('T=Path(');end=s.index('\nSRC=',start)
s=s[:start]+"T=E/'new'\nOLD=E/'old'"+s[end:];s=s[:s.index('# Each injected worker')]
# alpha fixture remains independent context, create it before bench
s=s.replace("c=Ctx(E/'context/timeline.json')", "root=E/'context';root.mkdir(exist_ok=True)\n(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))\n(root/'page.html').write_text('<html></html>')\nc=Ctx(root/'timeline.json')")
(E/'alpha.py').write_text(s)
(E/'basic.py').write_text("""import os,sys,unittest
from pathlib import Path
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
ee.WORKER_DIR=E/'new'
os.environ.update(VTX_TEST_ELECTRON='1',VTX_ELECTRON_EVIDENCE_DIR=str(E/'basic'))
sys.path.insert(0,str(E/'new'))
import test_navigation as n
n.WORKER_DIR=E/'new'
suite=unittest.TestSuite(n.RealNavigationTests(x) for x in ('test_static_page_no_starvation_and_security','test_marker_dom_side_effect_is_rejected','test_marker_has_third_child_is_rejected','test_marker_occlusion_timeout'))
r=unittest.TextTestRunner(verbosity=2).run(suite)
assert r.wasSuccessful() and not r.skipped
""")
shutil.copyfile('/tmp/framivra-electron-encode-overlap-20261017/setup.py',E/'tooling/setup.py')
shutil.copyfile(__file__,E/'tooling/prepare.py')
