from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-20261017-codex')
(E/'negative.py').write_text('''import json,time,shutil,hashlib
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
page=E/'context/protocol.html';page.write_text('<style>html,body{margin:0;background:rgb(90,120,160)}</style>')
rows=[]
for op in ('a','aa'):
 w=E/('encode_error_'+op);shutil.copytree(E/'new',w)
 ee.WORKER_DIR=w
 ctx=SimpleNamespace(root=E/'context',cache=E/('negative_'+op)/'cache',out=E/('negative_'+op)/'out')
 control=ee.render_page(page,E/('negative_'+op)/'control',3,width=192,height=96,frames=[0,1,2],ctx=ctx,timeout_s=15)
 assert control['exit_code']==0 and control['failed']==[],control
 p=w/'navigation_worker.mjs';s=p.read_text();before="try { return decoder.decode(record.image.toPNG(),operation); }"
 assert s.count(before)==1;s=s.replace(before,"try { if (f===1 && operation==='"+op+"') throw Error('injected_encode_error'); return decoder.decode(record.image.toPNG(),operation); }")
 p.write_text(s)
 out=E/('negative_'+op)/'tampered';out.mkdir(parents=True)
 stale=out/'f0001.png';shutil.copyfile(E/('negative_'+op)/'control/f0001.png',stale);sha=hashlib.sha256(stale.read_bytes()).hexdigest()
 t=time.monotonic();st=ee.render_page(page,out,3,width=192,height=96,frames=[0,1,2],ctx=ctx,timeout_s=15)
 assert st['exit_code']==1 and st['failed']==[1] and st['rendered']==2,st
 assert hashlib.sha256(stale.read_bytes()).hexdigest()==sha
 assert not list((ctx.cache/'tmp').glob('*'))
 wall=time.monotonic()-t;assert wall<5,wall
 rows.append(dict(op=op,control=control,tampered=st,wall_s=wall,stale_unchanged=True,profile_clean=True))
 (E/'negative-results.json').write_text(json.dumps(rows,indent=2));print(op,wall,flush=True)
''')
w=E/'instrumented';shutil.copytree(E/'new',w)
p=w/'navigation_worker.mjs';s=p.read_text()
s=s.replace("const delay = ms", "function trace(event,extra={}) { fs.appendFileSync("+repr(str(E/'trace.jsonl'))+",JSON.stringify({t:Date.now(),event,...extra})+'\\n'); }\nconst delay = ms")
s=s.replace("try { return decoder.decode(record.image.toPNG(),operation); }", "try { trace('encode_start',{f,operation}); const png=record.image.toPNG(); trace('encode_end',{f,operation}); return decoder.decode(png,operation); }")
s=s.replace("const ready = active; active = null;", "const ready = active; active = null; trace('accepted',{f,operation:ready.operation});")
s=s.replace("      await isolated(wc, `${checkDocumentCode(expectedUrl,f)};", "      trace('send',{f,operation});\n      const rendererAt = await isolated(wc, `${checkDocumentCode(expectedUrl,f)};",1)
s=s.replace("        })()`);\n      wc.invalidate();", "          return Date.now();\n        })()`);\n      trace('installed_reply',{f,operation,rendererAt});\n      wc.invalidate();",1)
s=s.replace("try { baselinePending = decoder.decode(baselineImage.toPNG(),'baseline'); }", "try { trace('encode_start',{f,operation:'baseline'}); const png=baselineImage.toPNG(); trace('encode_end',{f,operation:'baseline'}); baselinePending = decoder.decode(png,'baseline'); }")
p.write_text(s)
(E/'diagnostic.py').write_text('''import json
from pathlib import Path
from vtx import gfx_electron as ee
from vtx.infra import Ctx
E=Path(__file__).resolve().parent;ee.WORKER_DIR=E/'instrumented'
st=ee.render_page(Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx/open_source_card.html'),E/'diagnostic',91,width=1920,height=1080,frames=[30,60,90],ctx=Ctx(E/'context/timeline.json'),timeout_s=15)
(E/'diagnostic-result.json').write_text(json.dumps(st,indent=2));assert st['exit_code']==0,st
''')
shutil.copyfile(__file__,E/'tooling/prepare_finish.py')
