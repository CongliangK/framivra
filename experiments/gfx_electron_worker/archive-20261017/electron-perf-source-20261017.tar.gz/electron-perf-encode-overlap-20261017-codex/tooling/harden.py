from pathlib import Path
import shutil,json,hashlib,difflib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-20261017-codex');shutil.copytree(E/'new',E/'new-v2');p=E/'new-v2/navigation_worker.mjs';s=p.read_text()
s=s.replace('  const retained = new Set(), pendingWitnesses = new Set();',"  const retained = new Set(), pendingWitnesses = new Set();\n  let cancelInstallation;\n  const cancelled = new Promise((_,reject) => { cancelInstallation=reject; });\n  cancelled.catch(() => {});")
s=s.replace("      await isolated(wc, `${checkDocumentCode(expectedUrl,f)};", "      await Promise.race([isolated(wc, `${checkDocumentCode(expectedUrl,f)};",1)
s=s.replace("        })()`);\n      wc.invalidate();", "        })()`),cancelled]);\n      wc.invalidate();",1)
s=s.replace("    active?.reject(Error('capture_cancelled')); active = null;", "    cancelInstallation(Error('capture_cancelled'));\n    active?.reject(Error('capture_cancelled')); active = null;")
p.write_text(s)
(E/'v2.diff').write_text(''.join(difflib.unified_diff((E/'old/navigation_worker.mjs').read_text().splitlines(True),s.splitlines(True),fromfile='old/navigation_worker.mjs',tofile='new-v2/navigation_worker.mjs')))
(E/'v2-sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (E/'new-v2').glob('*.mjs')},indent=2))
s=(E/'negative.py').read_text().replace("E/'new'","E/'new-v2'").replace("'encode_error_'","'v2_encode_error_'").replace("'negative_'","'v2_negative_'").replace("'negative-results.json'","'v2-negative-results.json'")
(E/'negative_v2.py').write_text(s);shutil.copyfile(__file__,E/'tooling/harden.py')
