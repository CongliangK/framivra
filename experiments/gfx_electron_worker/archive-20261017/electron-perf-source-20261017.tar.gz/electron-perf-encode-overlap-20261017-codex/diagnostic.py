import json
from pathlib import Path
from vtx import gfx_electron as ee
from vtx.infra import Ctx
E=Path(__file__).resolve().parent;ee.WORKER_DIR=E/'instrumented'
st=ee.render_page(Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx/open_source_card.html'),E/'diagnostic',91,width=1920,height=1080,frames=[30,60,90],ctx=Ctx(E/'context/timeline.json'),timeout_s=15)
(E/'diagnostic-result.json').write_text(json.dumps(st,indent=2));assert st['exit_code']==0,st
