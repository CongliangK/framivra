import json,time,shutil,hashlib
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
page=E/'context/protocol.html';page.write_text('<style>html,body{margin:0;background:rgb(90,120,160)}</style>')
rows=[]
for op in ('a','aa'):
 w=E/('v2_encode_error_'+op);shutil.copytree(E/'new-v2',w)
 ee.WORKER_DIR=w
 ctx=SimpleNamespace(root=E/'context',cache=E/('v2_negative_'+op)/'cache',out=E/('v2_negative_'+op)/'out')
 control=ee.render_page(page,E/('v2_negative_'+op)/'control',3,width=192,height=96,frames=[0,1,2],ctx=ctx,timeout_s=15)
 assert control['exit_code']==0 and control['failed']==[],control
 p=w/'navigation_worker.mjs';s=p.read_text();before="try { return decoder.decode(record.image.toPNG(),operation); }"
 assert s.count(before)==1;s=s.replace(before,"try { if (f===1 && operation==='"+op+"') throw Error('injected_encode_error'); return decoder.decode(record.image.toPNG(),operation); }")
 p.write_text(s)
 out=E/('v2_negative_'+op)/'tampered';out.mkdir(parents=True)
 stale=out/'f0001.png';shutil.copyfile(E/('v2_negative_'+op)/'control/f0001.png',stale);sha=hashlib.sha256(stale.read_bytes()).hexdigest()
 t=time.monotonic();st=ee.render_page(page,out,3,width=192,height=96,frames=[0,1,2],ctx=ctx,timeout_s=15)
 assert st['exit_code']==1 and st['failed']==[1] and st['rendered']==2,st
 assert hashlib.sha256(stale.read_bytes()).hexdigest()==sha
 assert not list((ctx.cache/'tmp').glob('*'))
 wall=time.monotonic()-t;assert wall<5,wall
 rows.append(dict(op=op,control=control,tampered=st,wall_s=wall,stale_unchanged=True,profile_clean=True))
 (E/'v2-negative-results.json').write_text(json.dumps(rows,indent=2));print(op,wall,flush=True)
