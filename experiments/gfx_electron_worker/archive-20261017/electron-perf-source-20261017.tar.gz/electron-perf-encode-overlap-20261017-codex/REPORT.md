# EE-PERF-9 single-document encode/renderer overlap

Decision: REJECTED_NO_PERFORMANCE_GAIN. No production edit or adoption. Frozen repository remains clean at d32310853d6136f3f621a356b0c2718c7fab1a25. No full-film restart, PR/push/merge, network/install, dependency manifest write, next-document prefetch, extra renderer, or additional thread. Writes restricted to this E and /tmp/framivra-electron-encode-overlap-20261017. Native execution is complete; every job exit was reaped. Native process scan found no remaining experiment worker.

## Experiment and source custody

Original attached handoff, frozen AGENTS.md/docs/DEV.md, pipeline REPORT, and SDK REPORT were read. SDK lifetime conclusion independently checked against downloaded originals: OSR OnPaint626–643 creates fresh SkBitmap+allocN32Pixels+readPixels; WebContents OnPaint4296–4314 wraps CreateFrom1xBitmap; NativeImage159–163 copies gfx::Image; Chromium ImageSkiaRep31–39 copies bitmap_(src) and setImmutable; SkBitmap.cpp45 shares fPixelRef. This supports strong NativeImage ownership of each independent immutable paint allocation on the host thread. It does not make getBitmap zero-copy, permit mutation, or authorize reuse of cached PNG across operations/images. Evidence home: ../electron-perf-sdk-research-20261017-codex/REPORT.md (SHA fa6f89c640bba014c88577c85e8ce508be87a59cadf0b445090b38581defe28a), plus its raw sources and source-fetch/frozen hashes. SDK executable SHA433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f was verified by each runner.

old/ copies frozen d323 worker/gate/codec. new/ v1 alters only navigation_worker.mjs scheduling: accepted paint copies full bitmap/checks geometry+nonce, returns strong image; send A then encode/decode baseline, send B then encode/decode A, B encode/decode before original40ms, capture AA then send BB then encode/decode AA, finally encode/decode BB. All full comparisons, native reconstruction+sixth decode, final document/resource/error fences and atomic publication stay. Original six-op baseline/a/b/aa/bb/final order, four nonce ABAB, baseline veto-only, fresh per-frame BrowserWindow/document,60Hz,b0,100ms quiet,15s watchdog preserved. Images cleared immediately after toPNG in finally, retained set cleared on errors. No getBitmap or transfer of image/bitmap.

v1 full worker SHA 04b3ffa83b8b018fa5b804363e7283fca17a2ae0ce7d0df976615b6348334e6f; old worker 779cef67cf9e0a848afb6f0f08e797b77dfcc1386b2cbc9ce1de084c7810d5e2; codec unchanged 9a8a4cc448dccfc0d541f56977150272a058d61adba1cbf0d2cb50c9c13c2142; gate unchanged baec46139eeba8f0c52488018d71867d4b8c07bfd104d2b6d20eb688aef49425. Full reconstructable sources are in old/,new/; exact scheduling diff candidate.diff and frozen-sha256.json were saved BEFORE native execution.

## Controlled uninstrumented AB/BA36 (v1 only)

Root read-only bwrap, private net/PID/dev/physical temporary directory, X11socket read-only, only this E writable; HOME inherited unchanged, XDG_CONFIG_HOME/CACHE_HOME point inside E. Actual command/env saved *.command.json. No GPU/Wayland; DISPLAY=:0, verified XAUTHORITY; single worker/PAGES1/b0/15s/1920x1080. Same three real read-only HTML sources and frames30,60,90, new profile/output each render; AB then BA,18 frames per side including startup. OS/font caches not cleared; not physical disk cold.

| page | old fps | new fps | speedup |
|---|---:|---:|---:|
| nav_two_pillars |1.99228|1.99194|0.999826x|
| open_source_card |1.68256|1.59356|0.947100x|
| u2_backends |2.02560|2.06028|1.017122x|

Aggregate old 9.539699316s → new 9.689536501s = 0.984536x, approximately1.57% slower. 18/18 paired PNG bytes and full decoded RGBA identical, all actual receipts four witnesses/six decode. See final-native-results.json/final-rgba-comparisons.json/final-native-summary.json/aggregate.json. old/new paints 221/222, rejected paints 72/72. Observed child user 6.623730/6.592094s, child system 3.881217/3.962684s. Full self/child breakdown in aggregate.json. rusage may miss non-parent-reaped renderer descendants; not complete tree CPU. No tree RSS measurement.

## Correctness controls and actual failure

basic.py real four tests: static/security control, marker DOM side effect veto, third-child :has veto, occlusion timeout;4/4 PASS,0skip,2.733s. alpha.py real1080 fixture f0/1/3 with5000 alpha128 pixels per frame: PNG and fullRGBA exactly equal; g6a_title f0/1/3 also equal but opaque and explicitly not fractional-alpha coverage. See alpha-comparisons.json.

v1 pending-witness cleanup had an actual FAIL, retained in negative.py.log, exit1: injected A encode throw with B installation already pending left executeJavaScriptInIsolatedWorld unresolved after window destruction. Rejecting captured plus closing/destroying was insufficient; finally allSettled waited until whole-frame watchdog exit72 at15.397s, no f2. Existing prewritten f1 PNG was not overwritten. Adapter correctly treated the entire incomplete run as failed, despite raw f0 having published. This source must not be adopted.

A separate new-v2/ adds explicit rejected cancellation Promise raced with the isolated installation await. Finally cancels installation BEFORE active rejection/window destruction; witness finally clears interval and deadline finally clears timer; all pending witness promises are awaited before decoder.drain. Cancellation handlers attach from creation. Full diff v2.diff, v2-sha256.json; worker SHA a4db83cd1cbc5b193123a564aa281146013055ee8beefff708dbabf07bac742c. Successful scheduling is unchanged by construction but no v2 throughput/equivalence acceptance is claimed.

negative_v2.py: for both A→B and AA→BB encode throw cases, first genuine three-frame control rc0, then tamper fails onlyf1 with injected_encode_error, preserves stale PNG byte-SHA, succeeds f0/f2, leaves cache/tmp empty. Tampered run wall0.724/0.823s, rc1, no15s watchdog. See v2-negative-results.json, full mutant sources under v2_encode_error_*/. Native worker/gate cleanup and later-frame isolation passed this targeted counterexample.

## Instrumented explanation (v1 diagnostic, separate from benchmark)

diagnostic.py real open_source_card f30/60/90 rc0, separate instrumented/ sources. trace.jsonl records host Date.now send/encode/accepted and renderer Date.now immediately after installing marker. All nine relevant renderer installation-complete timestamps occur at or AFTER previous encode_end (millisecond precision). Example f30 sendA4788, encode4788..4807, renderer installation4811; sendB4835, encode4835..4853, renderer4854 (common leading179222562 omitted). Thus the intended host-send-first schedule did not demonstrate renderer work overlapped with synchronous encode. This supports a scheduling/IPC-delivery limitation, not proof of Chromium's precise flush internals or a general impossibility result. Only task instrumentation, no production metrics in formal benchmark.

## Scope and exits

User performance target remains same-method single-worker aggregate elapsed <=fresh CEF1.25, all correctness gates unchanged. This direction has no significant speedup, so stopped before450-frame stress, full46 regression, fractional original e1/llm/w_title matrix, or freshCEF qualification. No performance PASS, final candidate admission, stable full regression, image retention stress or full-tree memory proof is claimed. v2 only fixes cleanup counterexample; not selected for integration. Follow-up setImmediate-yield scheduling would be a new variant requiring controller direction; not run.

Command exits (all personally reaped): {"basic.py.exit.json": 0, "alpha.py.exit.json": 0, "bench.py.exit.json": 0, "negative.py.exit.json": 1, "negative_v2.py.exit.json": 0, "diagnostic.py.exit.json": 0}. setup/prepare/prepare_finish/harden/source inspections each exited0. Failed negative v1 is preserved, not relabeled. Full actual invocations in tooling/, *.command.json, *.log, *.exit.json. Source v1 stayed frozen throughout its benchmark; v2 and diagnostics are independent copies. Repository git status --short empty and HEAD d323... verified after native jobs. End of experiment; no further source writes.
