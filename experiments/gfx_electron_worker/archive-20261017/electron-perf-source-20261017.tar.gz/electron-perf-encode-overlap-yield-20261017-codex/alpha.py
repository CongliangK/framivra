import os,json,hashlib,shutil,time
from pathlib import Path
from PIL import Image
from vtx import gfx_electron as ee
from vtx.infra import Ctx
E=Path(__file__).resolve().parent
T=E/'yield1'
OLD=E/'old'
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
root=E/'context';root.mkdir(exist_ok=True)
(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))
(root/'page.html').write_text('<html></html>')
c=Ctx(root/'timeline.json')
fixture=E/'context/alpha128.html';fixture.write_text('<!doctype html><style>html,body{margin:0;background:transparent}div{position:absolute;left:50px;top:20px;width:100px;height:50px;background:rgba(200,100,40,0.5019607843137255)}</style><div></div>')
rows=[]
for label,page,frames in [('fade',SRC/'g6a_title.html',[0,1,3]),('alpha128',fixture,[0,1,3])]:
 for backend,worker in [('old',OLD),('new',T)]:
  ee.WORKER_DIR=worker;out=E/'alpha'/label/backend
  st=ee.render_page(page,out,4,width=1920,height=1080,frames=frames,ctx=c,timeout_s=15)
  assert st['exit_code']==0 and st['failed']==[],st
 for f in frames:
  paths=[E/'alpha'/label/b/f'f{f:04d}.png' for b in ('old','new')];ims=[Image.open(p).convert('RGBA') for p in paths];pixels=[im.tobytes() for im in ims]
  assert pixels[0]==pixels[1];assert paths[0].read_bytes()==paths[1].read_bytes()
  if label=='alpha128':assert ims[1].getpixel((90,48))[3]==128
  rows.append(dict(label=label,frame=f,source_sha256=hashlib.sha256(page.read_bytes()).hexdigest(),png_equal=True,rgba_equal=True,alpha_extrema=ims[1].getchannel('A').getextrema(),alpha128_count=sum(a==128 for a in ims[1].getchannel('A').tobytes()),rgba_sha256=hashlib.sha256(pixels[1]).hexdigest()))
(E/'alpha-comparisons.json').write_text(json.dumps(rows,indent=2))
