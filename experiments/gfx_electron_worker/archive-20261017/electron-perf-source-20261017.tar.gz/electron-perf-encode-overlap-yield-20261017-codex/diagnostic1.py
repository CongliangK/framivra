import json,time,resource
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
rows=[]
for label in ('old','yield1'):
 ee.WORKER_DIR=E/('instrumented-'+label);ctx=SimpleNamespace(root=E,cache=E/'context'/label/'cache',out=E/'context'/label/'out')
 start=time.perf_counter()
 st=ee.render_page(Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx/open_source_card.html'),E/('diagnostic-'+label),91,width=1920,height=1080,frames=[30,60,90],ctx=ctx,timeout_s=15)
 rows.append(dict(label=label,wall_s=time.perf_counter()-start,result=st));(E/'diagnostic1-results.json').write_text(json.dumps(rows,indent=2));assert st['exit_code']==0,st
