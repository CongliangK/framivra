import os,sys,unittest
from pathlib import Path
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
ee.WORKER_DIR=E/'ackyield'
os.environ.update(VTX_TEST_ELECTRON='1',VTX_ELECTRON_EVIDENCE_DIR=str(E/'ack-basic'))
sys.path.insert(0,str(E/'ackyield'))
import test_navigation as n
n.WORKER_DIR=E/'ackyield'
suite=unittest.TestSuite(n.RealNavigationTests(x) for x in ('test_static_page_no_starvation_and_security','test_marker_dom_side_effect_is_rejected','test_marker_has_third_child_is_rejected','test_marker_occlusion_timeout'))
r=unittest.TextTestRunner(verbosity=2).run(suite)
assert r.wasSuccessful() and not r.skipped
