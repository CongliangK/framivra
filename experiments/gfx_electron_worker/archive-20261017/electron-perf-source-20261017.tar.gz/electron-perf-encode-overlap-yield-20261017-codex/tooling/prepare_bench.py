from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex');P=E.parent/'electron-perf-encode-overlap-20261017-codex'
for name in ('bench.py','alpha.py','basic.py'):
 s=(P/name).read_text().replace("E/'new'","E/'yield1'");(E/name).write_text(s)
shutil.copyfile(__file__,E/'tooling/prepare_bench.py')
