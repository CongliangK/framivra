from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex')
for n in ('basic','alpha','bench'):
 s=(E/(n+'.py')).read_text().replace("E/'yield1'","E/'ackyield'")
 if n=='basic':s=s.replace("E/'basic'","E/'ack-basic'")
 if n=='alpha':s=s.replace("E/'alpha'","E/'ack-alpha'").replace('alpha-comparisons.json','ack-alpha-comparisons.json')
 if n=='bench':s=s.replace('final-native','ack-final-native').replace('final-rgba','ack-final-rgba')
 (E/('ack_'+n+'.py')).write_text(s)
# same existing v2 cleanup negatives, both next-witness pending boundaries
P=E.parent/'electron-perf-encode-overlap-20261017-codex'
s=(P/'negative_v2.py').read_text().replace("E/'new-v2'","E/'ackyield'").replace('v2_encode_error_','ack_encode_error_').replace('v2_negative_','ack_negative_').replace('v2-negative-results.json','ack-negative-results.json')
(E/'ack_negative.py').write_text(s)
shutil.copyfile(__file__,E/'tooling/prepare2.py')
