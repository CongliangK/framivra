from pathlib import Path
import json,hashlib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex');summary={}
for variant,prefix in [('yield1',''),('ackyield','ack-')]:
 rows=json.loads((E/(prefix+'final-native-results.json')).read_text());r={}
 for b in ('old','new'):
  rs=[x for x in rows if x['backend']==b];r[b]=dict(wall_s=sum(x['wall_s'] for x in rs),cpu_s={k:sum(x['cpu_delta_s'][k] for x in rs) for k in rs[0]['cpu_delta_s']},paints=sum(f['paints'] for x in rs for f in x['frame_receipts']),rejected=sum(f['rejected_paints'] for x in rs for f in x['frame_receipts']))
 r['speedup']=r['old']['wall_s']/r['new']['wall_s'];r['wall_reduction']=1-r['new']['wall_s']/r['old']['wall_s'];summary[variant]=r
(E/'aggregate.json').write_text(json.dumps(summary,indent=2));trace_rows=[]
for label in ('yield1','ackyield'):
 trace=[json.loads(x) for x in (E/(label+'-trace.jsonl')).read_text().splitlines()]
 for f in (30,60,90):
  for nextop,prev in (('a','baseline'),('b','a'),('bb','aa')):
   ev=[x for x in trace if x['f']==f];r=next(x for x in ev if x['event']=='installed_reply' and x['operation']==nextop);es=next(x['t'] for x in ev if x['event']=='encode_start' and x['operation']==prev);ee=next(x['t'] for x in ev if x['event']=='encode_end' and x['operation']==prev);inv=next(x['t'] for x in ev if x['event']=='invalidated' and x['operation']==nextop);paint=next(x['t'] for x in ev if x['event']=='accepted' and x['operation']==nextop)
   trace_rows.append(dict(variant=label,frame=f,next=nextop,previous=prev,encode_start=es,encode_end=ee,renderer_installed=r['rendererAt'],host_invalidated=inv,accepted_native=paint,renderer_before_encode_end=r['rendererAt']<ee,renderer_inside_encode=es<=r['rendererAt']<ee,accepted_before_or_same_start=paint<=es))
(E/'trace-analysis.json').write_text(json.dumps(trace_rows,indent=2));(E/'command-exit-ledger.json').write_text(json.dumps({p.name:json.loads(p.read_text())['exit_code'] for p in E.glob('*.exit.json')},indent=2))
print(json.dumps(summary,indent=2))
