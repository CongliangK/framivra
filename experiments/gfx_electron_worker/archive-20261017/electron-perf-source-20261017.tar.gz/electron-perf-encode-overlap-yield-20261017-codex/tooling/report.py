from pathlib import Path
import json,hashlib,shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex');s=json.loads((E/'aggregate.json').read_text());p=json.loads((E/'source2-sha256.json').read_text());ledger=json.loads((E/'command-exit-ledger.json').read_text())
# all frozen runtime copies verified against pre-native source manifests
for file,expected in p.items():assert hashlib.sha256((E/file).read_bytes()).hexdigest()==expected,file
for file,expected in json.loads((E/'source-sha256.json').read_text()).items():assert hashlib.sha256((E/file).read_bytes()).hexdigest()==expected,file
(E/'REPORT.md').write_text(f'''# EE-PERF-9B bounded yield variants

Outcome: REAL_RENDERER_OVERLAP_CONFIRMED / MODEST_GAIN / NO_PRODUCTION_ADMISSION. Two authorized minimal variants completed; no further yield/timeout tuning. Neither has measured freshCEF qualification or full46/450 acceptance. Recommendation to controller: stop this direction as the measured4.5–6.7% speedups do not close the known historical gap. This is not a formal target FAIL against an unmeasured freshCEF. Native windows released; all jobs personally reaped; no production wiring, full-film, PR, git write, install, network, SDK fork, recursive agent, or repository changes.

User target remains same-method single-worker total elapsed <=freshCEF1.25 with every correctness hard gate unchanged. Evidence is written only here and /tmp/framivra-electron-encode-overlap-yield-20261017; prior E frozen/read-only. Repo clean@d32310853d6136f3f621a356b0c2718c7fab1a25 verified after runs.

## Frozen sources and minimal changes

old/ is original d323 worker+gate+codec (not prior cleanup-v2). yield1/ starts from prior E new-v2 cancellation mechanism and adds exactly one setImmediate Promise-raced with cancellation immediately after send-next-witness at baseline→A, A→B, AA→BB, before prior NativeImage.toPNG. ackyield/ starts from the same v2, waits a dedicated installation-ack Promise resolved AFTER wc.invalidate/interval creation, then exactly one setImmediate before prior toPNG. The installation acknowledgement is not captured paint; code does not await next paint before encoding prior image. Installed/rejected/cancel promises all attach handlers from creation; installed await races same cancellation; full-frame15s watchdog bounds extra awaits. Pending witness installation cancellation in finally precedes active rejection/window destruction, allSettled and decoder drain.

Original six native PNG encode/decode baseline/a/b/aa/bb/final, fullRGBA equality and baseline-only veto, four random nonce ABAB, fresh single BrowserWindow/document per frame, mode/imagepolicy60Hz/b0,100ms resource quiet,40ms delay AFTER B encode, JS/Promise/child gates/final document+resource fence/atomic publish stay intact. No image/bitmap transfer/getBitmap, no cached PNG reuse. Per-image strong reference cleared immediately after its toPNG, error cleanup clears all retained images. Ownership source proof home remains ../electron-perf-sdk-research-20261017-codex/REPORT.md and originals, independently read in EE-PERF-9; no new unsupported lifetime assumption.

Source snapshots and exact diffs saved before native: yield1.diff,ackyield.diff,source-sha256.json,source2-sha256.json. All source manifests reverified unchanged at report generation. Worker SHA old {p['old/navigation_worker.mjs']}; yield1 {p['yield1/navigation_worker.mjs']}; ackyield {p['ackyield/navigation_worker.mjs']}. Gate and codec unchanged. Full sources retained in old/,yield1/,ackyield/ and independent instrumented-*/negative mutant directories.

## Actual diagnostic scheduling

Each diagnostic compared old/new cold open_source_card1080 frames30/60/90 with the same trace events and synchronous append mechanism, in isolated copies; instrumented throughput is not acceptance. Native toPNG start/end (all6), witness send, renderer Date.now immediately after marker draw, installation reply, wc.invalidate, accepted nonce paint are recorded. Old accepted event is after its synchronous encode; new accepted event before deferred encode, so it is a logical accepted callback point, not a universal callback-entry timestamp. Renderer/host Date.now are millisecond precision on the same host; no submillisecond inference.

yield1: old1.833863s/new1.631704s,rc0. All9/9 renderer installation timestamps fall INSIDE prior encode interval and strictly before encode_end. Example f30 sendA5660/encode5660..5679/renderer5664; sendB5689/encode5689..5707/renderer5689; BB5787/encode5787..5805/renderer5788 (common leading179222580 omitted). Host invalidate remains after encode because host callback is blocked. This is actual renderer JS work overlap, not merely static send-first code. See yield1-trace.jsonl/diagnostic1-results.json.

ackyield: old1.784032s/new1.680769s,rc0. All9/9 renderer installations complete before prior encode_start, and all9 wc.invalidate calls execute before or at encode_start. In7/9 transitions accepted nonce paint happens after encode_start; in2/9 (BB f60/f90) paint accepted in the same millisecond as encode_start, so cannot claim compositor/paint overlap for those2. No explicit paint await exists at these boundaries; those paints arrived during the one host yield. Example f30 baseline encode starts3ms after renderer installation/at invalidate, accepted26ms after encode start. Complete exact timeline in trace-analysis.json/ackyield-trace.jsonl. Marker-install completion before encode alone does not prove all raster time overlapped; timing scope is stated explicitly.

## Two independent uninstrumented AB/BA36 comparisons

Both use rootRO bwrap/private network+PID+dev/physical temporary directory/X11socket RO/only this E RW, HOME inherited unchanged and XDG_CONFIG_HOME/CACHE_HOME inside E. SDK hash433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f verified by runner; DISPLAY=:0/XAUTHORITY verified, no Wayland/GPU. Singleworker/PAGES1/b0/native_toPNG/15s/1920x1080; same three real read-only original experimental HTML pages,frames30/60/90; new cold profile/output per render,AB thenBA,18frames per side including startup. OS/font caches not physically cleared.

| variant/page | old fps | new fps | speedup |
|---|---:|---:|---:|
| yield1 nav |2.02622|2.09795|1.03540x|
| yield1 open |1.68468|1.81242|1.07582x|
| yield1 u2 |2.09741|2.13570|1.01826x|
| ackyield nav |1.99219|2.06093|1.03451x|
| ackyield open |1.68414|1.81132|1.07552x|
| ackyield u2 |1.99090|2.17183|1.09088x|

Aggregate yield1 old{s['yield1']['old']['wall_s']:.9f}→new{s['yield1']['new']['wall_s']:.9f}s = {s['yield1']['speedup']:.6f}x,4.300% wall reduction. ackyield old{s['ackyield']['old']['wall_s']:.9f}→new{s['ackyield']['new']['wall_s']:.9f}s = {s['ackyield']['speedup']:.6f}x,6.275% wall reduction. Their new-side wall totals are effectively similar; different contemporaneous baselines forbid claiming ackyield definitively faster than yield1. No statistical significance beyond these small cold paired samples is claimed.

Each formal comparison18/18 PNG bytes AND independently decoded fullRGBA exact, raw receipts four witnesses/six decode/full hard fences. Total36 paired comparisons across both variants. See final-native-*/final-rgba-comparisons.json and ack-final-native-*/ack-final-rgba-comparisons.json. No instrumentation in either formal source.

CPU and paints: yield1 old/new observed child user6.272872/6.519850s,system3.689976/3.772193s,paints221/220,rejected72/73. ackyield user6.594552/5.960475s,system3.899563/3.734754s,paints219/219,rejected72/72. Full Python self/child breakdown in aggregate.json. rusage excludes possible non-parent-reaped descendants, not full-tree CPU; no complete-tree RSS proof. Timing not enough to attribute CPU delta causally.

## Correctness controls and cleanup counterexamples

For each variant separately: basic4/4 real tests0skip (static/security, marker-side-effect veto,thirdchild :has veto,marker occlusion timeout) rc0. Independently paired128alpha fixture f0/1/3 each5000alpha128 pixels1080, PNG/fullRGBA byte-exact; g6a_title f0/1/3 also exact but opaque and not fractional-alpha coverage. alpha-comparisons.json and ack-alpha-comparisons.json retain outputs/statistics. Actual fixtures/pages never edited during jobs.

ack_negative.py: A and AA encode failure injection after the next B/BB installed Promise has been started; each first genuine3-frame control rc0, then f1-only injected encode throw. Both tampered rc1 with f0/f2 successful, stalef1PNG SHA unchanged, profile/cachetmp empty; totalwall0.824/0.825s, no watchdog hang. Sources preserved in ack_encode_error_*/; ack-negative-results.json. yield1 inherited explicit v2 cancellation, but no yield1-specific encode-error injection was run; do not promote ackyield test to universal cleanup proof.

All native commands exited0 at harness level: {json.dumps(ledger)}. Internal deliberately failed frames are correctly rc1, not harness errors. setup/setup2/prepare scripts/summarize/report exited0. Exact argv/env each *.command.json; logs/exit ledgers retained. The prior E v1 cleanup FAIL remains untouched and is not relabeled.

## Deliberately unrun and release boundary

No original fractional e1/llm/w_title matrix,full46,450-frame complete-tree RSS/CPU tail stress,freshCEF,independent review or production admission. Small gain is real in these samples but insufficient evidence that total target can be reached; no target PASS or impossible claim. As controller requested at most two variants, no further yield schedules or timeout adjustments attempted. Both have snapshots for possible later review, but neither is integrated or recommended as production-ready. All workers/windows have exited and sources remain frozen for controller decision.
''')
for name in ('summarize.py','report.py'):shutil.copyfile(Path(__file__).parent/name,E/'tooling'/name)
print(hashlib.sha256((E/'REPORT.md').read_bytes()).hexdigest())
