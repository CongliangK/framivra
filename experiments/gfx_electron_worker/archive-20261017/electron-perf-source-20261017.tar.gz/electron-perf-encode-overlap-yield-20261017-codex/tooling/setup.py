from pathlib import Path
import shutil,json,hashlib,difflib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex');P=E.parent/'electron-perf-encode-overlap-20261017-codex'
E.mkdir();(E/'tooling').mkdir()
shutil.copytree(P/'old',E/'old');shutil.copytree(P/'new-v2',E/'yield1')
p=E/'yield1/navigation_worker.mjs';s=p.read_text()
for line in ("    const aPending = beginWitness('a','a');", "    const bPending = beginWitness('b','b');", "    const bbPending = beginWitness('b','bb');"):
 assert s.count(line)==1;s=s.replace(line,line+"\n    await Promise.race([new Promise(resolve => setImmediate(resolve)),cancelled]);")
p.write_text(s)
(E/'yield1.diff').write_text(''.join(difflib.unified_diff((E/'old/navigation_worker.mjs').read_text().splitlines(True),s.splitlines(True),fromfile='old/navigation_worker.mjs',tofile='yield1/navigation_worker.mjs')))
for label in ('old','yield1'):
 w=E/('instrumented-'+label);shutil.copytree(E/label,w);p=w/'navigation_worker.mjs';s=p.read_text()
 s=s.replace('const delay = ms',"function trace(event,extra={}) { fs.appendFileSync("+repr(str(E/(label+'-trace.jsonl')))+",JSON.stringify({t:Date.now(),event,...extra})+'\\n'); }\nconst delay = ms")
 # trace accepted before encoding, and all six native operations identically
 s=s.replace("      const png = image.toPNG();", "      trace('encode_start',{f,operation:active.operation}); const png = image.toPNG(); trace('encode_end',{f,operation:active.operation});")
 s=s.replace("      const ready = active; active = null;", "      const ready = active; active = null; trace('accepted',{f,operation:ready.operation});")
 s=s.replace("try { return decoder.decode(record.image.toPNG(),operation); }", "try { trace('encode_start',{f,operation}); const png=record.image.toPNG(); trace('encode_end',{f,operation}); return decoder.decode(png,operation); }")
 s=s.replace("    const baselinePending = decoder.decode(baselineImage.toPNG(),'baseline');", "    trace('encode_start',{f,operation:'baseline'}); const baselinePng=baselineImage.toPNG(); trace('encode_end',{f,operation:'baseline'}); const baselinePending = decoder.decode(baselinePng,'baseline');")
 s=s.replace("try { baselinePending = decoder.decode(baselineImage.toPNG(),'baseline'); }", "try { trace('encode_start',{f,operation:'baseline'}); const png=baselineImage.toPNG(); trace('encode_end',{f,operation:'baseline'}); baselinePending = decoder.decode(png,'baseline'); }")
 s=s.replace("    const png = rebuilt.toPNG();", "    trace('encode_start',{f,operation:'final'}); const png=rebuilt.toPNG(); trace('encode_end',{f,operation:'final'});")
 if label=='old':
  s=s.replace("      await isolated(wc, `${checkDocumentCode(expectedUrl,f)};", "      trace('send',{f,operation}); const rendererAt = await isolated(wc, `${checkDocumentCode(expectedUrl,f)};",1)
  s=s.replace("        })()`);\n      wc.invalidate();", "          return Date.now();\n        })()`);\n      trace('installed_reply',{f,operation,rendererAt});\n      wc.invalidate();",1)
 else:
  s=s.replace("      await Promise.race([isolated(wc, `${checkDocumentCode(expectedUrl,f)};", "      trace('send',{f,operation}); const rendererAt = await Promise.race([isolated(wc, `${checkDocumentCode(expectedUrl,f)};",1)
  s=s.replace("        })()`),cancelled]);\n      wc.invalidate();", "          return Date.now();\n        })()`),cancelled]);\n      trace('installed_reply',{f,operation,rendererAt});\n      wc.invalidate();",1)
 s=s.replace("      wc.invalidate(); // Critical", "      wc.invalidate(); trace('invalidated',{f,operation}); // Critical")
 p.write_text(s)
(E/'source-sha256.json').write_text(json.dumps({str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for label in ('old','yield1','instrumented-old','instrumented-yield1') for p in (E/label).glob('*.mjs')},indent=2))
s=(P/'tooling/run.py').read_text().replace(str(P),str(E));(E/'tooling/run.py').write_text(s)
(E/'diagnostic1.py').write_text('''import json,time,resource
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
rows=[]
for label in ('old','yield1'):
 ee.WORKER_DIR=E/('instrumented-'+label);ctx=SimpleNamespace(root=E,cache=E/'context'/label/'cache',out=E/'context'/label/'out')
 start=time.perf_counter()
 st=ee.render_page(Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx/open_source_card.html'),E/('diagnostic-'+label),91,width=1920,height=1080,frames=[30,60,90],ctx=ctx,timeout_s=15)
 rows.append(dict(label=label,wall_s=time.perf_counter()-start,result=st));(E/'diagnostic1-results.json').write_text(json.dumps(rows,indent=2));assert st['exit_code']==0,st
''')
shutil.copyfile(__file__,E/'tooling/setup.py')
