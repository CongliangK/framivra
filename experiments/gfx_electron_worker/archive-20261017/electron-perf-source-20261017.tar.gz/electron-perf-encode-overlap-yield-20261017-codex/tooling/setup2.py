from pathlib import Path
import shutil,json,hashlib,difflib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-encode-overlap-yield-20261017-codex');P=E.parent/'electron-perf-encode-overlap-20261017-codex'
shutil.copytree(P/'new-v2',E/'ackyield');p=E/'ackyield/navigation_worker.mjs';s=p.read_text()
s=s.replace("    const pending = witness(phase,operation);\n    pending.catch(() => {});", "    let resolveInstalled, rejectInstalled;\n    const installed = new Promise((resolve,reject) => { resolveInstalled=resolve; rejectInstalled=reject; });\n    installed.catch(() => {});\n    const pending = witness(phase,operation,resolveInstalled);\n    pending.catch(rejectInstalled);\n    pending.installed=installed;")
s=s.replace('async function witness(phase, operation) {','async function witness(phase, operation, onInstalled) {')
s=s.replace("      pulse = setInterval(() => { if (!wc.isDestroyed()) wc.invalidate(); }, 30);", "      pulse = setInterval(() => { if (!wc.isDestroyed()) wc.invalidate(); }, 30);\n      onInstalled();")
for line,pending in (("    const aPending = beginWitness('a','a');",'aPending'),("    const bPending = beginWitness('b','b');",'bPending'),("    const bbPending = beginWitness('b','bb');",'bbPending')):
 s=s.replace(line,line+f"\n    await Promise.race([{pending}.installed,cancelled]);\n    await Promise.race([new Promise(resolve => setImmediate(resolve)),cancelled]);")
p.write_text(s)
(E/'ackyield.diff').write_text(''.join(difflib.unified_diff((E/'old/navigation_worker.mjs').read_text().splitlines(True),s.splitlines(True),fromfile='old/navigation_worker.mjs',tofile='ackyield/navigation_worker.mjs')))
# exact same instrumentation transform as variant1, preserving variant2 structure
w=E/'instrumented-ackyield';shutil.copytree(E/'ackyield',w);p=w/'navigation_worker.mjs';s=p.read_text()
s=s.replace('const delay = ms',"function trace(event,extra={}) { fs.appendFileSync("+repr(str(E/'ackyield-trace.jsonl'))+",JSON.stringify({t:Date.now(),event,...extra})+'\\n'); }\nconst delay = ms")
s=s.replace("      const ready = active; active = null;", "      const ready = active; active = null; trace('accepted',{f,operation:ready.operation});")
s=s.replace("try { return decoder.decode(record.image.toPNG(),operation); }", "try { trace('encode_start',{f,operation}); const png=record.image.toPNG(); trace('encode_end',{f,operation}); return decoder.decode(png,operation); }")
s=s.replace("try { baselinePending = decoder.decode(baselineImage.toPNG(),'baseline'); }", "try { trace('encode_start',{f,operation:'baseline'}); const png=baselineImage.toPNG(); trace('encode_end',{f,operation:'baseline'}); baselinePending = decoder.decode(png,'baseline'); }")
s=s.replace("    const png = rebuilt.toPNG();", "    trace('encode_start',{f,operation:'final'}); const png=rebuilt.toPNG(); trace('encode_end',{f,operation:'final'});")
s=s.replace("      await Promise.race([isolated(wc, `${checkDocumentCode(expectedUrl,f)};", "      trace('send',{f,operation}); const rendererAt = await Promise.race([isolated(wc, `${checkDocumentCode(expectedUrl,f)};",1)
s=s.replace("        })()`),cancelled]);\n      wc.invalidate();", "          return Date.now();\n        })()`),cancelled]);\n      trace('installed_reply',{f,operation,rendererAt});\n      wc.invalidate();",1)
s=s.replace("      wc.invalidate(); // Critical", "      wc.invalidate(); trace('invalidated',{f,operation}); // Critical");p.write_text(s)
shutil.copytree(E/'instrumented-old',E/'instrumented-old2');p=E/'instrumented-old2/navigation_worker.mjs';p.write_text(p.read_text().replace('old-trace.jsonl','old2-trace.jsonl'))
s=(E/'diagnostic1.py').read_text().replace("('old','yield1')","('old2','ackyield')").replace("'diagnostic1-results.json'","'diagnostic2-results.json'")
(E/'diagnostic2.py').write_text(s)
pins={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for label in ('old','yield1','ackyield','instrumented-old2','instrumented-ackyield') for p in (E/label).glob('*.mjs')};(E/'source2-sha256.json').write_text(json.dumps(pins,indent=2));shutil.copyfile(__file__,E/'tooling/setup2.py')
