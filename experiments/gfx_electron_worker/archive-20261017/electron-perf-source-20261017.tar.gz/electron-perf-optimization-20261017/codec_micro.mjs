import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {pathToFileURL} from 'node:url';
const old=await import(pathToFileURL(process.argv[2]));
const fresh=await import(pathToFileURL(process.argv[3]));
const results=[];
for(const file of process.argv.slice(4)){
 const png=fs.readFileSync(file), w=png.readUInt32BE(16),h=png.readUInt32BE(20),channels=png[25]===6?4:3;
 const idat=[];for(let p=8;p<png.length;){const n=png.readUInt32BE(p);if(png.toString('ascii',p+4,p+8)==='IDAT')idat.push(png.subarray(p+8,p+8+n));p+=n+12;}
 const raw=zlib.inflateSync(Buffer.concat(idat)), filters={};for(let y=0;y<h;y++){const f=raw[y*(w*channels+1)];filters[f]=(filters[f]||0)+1;}
 const expected=old.decodeNativePng(png,w,h);if(!expected.equals(fresh.decodeNativePng(png,w,h)))throw Error('RGBA mismatch');
 const timings={};for(const [label,mod]of[['old',old],['new',fresh]]){const cpu=process.cpuUsage(),t=performance.now();for(let n=0;n<8;n++){const out=mod.decodeNativePng(png,w,h);if(!out.equals(expected))throw Error('mismatch');}timings[label]={wall_ms:(performance.now()-t)/8,user_ms:(process.cpuUsage(cpu).user/1000)/8};}
 results.push({file,w,h,channels,filters,rgba_sha256:crypto.createHash('sha256').update(expected).digest('hex'),timings,speedup:timings.old.wall_ms/timings.new.wall_ms});
}
console.log(JSON.stringify({scope:'single process codec only; 8 repetitions, exact all-RGBA equality; not native render throughput',results},null,2));
