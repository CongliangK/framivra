# Electron codec performance patch — measured partial improvement

## Verdict

FUNCTIONAL_REGRESSION_PASS / PERFORMANCE_IMPROVED_BUT_STILL_BELOW_CEF. Do not restart the original full-film run on the strength of this report alone. No full-film speed or final-release claim.

Candidate: `0b1b78bf4472d133ccfb89e14803f832f0d2ef29`, parent `536d2468773f7dee71b46d8a390a81aefb37f369`; branch `alpha/electron-perf-20261017`; clean. Only three files changed: runtime `pixel_codec.mjs`, existing navigation contract test, new stdlib independent reference test. No navigation worker, gate, Python production code, HTML, timeline, font, SDK, flags or thresholds changed. No network/install/push/other-agent work/full-film restart. Own jobs 1033/1039/1058/1064 all collected. Elapsed execution/reasoning exceeded the requested 25-minute target (start 12:39; delivery after 13:10); not presented as within budget.

## Root cause and patch

The diagnostic worker reports ~68ms per PNG decode in Electron's Node runtime, six semantic decodes per frame. The system Node microbenchmark is faster and is not used to claim native speed. Window blank/navigation accounted for roughly 45ms in the sampled frame; unsafe browser reuse was not attempted.

Decoder now dispatches filters once per row; None uses bulk copy; Sub and Up avoid generic predictor work; Up uses explicit little-endian DataView four-byte independent modular sums with masked alternating lanes and scalar row tails. RGB-to-RGBA expansion uses bounded unaligned word reads and explicit alpha 255 (required by RGB format), including a scalar final-pixel tail. RGBA pixels retain all source alpha bytes; this is not an opaque-only shortcut. Existing signature/header/format/truncation/inflate-output/filter guards remain. Four signed A/B/A/B witnesses, baseline-only veto, six native PNG semantic decodes and all final fences remain unchanged.

## Actual native before/after

`native-results.json`, `native-summary.json`, `rgba-comparisons.json` and all original requests/worker results are retained. Root-RO bwrap, only own evidence RW, private net/PID/dev/tmp, host X11 socket RO. Same SDK SHA433b343..., b0/N/electron_native_topng/15s, 1920×1080, one worker, same untouched original three HTML paths and frame IDs 30/60/90. Two cold-output AB then BA rounds; 36 rendered frames total, 18 paired comparisons. Includes process startup; small sample, not sustained full-film throughput.

| Original page | old fps | new fps | wall speedup | old/new child user CPU seconds (6f each) |
|---|---:|---:|---:|---:|
| nav_two_pillars | 1.078 | 1.709 | 1.586× | 3.816 / 1.940 |
| open_source_card | 1.034 | 1.462 | 1.415× | 4.036 / 2.256 |
| u2_backends | 1.129 | 1.759 | 1.559× | 3.687 / 1.797 |

Aggregate wall approximately 16.686→11.024 seconds, 1.514×. All 18 decoded full-RGBA buffers EXACTLY equal; PNG bytes also all equal. The original pages declare transparency but these sampled final native PNGs are RGB; real fractional/zero-alpha correctness is covered separately by the real navigation fixture, not falsely called an original-transparent-page performance measurement.

Independent diagnostic fair CEF samples are 3.186 / 1.911 / 3.845fps respectively. Thus this candidate is STILL SLOWER than that CEF baseline. No hidden concurrency increase, warm-cache substitution, tiny-viewport speed claim or error-gate weakening.

`codec-micro.json` measures the initial scalar version on system Node: 2.01–3.48× isolated decode improvement on three real original 1080 PNGs, eight repeats. This is not the final packed-lane version's independent speed claim and not native renderer throughput. Native comparison above uses the final committed runtime codec.

## Correctness and actual regression

`final-regression.log`: 45 tests, 38.437s, OK, no skips. Correct package invocation covers navigation, page errors, promise checkpoints, independent PNG reference and public integration, including actual one-second all/QC/real Blender finish-hook verification. Real tests include zero/fractional alpha and marker fragments, generation/nonces, no starvation, delayed resources, resource errors, third-child/CSS marker side effects, occlusion timeout, wrong document, SIGKILL cleanup/stuck renderer, document-start throws/syntax errors, child exceptions, unhandled/suppressed promises, current HTML/config receipt bindings, corrupt/missing receipts, fail-closed reader/producer, split/warm identity, strict refusal and zero fallback.

Independent stdlib Python PNG encoder constructs RGB/RGBA randomized original pixels with all five filters, mixed rows, width1/2/65/127 boundaries and alpha values. 42 exact pixel cases plus geometry/truncation/illegal filter/short and oversized payload negatives. Reference is integrated into the existing contract suite; no new dependency.

Initial `native-regression.log` retains 24 passing cases plus one loader ERROR because discovery loaded a relative-import module without package context. `set -e` prevented the following public invocation. No product relaxation: correct explicit package names produced the final 45/45 result.

## Identity and preservation

`identity-and-source.json` records old identity SHA92bbf50b0ea10a47f8bf7dc68b9a085a471cff2ef712b1bec8c4e136b4943a95 and new identity SHAca6b221c92502ecfaac16227a8e5efa088d14a4c641f6184844e90c08ecdcf05. Codec byte changes naturally invalidate current native cache identity. Existing 536 outputs/cache remain untouched and cannot be relabeled as this candidate's current cache. All benchmark frame directories are evidence only, not fabricated canonical completions.

## Remaining work

More performance work is needed before re-running the original film. Keep measured gain, independently review packed-lane arithmetic/row tails, inspect remaining PNG encode and witness/quiet-window timings, and benchmark a real transparent 1080 case explicitly. Do not simply increase page concurrency or shorten stability thresholds. No risky BrowserWindow reuse is included; any future reuse needs strict new-document/generation/error-gate reset and adversarial cross-frame tests. This report is neither final PR readiness nor final Alpha approval.
