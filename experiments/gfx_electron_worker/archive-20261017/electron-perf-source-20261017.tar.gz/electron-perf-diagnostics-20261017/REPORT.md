# Electron 原536性能独立诊断与真实Native基线

## 结论

确认是**原生每帧路径的性能退化**，不是完整原片已完成，也不是仅等待UI不刷新。应先优化独立PNG解码器，不应继续盲等、不应靠删JS错误栅栏/见证/无标记baseline/PNG语义门提速。

- 同机、CPU/X11、1920×1080、同三份真实HTML、每页同帧`[30,60,90]`、并发1、全新profile和输出：原Electron共8.318s/9f，CEF共3.292s/9f，Electron批次wall为CEF的**2.527倍**。包含启动；非1080小图替代。
- 在Electron内部3个真实1080帧的仪表中：**6次独立PNG decode占总wall的47.12%**；6次PNG encode占14.92%。四见证、baseline、最终PNG验证均保留。
- 中断产物5759张PNG中5715张为RGB、44张RGBA（**99.24%走RGB路径**）。原codec在RGB→RGBA扩展对每个像素调用Buffer.copy：每张1080 PNG 2,073,600次、每帧6次decode约12,441,600次。行filter的逐字节分派也是热点。
- 原完整EE仅观察到5759 PNG、5759 raw frame receipts、11个complete页，**不是12024/整片PASS**。原始每帧elapsed合计5461.010s，已占GFX开始至末PNG5619.363s的97.18%；问题主要在native每帧内部，不是主控准备或cache校验。

详细机器数据：[metrics.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/metrics.json>)。

## 1. 历史基线口径

| 运行 | 原生gfx wall | 帧/页 | 并行设置 | 有效吞吐 |
|---|---:|---:|---|---:|
| 冻结CEF91实际完整gfx | 1276.599931s | 12024 / 28 | PAGES=2（不等于全程同时2个worker） | 9.41877fps |
| 原536 EE中断观测区间 | 5619.363201s | 5759 PNG / 11 complete页 | PAGES=1 | 1.02485fps |

CEF时间源是[实际阶段事件](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/cef-full-run-v3/run-full-final-91f41b3-20261016-attempt1/all-stage-events.jsonl>)：gfx从2026-10-16T11:14:38.692618Z到11:35:55.292549Z。EE来源是[实际阶段事件](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-full-run-v3-20261017/run-electron-full-536d246-20261017-full1/all-stage-events.jsonl>)加末PNG mtime；gfx从2026-10-17T03:02:32.874858Z开始，到末PNG仅为观测span，**没有gfx completed事件**。最终精确停止快照由Lead负责，本棒没有把截止时刻猜成正式阶段结束。

二者工作量/并行度/完整性不同，不以9.19倍的历史吞吐比冒充受控同并发结果。两历史流没有完整per-stage CPU，因此CPU为**UNKNOWN**；不能用瞬时ps 88%倒推CPU秒。CDP温态100.8s全链不是冷native gfx基线，完全未采用。

## 2. 新鲜受控原生小样

只读引用Electron实验副本的真实`nav_two_pillars`、已授权selector修复的`open_source_card`、`u2_backends` HTML；不拷贝改写内容。每页同`[30,60,90]`、1920×1080，每backend9帧。两个backend在同一独立私有dev/net/PID、rootRO、仅本E可写、短物理tmp+host X11socket RO的bwrap中串行测量。原候选536未改，原SDK未改；原工程及两copy未写。

| 页 | EE batch wall /3f | CEF batch wall /3f | EE frame elapsed ms | CEF request ms |
|---|---:|---:|---|---|
| nav_two_pillars | 2.807923s | 0.941561s | 876 / 783 / 783 | 208.70 / 164.62 / 157.45 |
| open_source_card | 2.903419s | 1.569800s | 935 / 855 / 863 | 485.13 / 441.80 / 430.30 |
| u2_backends | 2.606786s | 0.780142s | 853 / 746 / 770 | 238.98 / 165.68 / 166.40 |

冷定义：新输出无任何PNG命中、新profile、新worker进程。后两帧为同进程/同session的新文档导航，称navigation-warm，**不是artifact warm hit**。OS文件/字体缓存未清除，也未声称物理磁盘冷态。CEF通过原CefWorkerClient协议请求同frame id、核实际worker PID/canary/frame几何，未用0..2替代30/60/90。

正式native占用窗口为12:45:38.975–12:45:55.523+08（含额外3帧诊断仪表）；已向Lead发开始/结束，结束后才放行优化者正式bench。只有一次原始小样，无置信区间，不外推为新优化版12k吞吐。

原始记录：[bench.log](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/bench.log>)、[baseline-results.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/baseline-results.json>)。

RUSAGE_CHILDREN观察到的各batch user+system：EE 2.5486/2.5557/2.3614 CPU秒，CEF 0.8192/0.8058/0.6834 CPU秒。另存Python self CPU分量。它可能漏掉未由该父链reap的renderer子孙，因此标为observed child rusage，不冒充完整树CPU；下述Node phase CPU又仅main process（含其线程），不包含独立renderer。

## 3. 仪表计时与热点

仅在本E复制worker/gate/codec加hrtime和process.cpuUsage，未修改任何候选。原生capture、错误门、参数/超时、四见证、baseline-veto、独立解码比较及最终写盘均未删改。3个open_source_card可见帧全部真实native rc0/failed[]。

| 操作 | 次数/帧 | 3个实测帧wall范围 | 占比/含义 |
|---|---:|---:|---|
| 独立PNG decode | 6 | 413.7–437.0ms | 合计47.12%，首要热点 |
| PNG encode：baseline+4 witness+final | 6 | 107.8–150.6ms | 合计14.92% |
| active paint bitmap转换 | 8 | 22.7–24.4ms | 包括被拒旧paint，非只4个accepted |
| PNG/result两次原子写盘 | 2 | 10.86–11.03ms | 约1.2%，不是主因 |
| 四见证之外的稳定等待 | 1 | 40.22–40.38ms | 合计4.50%，不可直接删除 |
| 资源quiet等待 | 1 | 20.26 / 100.99 / 100.87ms | 合计8.27%；100ms是距离最后资源活动，并非总是额外100ms |
| 合并/全图相等及恢复段 | 1 | 6.17–6.84ms | 不是第一热点 |

总frame wall 873.99–937.20ms；main-process CPU约714–827ms。窗口构造coarse区间1.59–5.99ms；blank navigation18.73–45.69ms、file navigation22.55–84.03ms（冷首帧较高），gate安装2.55–3.87ms。不是“BrowserWindow构造本身占大多数”。baseline段含capture等待+encode+decode，见证段也含encode/decode，**不能把嵌套phase相加**。所有细分marks/operations保留在metrics。

原及仪表代码SHA：[instrumentation-hashes.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/instrumentation-hashes.json>)；仪表版不是候选原代码的验收证明。

### Codec内部辅助微测（版本限定）

另用系统Node22.23.3/V8 12.4对已生成RGB PNG做一次丢弃warmup+3次decode，没有启动浏览器。其单decode：inflate约1.3–2.6ms；逐字节unfilter约20.5–23.2ms；RGB扩展约15.3–17.7ms。原RGB行filter以Up(2)居多，另Sub(1)/Paeth(4)；每byte重新判断filter并计算不需要的邻居造成冗余。全表/版本见[codec-micro-results.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/codec-micro-results.json>)。

**不得将Node22微测比例直接套到Electron Node24的每次69–73ms真实decode上**；该差异可能涉及V8/GC/在途buffer，未独立归因。嵌入Electron内部的inflate/unfilter/expand各自精确CPU占比仍UNKNOWN。该微测不与优化版做正式比较。

## 4. 收益上界与最小安全建议

本3帧样本的Amdahl纯数学上界：把所有decode假想变成零成本也仅1.891倍；把所有encode+decode假想都变成零成本才2.635倍，**不是可达预测**。只改RGB扩展不可宣称拿到全部47%的收益。等待两项也不是允许删除的开关。

建议优先级：
1. 保持同一独立PNG语义解码器，逐row分派PNG filter，避免每byte重复分派/不需要的邻居计算；Filter0允许整行copy，Up/Sub/Paeth分别专用循环。
2. RGB→RGBA改直接indexed stores或经测试的更少分配路径，避免每pixel Buffer.copy调用。保持RGBA、alpha、所有0..4 filter与拒绝非法输入边界不变。
3. 检查重复分配/GC与长期450f batch真实尾段，不用只测192×96或只取第一帧替代1080稳定吞吐。
4. 之后才考虑window/session生命周期和并发；每帧新文档、pre-script异常栅栏、四见证及独立baseline不能由“暖态更快”直接绕过。不要擅自启用已证伪navfree。
5. 任一改动必须同样本1080新旧RGBA全等、原有错误/marker/alpha/provenance反例不变，再同配置实测；提升worker并发与减少单帧CPU分别报告。

## 5. 像素证据与局限

9个原EE/CEF匹配帧的decoded RGBA全部逐通道零差；PNG及RGBA SHA、maxdiff/MAE已记录：[cross-backend-comparison.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/cross-backend-comparison.json>)。额外3个仪表帧相对原EE也全部RGBA零差：[instrumented-pixel-comparison.json](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/instrumented-pixel-comparison.json>)。

这三页选定可见帧均为RGB opaque，不冒充独立透明fade原生配对基准。对实际中断产物的只读IHDR普查已提供[颜色格式分布](</home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-diagnostics-20261017/partial-png-format-census.json>)，其中存在44个RGBA帧；未另造透明内容或修改原HTML。

原536 HEAD/clean及两个native二进制SHA已现场重核：Electron `433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f`，CEF `c728509d359e2194450e7d6c440e005cebdeeec8e9441e95876a5fca7b87160c`。本棒没有源码/SDK/项目写入、安装/网络/其它agent/全片/PR操作；仅本E写。原完整任务由Lead停止，不由本棒重启。唯一正式native后台1034已亲收exit0，其余为有界同步数据分析；无活动后台。
