import os,sys,json,time,hashlib,resource,contextlib
from pathlib import Path
from PIL import Image,ImageChops
from vtx.infra import Ctx
from vtx import gfx_electron as ee
from vtx.cef_client import CefWorkerClient
from vtx.proc_supervisor import SupervisedProcessGroup
E=Path(__file__).resolve().parent
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
CEF=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-cef-final-20261016/experiments/gfx_cef_worker/build/bin/vtx_cef_worker')
PAGES=['nav_two_pillars','open_source_card','u2_backends'];FRAMES=[30,60,90]
root=E/'context';root.mkdir(exist_ok=True)
(root/'page.html').write_text('<html><body></body></html>')
(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))
c=Ctx(root/'timeline.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cpu():
 a=resource.getrusage(resource.RUSAGE_CHILDREN);b=resource.getrusage(resource.RUSAGE_SELF)
 return dict(child_user=a.ru_utime,child_system=a.ru_stime,self_user=b.ru_utime,self_system=b.ru_stime)
def cef(page,out):
 out.mkdir(parents=True);fds=[];env=dict(os.environ);rows=[]
 def argv(run,profile):
  fd=os.open(run,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);fds.append(fd);env['TMPDIR']=f'/proc/{os.getpid()}/fd/{fd}'
  return [str(CEF),'--mode=a0','--serve','--sync','--sync-mode=n','--sync-canary=exact','--sync-log=sync.jsonl','--ipc-socket=ipc.sock',f'--root-cache-path={profile}',f'--url-template={page.as_uri()}?f={{f}}','--width=1920','--height=1080']
 try:
  with open(out/'worker.log','wb') as log:
   with SupervisedProcessGroup(c,argv,backend_id='perf_cef_a0',stdout=log,stderr=log,env=env) as g:
    with CefWorkerClient.connect(f'/proc/{os.getpid()}/fd/{fds[-1]}/ipc.sock',connect_timeout=45) as client:
     assert client.hello['pid']==g.proc.pid
     for rid,f in enumerate(FRAMES,1):
      t=time.perf_counter();r=client.request_png(f,'frame.png',request_id=rid,expected_wh=(1920,1080),worker_relative=True)
      assert r.header['canary_frame_index']==f
      (out/f'f{f:04d}.png').write_bytes((g.run_dir/'frame.png').read_bytes())
      rows.append(dict(frame=f,request_wall_s=time.perf_counter()-t,receipt=r.header))
    rc=g.proc.wait(timeout=15);assert rc==0
    if (g.run_dir/'sync.jsonl').exists():(out/'sync.jsonl').write_bytes((g.run_dir/'sync.jsonl').read_bytes())
 finally:
  for fd in fds:os.close(fd)
 return rows
rows=[]
for backend in ('electron','cef'):
 for name in PAGES:
  page=SRC/(name+'.html');before=sha(page);out=E/'baseline'/backend/name
  t=time.perf_counter();b=cpu();started=time.time()
  print('BEGIN',backend,name,started,flush=True)
  if backend=='electron':
   st=ee.render_page(page,out,91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15,mode='b0',output='electron_native_topng')
   assert st['exit_code']==0 and st['failed']==[] and st['errors']=={},st
   raw=json.loads((Path(st['evidence_dir'])/'result.json').read_text());detail=raw['frames']
  else:detail=cef(page,out)
  a=cpu();r=dict(backend=backend,page=name,frames=FRAMES,source_sha256=before,started_epoch=started,wall_s=time.perf_counter()-t,cpu_delta_s={k:a[k]-b[k] for k in a},frame_receipts=detail)
  assert sha(page)==before
  rows.append(r);(E/'baseline-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
  print('END',backend,name,r['wall_s'],flush=True)
# Original-worker pair comparisons are observations across different Chromium versions, not a bit-exact release claim.
comparisons=[]
for name in PAGES:
 for f in FRAMES:
  paths=[E/'baseline'/b/name/f'f{f:04d}.png' for b in ('electron','cef')]
  ims=[Image.open(p).convert('RGBA') for p in paths];raw=[im.tobytes() for im in ims]
  diff=ImageChops.difference(*ims);hist=diff.histogram()
  count=sum(x!=y for x,y in zip(*raw));mae=sum(i%256*v for i,v in enumerate(hist))/(1920*1080*4)
  comparisons.append(dict(page=name,frame=f,png_sha256=[sha(p) for p in paths],rgba_sha256=[hashlib.sha256(x).hexdigest() for x in raw],different_channels=count,mae=mae,max_channel_delta=max(max(ch.getextrema()) for ch in diff.split())))
(E/'cross-backend-comparison.json').write_text(json.dumps(comparisons,indent=2))
print('BASELINE_NATIVE_DONE',time.time(),flush=True)
# Diagnostic-only instrumented worker: same gate/capture logic, additional timers; not production candidate evidence.
ee.WORKER_DIR=E/'instrumented'
page=SRC/'open_source_card.html';out=E/'instrumented-output';t=time.perf_counter();b=cpu()
st=ee.render_page(page,out,91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15,mode='b0',output='electron_native_topng')
assert st['exit_code']==0 and st['failed']==[] and st['errors']=={},st
(E/'instrumented-summary.json').write_text(json.dumps(dict(wall_s=time.perf_counter()-t,cpu_before=b,cpu_after=cpu(),adapter=st),indent=2))
print('ALL_NATIVE_DONE',time.time(),flush=True)
