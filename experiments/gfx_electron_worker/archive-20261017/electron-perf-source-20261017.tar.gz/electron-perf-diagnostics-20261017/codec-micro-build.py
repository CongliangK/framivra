from pathlib import Path
E=Path(__file__).resolve().parent;S=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-receipts-20261017/experiments/gfx_electron_worker/pixel_codec.mjs')
s=S.read_text()
s=s.replace('  const raw = zlib.inflateSync', '  const _t0=process.hrtime.bigint();\n  const raw = zlib.inflateSync',1)
s=s.replace('  const decoded = Buffer.alloc', '  const _t1=process.hrtime.bigint();\n  const decoded = Buffer.alloc',1)
s=s.replace('  if (channels === 4) return decoded;', '  const _t2=process.hrtime.bigint();\n  if (channels === 4) {globalThis.__codecTimes.push({inflate_ms:Number(_t1-_t0)/1e6,unfilter_ms:Number(_t2-_t1)/1e6,rgb_expand_ms:0});return decoded;}',1)
s=s.replace('  return rgba;', '  const _t3=process.hrtime.bigint();globalThis.__codecTimes.push({inflate_ms:Number(_t1-_t0)/1e6,unfilter_ms:Number(_t2-_t1)/1e6,rgb_expand_ms:Number(_t3-_t2)/1e6});\n  return rgba;',1)
(E/'codec-micro.mjs').write_text(s)
