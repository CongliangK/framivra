from pathlib import Path
import json,hashlib,statistics,subprocess,os
E=Path(__file__).resolve().parent;m=json.loads((E/'metrics.json').read_text());micro=json.loads((E/'codec-micro-results.json').read_text());compare=json.loads((E/'cross-backend-comparison.json').read_text());inst=json.loads((E/'instrumented-pixel-comparison.json').read_text());fmt=json.loads((E/'partial-png-format-census.json').read_text())
T=sum(p['total_wall_ms'] for p in m['instrumented']);D=sum(p['operations']['decode']['wall_ms'] for p in m['instrumented']);EN=sum(sum(v['wall_ms'] for k,v in p['operations'].items() if k.startswith('encode')) for p in m['instrumented'])
quiet=sum(next(i['wall_ms'] for i in p['intervals'] if i['start']=='resources_end_quiet_start') for p in m['instrumented']);stable=sum(next(i['wall_ms'] for i in p['intervals'] if i['start']=='stable_wait_start') for p in m['instrumented'])
m['diagnostic_codec_micro']=micro;m['partial_format_census']=fmt;m['pixel_comparison_summary']={'matched_ee_cef_rgba_zero_difference':all(x['different_channels']==0 for x in compare),'matched_pairs':len(compare),'instrumented_rgba_equal':all(x['rgba_equal'] for x in inst),'instrumented_pairs':len(inst)}
m['amdahl_bounds']={'basis':'Three instrumented1080 open_source_card frames only; zero-cost limits, not achievable predictions. Security waits/gates must remain.','decode_fraction':D/T,'eliminating_only_all_decode_upper_bound':1/(1-D/T),'all_png_encode_fraction':EN/T,'eliminating_encode_and_decode_upper_bound':1/(1-(D+EN)/T),'resource_quiet_fraction':quiet/T,'stable_wait_fraction':stable/T}
root=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-receipts-20261017');env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
m['source_head']=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True,env=env).strip();m['source_porcelain']=subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True,env=env)
paths={'electron_bin':Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron/dist/electron'),'cef_bin':Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-cef-final-20261016/experiments/gfx_cef_worker/build/bin/vtx_cef_worker')}
m['native_hashes']={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()}
assert m['source_head']=='536d2468773f7dee71b46d8a390a81aefb37f369' and not m['source_porcelain']
assert m['native_hashes']['electron_bin']=='433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f'
assert m['native_hashes']['cef_bin']=='c728509d359e2194450e7d6c440e005cebdeeec8e9441e95876a5fca7b87160c'
m['native_measurement_window']={'start_epoch':1792212338.9749582,'end_epoch':1792212355.5226674,'note':'Only this16.55s native window is claimed serialized with optimizer. Subsequent standalone Node22 codec diagnostic is not a native benchmark or patched-code comparison.'}
(E/'metrics.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
print(json.dumps(m['amdahl_bounds'],indent=2))
