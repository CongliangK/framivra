from pathlib import Path
import json,hashlib,subprocess
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-marker-canvas-20261017-codex')
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
snapshot=json.loads((E/'source-snapshot.json').read_text())
for side in ['old','new']:
 for name,expected in snapshot[side].items():assert hashlib.sha256((E/side/name).read_bytes()).hexdigest()==expected
for name,h in snapshot['old'].items():assert hashlib.sha256((T/'experiments/gfx_electron_worker'/name).read_bytes()).hexdigest()==h
assert subprocess.check_output(['git','-C',str(T),'rev-parse','HEAD'],text=True).strip()=='d32310853d6136f3f621a356b0c2718c7fab1a25'
assert subprocess.check_output(['git','-C',str(T),'status','--porcelain'],text=True)==''
rows=json.loads((E/'final-native-results.json').read_text())
metrics=[]
for r in rows:
 assert len(r['frame_receipts'])==3
 assert [f['generation'] for f in r['frame_receipts']]==[1,2,3]
 assert all(f['witnesses']==4 and f['png_decode_count']==6 and f['baseline_veto_passed'] and f['png_semantics_passed'] for f in r['frame_receipts'])
 metrics.append({k:r[k] for k in ['round','backend','page','wall_s','cpu_delta_s']}|{'paints':sum(f['paints'] for f in r['frame_receipts']),'rejected_paints':sum(f['rejected_paints'] for f in r['frame_receipts']), 'per_frame':[{'frame':f['frame'],'paints':f['paints'],'rejected_paints':f['rejected_paints'],'witnesses':f['witnesses'],'png_decode_count':f['png_decode_count']} for f in r['frame_receipts']]})
agg={}
for side in ['old','new']:
 rs=[r for r in metrics if r['backend']==side]
 agg[side]={'wall_s':sum(r['wall_s'] for r in rs),'paints':sum(r['paints'] for r in rs),'rejected_paints':sum(r['rejected_paints'] for r in rs),'cpu_delta_s':{k:sum(r['cpu_delta_s'][k] for r in rs) for k in rs[0]['cpu_delta_s']}}
(E/'aggregate-metrics.json').write_text(json.dumps({'runs':metrics,'aggregate':agg,'speedup':agg['old']['wall_s']/agg['new']['wall_s']},indent=2))
ledger={'setup.py':0,**{p.name.removesuffix('.exit.json'):json.loads(p.read_text())['exit_code'] for p in E.glob('*.exit.json')},'report.py':0}
(E/'command-exit-ledger.json').write_text(json.dumps(ledger,indent=2))
summary=json.loads((E/'final-native-summary.json').read_text())
report='''# EE-PERF-7 双小 canvas 局部假说

结论：TARGETED_CORRECTNESS_PASS / NO_STABLE_MATERIAL_PERFORMANCE_GAIN / DIRECTION_STOPPED。未接线生产，未修改工作树、原片、实验副本或 manifest；未 push、merge、重启整片。稳定 E 副本只供 fresh 审查及复核。

## 范围与冻结

冻结源 HEAD `d32310853d6136f3f621a356b0c2718c7fab1a25`，setup前与最终均 clean；old逐个 mjs 与该树逐字节一致。完整差异见 `candidate.diff`，仅 isolated world marker 内部：闭合 shadow 内原1920×1080 canvas改为两张32×1 canvas，绝对固定在 host 顶左/底右；host document div、important CSS、closed shadow/world997、48bytes crypto nonce、A/B/A/B、generation、60Hz、invalidate cadence、capturePage/toBitmap/toPNG、六次全RGBA decode、baseline仅veto及所有门均未改。未增依赖或协议声明。每次nonce清两张32×1后只画原32个随机RGB像素。

phase A 顶 local0..15/底local16..31，phase B 顶16..31/底0..15；底canvas全局x=width−32，y=height−1。markerMatches/markerRanges/mergeWitnesses完全沿用冻结版本。源码及gate/codec SHA详 `source-snapshot.json`；candidate worker SHA `8710be55d92e5ec71314cdcd593c99d94511406386a14737121de63e948ed23f`。运行开始后未修改这些源码，最终机验哈希不变。

## 先验验证

`validation.py` 原生执行 exit0。192×96 原 navigation fixture frames[3,0,2]，双侧rc0，3对PNG字节及完整RGBA全等。每帧alpha128实点核验，所有首尾行每个像素包括marker范围真实恢复成页面原值；原始receipt每帧四witness/六decode，generation[1,2,3]。

marker DOM side effect、html:has第三child、html opacity遮挡三反例各先紧邻真实native静态control rc0，再观测expected拒绝；每对2 tests OK，失败帧无输出。保留 `targeted/suite-*` 全部raw。遮挡保留1s测试预算，其余默认15s。marker坐标单元枚举宽64/65/192/1920/3840和高2/3/96/1080，两个phase全token匹配且范围有界；0/31/32/63宽拒绝。未以小viewport性能冒充正式验收。

## 正式性能与像素

SDK锁定SHA433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f。rootRO bwrap、private net/PID/dev、physical tmp、host X11socket RO、仅本E RW；无HOME重定义；每次精确argv/env在 `bench.py.command.json`，wrapper `run.py`。新冷profile/output，无旧cache命中，包含启动；OS/font缓存未清除。PAGES1/b0/15s/electron_native_topng/1920×1080，同三个真实只读HTML frames30/60/90，AB后BA共36帧，12次render全部exit0。

|页|old fps|tiny fps|old/tiny|old/new wall s(各6f)|
|---|---:|---:|---:|---:|
'''
for r in summary['results']:report+=f"|{r['page']}|{r['old_fps']:.5f}|{r['new_fps']:.5f}|{r['speedup']:.5f}×|{r['old_wall_s']:.6f}/{r['new_wall_s']:.6f}|\n"
report+=f"\n合计wall {agg['old']['wall_s']:.6f}→{agg['new']['wall_s']:.6f}s，{agg['old']['wall_s']/agg['new']['wall_s']:.6f}×。nav近乎零收益，open约3%，u2慢约1.8%；不足以支持稳定明显收益。\n\n18对PNG字节及全RGBA全部零差，见 `final-rgba-comparisons.json`。四witness/六decode/全语义标识逐帧机验；最终输出每像素仍来自真实native四witness恢复，baseline仅veto。\n\n|侧|child user s|child system s|self user s|self system s|paints|rejected paints|\n|---|---:|---:|---:|---:|---:|---:|\n"
for side,r in agg.items():
 c=r['cpu_delta_s'];report+=f"|{side}|{c['child_user']:.6f}|{c['child_system']:.6f}|{c['self_user']:.6f}|{c['self_system']:.6f}|{r['paints']}|{r['rejected_paints']}|\n"
report+='''
CPU为Python rusage observed child/self分列，可能漏非本父链reap的renderer后代，不能当完整树CPU；未将paints/rejected paints与速度合并。各round/page独立CPU与实际paints、拒绝数及每帧细分在 `aggregate-metrics.json`；原始带完整frame receipts数据在 `final-native-results.json`。

## 止损与收尾

按授权的阶段止损：无稳定明显收益，未继续e1/llm_post/w_title额外真实分数alpha矩阵与完整46项回归，因此不可宣称该候选完整回归通过或生产准入。128alpha多帧与针对拒绝门通过只代表当前实测覆盖，不证明所有CSS对抗语义。未提速不强留：建议放弃此方向。全部证据、源码、profiles/PNGs、原始receipts保留；没有过滤/删除失败（本轮没有意外native失败）。

所有命令退出码见 `command-exit-ledger.json`：setup0/validation0/bench0/report0。两个后台native wrapper session已亲收exit0；最终无本E Electron/navigation_worker运行进程，profile自动清理检查通过。仓库HEAD及clean/source哈希最终未变。报告写完后停止写入，供fresh审查。
'''
(E/'REPORT.md').write_text(report)
print(json.dumps(agg,indent=2));print('REPORT_FROZEN')
