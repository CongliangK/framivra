# EE-PERF-7 双小 canvas 局部假说

结论：TARGETED_CORRECTNESS_PASS / NO_STABLE_MATERIAL_PERFORMANCE_GAIN / DIRECTION_STOPPED。未接线生产，未修改工作树、原片、实验副本或 manifest；未 push、merge、重启整片。稳定 E 副本只供 fresh 审查及复核。

## 范围与冻结

冻结源 HEAD `d32310853d6136f3f621a356b0c2718c7fab1a25`，setup前与最终均 clean；old逐个 mjs 与该树逐字节一致。完整差异见 `candidate.diff`，仅 isolated world marker 内部：闭合 shadow 内原1920×1080 canvas改为两张32×1 canvas，绝对固定在 host 顶左/底右；host document div、important CSS、closed shadow/world997、48bytes crypto nonce、A/B/A/B、generation、60Hz、invalidate cadence、capturePage/toBitmap/toPNG、六次全RGBA decode、baseline仅veto及所有门均未改。未增依赖或协议声明。每次nonce清两张32×1后只画原32个随机RGB像素。

phase A 顶 local0..15/底local16..31，phase B 顶16..31/底0..15；底canvas全局x=width−32，y=height−1。markerMatches/markerRanges/mergeWitnesses完全沿用冻结版本。源码及gate/codec SHA详 `source-snapshot.json`；candidate worker SHA `8710be55d92e5ec71314cdcd593c99d94511406386a14737121de63e948ed23f`。运行开始后未修改这些源码，最终机验哈希不变。

## 先验验证

`validation.py` 原生执行 exit0。192×96 原 navigation fixture frames[3,0,2]，双侧rc0，3对PNG字节及完整RGBA全等。每帧alpha128实点核验，所有首尾行每个像素包括marker范围真实恢复成页面原值；原始receipt每帧四witness/六decode，generation[1,2,3]。

marker DOM side effect、html:has第三child、html opacity遮挡三反例各先紧邻真实native静态control rc0，再观测expected拒绝；每对2 tests OK，失败帧无输出。保留 `targeted/suite-*` 全部raw。遮挡保留1s测试预算，其余默认15s。marker坐标单元枚举宽64/65/192/1920/3840和高2/3/96/1080，两个phase全token匹配且范围有界；0/31/32/63宽拒绝。未以小viewport性能冒充正式验收。

## 正式性能与像素

SDK锁定SHA433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f。rootRO bwrap、private net/PID/dev、physical tmp、host X11socket RO、仅本E RW；无HOME重定义；每次精确argv/env在 `bench.py.command.json`，wrapper `run.py`。新冷profile/output，无旧cache命中，包含启动；OS/font缓存未清除。PAGES1/b0/15s/electron_native_topng/1920×1080，同三个真实只读HTML frames30/60/90，AB后BA共36帧，12次render全部exit0。

|页|old fps|tiny fps|old/tiny|old/new wall s(各6f)|
|---|---:|---:|---:|---:|
|nav_two_pillars|2.02389|2.02552|1.00081×|2.964595/2.962203|
|open_source_card|1.68129|1.73146|1.02984×|3.568697/3.465291|
|u2_backends|2.09695|2.05955|0.98216×|2.861298/2.913264|

合计wall 9.394590→9.340758s，1.005763×。nav近乎零收益，open约3%，u2慢约1.8%；不足以支持稳定明显收益。

18对PNG字节及全RGBA全部零差，见 `final-rgba-comparisons.json`。四witness/六decode/全语义标识逐帧机验；最终输出每像素仍来自真实native四witness恢复，baseline仅veto。

|侧|child user s|child system s|self user s|self system s|paints|rejected paints|
|---|---:|---:|---:|---:|---:|---:|
|old|6.220022|3.885548|0.034631|0.034085|219|72|
|new|6.199991|3.812683|0.039295|0.029431|223|72|

CPU为Python rusage observed child/self分列，可能漏非本父链reap的renderer后代，不能当完整树CPU；未将paints/rejected paints与速度合并。各round/page独立CPU与实际paints、拒绝数及每帧细分在 `aggregate-metrics.json`；原始带完整frame receipts数据在 `final-native-results.json`。

## 止损与收尾

按授权的阶段止损：无稳定明显收益，未继续e1/llm_post/w_title额外真实分数alpha矩阵与完整46项回归，因此不可宣称该候选完整回归通过或生产准入。128alpha多帧与针对拒绝门通过只代表当前实测覆盖，不证明所有CSS对抗语义。未提速不强留：建议放弃此方向。全部证据、源码、profiles/PNGs、原始receipts保留；没有过滤/删除失败（本轮没有意外native失败）。

所有命令退出码见 `command-exit-ledger.json`：setup0/validation0/bench0/report0。两个后台native wrapper session已亲收exit0；最终无本E Electron/navigation_worker运行进程，profile自动清理检查通过。仓库HEAD及clean/source哈希最终未变。报告写完后停止写入，供fresh审查。
