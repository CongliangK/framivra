from pathlib import Path
import hashlib,json,shutil,difflib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-marker-canvas-20261017-codex')
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
E.mkdir(exist_ok=False)
for side in ['old','new']:
 d=E/side;d.mkdir()
 for p in (T/'experiments/gfx_electron_worker').iterdir():
  if p.is_file() and p.suffix in ('.mjs','.py','.json'):shutil.copy2(p,d/p.name)
 shutil.copytree(T/'experiments/gfx_electron_worker/pages',d/'pages')
(E/'tmp').mkdir()
p=E/'new/navigation_worker.mjs';s=p.read_text()
old="""            const canvas = document.createElement('canvas'); canvas.width=${width}; canvas.height=${height};
            canvas.style.cssText='all:initial;display:block;width:${width}px;height:${height}px';
            root.append(canvas); document.documentElement.append(host);
            state = {host,canvas}; globalThis.__vtxHostMarker=state;
          }
          const c=state.canvas.getContext('2d'); c.clearRect(0,0,${width},${height});
          const t=${JSON.stringify([...token])}, dx=${phase === 'a' ? 0 : 16};
          for(let p=0;p<16;p++) {
            c.fillStyle='rgb('+t.slice(p*3,p*3+3).join(',')+')';
            c.fillRect(dx+p,0,1,1); c.fillRect(${width}-16-dx+p,${height}-1,1,1);
          }"""
new="""            const top = document.createElement('canvas'), bottom = document.createElement('canvas');
            for (const canvas of [top,bottom]) {
              canvas.width=32; canvas.height=1;
              canvas.style.cssText='all:initial;position:absolute;display:block;width:32px;height:1px';
            }
            top.style.left='0px'; top.style.top='0px';
            bottom.style.right='0px'; bottom.style.bottom='0px';
            root.append(top,bottom); document.documentElement.append(host);
            state = {host,top,bottom}; globalThis.__vtxHostMarker=state;
          }
          const a=state.top.getContext('2d'), b=state.bottom.getContext('2d');
          a.clearRect(0,0,32,1); b.clearRect(0,0,32,1);
          const t=${JSON.stringify([...token])}, dx=${phase === 'a' ? 0 : 16};
          for(let p=0;p<16;p++) {
            a.fillStyle=b.fillStyle='rgb('+t.slice(p*3,p*3+3).join(',')+')';
            a.fillRect(dx+p,0,1,1); b.fillRect(16-dx+p,0,1,1);
          }"""
assert s.count(old)==1;p.write_text(s.replace(old,new))
(E/'candidate.diff').write_text(''.join(difflib.unified_diff(s.splitlines(True),p.read_text().splitlines(True),fromfile='old/navigation_worker.mjs',tofile='new/navigation_worker.mjs')))
(E/'source-snapshot.json').write_text(json.dumps({side:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (E/side).glob('*.mjs')} for side in ['old','new']},indent=2))
runner=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-native-decoder-prototype-20261017-codex/run.py').read_text()
(E/'run.py').write_text(runner)
bench=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-native-decoder-prototype-20261017-codex/bench.py').read_text()
(E/'bench.py').write_text(bench)
print(E)
