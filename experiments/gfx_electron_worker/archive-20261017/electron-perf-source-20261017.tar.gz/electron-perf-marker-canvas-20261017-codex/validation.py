import os,sys,json,hashlib,importlib.util,unittest
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
results=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for side in ['old','new']:
 ee.WORKER_DIR=E/side
 root=E/'alpha192'/side;root.mkdir(parents=True)
 ctx=SimpleNamespace(root=root,cache=root/'cache',out=root/'out')
 st=ee.render_page(E/side/'pages/navigation_fixture.html',root/'frames',4,width=192,height=96,frames=[3,0,2],ctx=ctx,timeout_s=15)
 results.append({'side':side,'adapter':st});(E/'validation-alpha-results.json').write_text(json.dumps(results,indent=2))
 assert st['exit_code']==0 and not st['failed'],st
 raw=json.loads((Path(st['evidence_dir'])/'result.json').read_text())
 assert all(f['witnesses']==4 and f['png_decode_count']==6 for f in raw['frames'])
 for f in [3,0,2]:
  im=Image.open(root/'frames'/f'f{f:04d}.png').convert('RGBA')
  assert im.getpixel((8,8))[3]==128
  for y in (0,95):
   for x in range(192):assert im.getpixel((x,y))==((x+f*17)%256,(y*7+f)%256,(x+y)%256,255)
for f in [3,0,2]:
 ps=[E/'alpha192'/s/'frames'/f'f{f:04d}.png' for s in ['old','new']]
 assert ps[0].read_bytes()==ps[1].read_bytes()
 assert Image.open(ps[0]).convert('RGBA').tobytes()==Image.open(ps[1]).convert('RGBA').tobytes()
# Each negative immediately follows a genuine native control in the same frozen implementation.
os.environ['VTX_TEST_ELECTRON']='1';os.environ['VTX_ELECTRON_EVIDENCE_DIR']=str(E/'targeted')
ee.WORKER_DIR=E/'new'
spec=importlib.util.spec_from_file_location('target_tests',E/'new/test_navigation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=['test_marker_dom_side_effect_is_rejected','test_marker_has_third_child_is_rejected','test_marker_occlusion_timeout']
suite=unittest.TestSuite()
for n in names:
 suite.addTest(m.RealNavigationTests('test_static_page_no_starvation_and_security'))
 suite.addTest(m.RealNavigationTests(n))
# Repeated setUp names need separate suite roots, so run each pair separately.
for n in names:
 suite=unittest.TestSuite([m.RealNavigationTests('test_static_page_no_starvation_and_security'),m.RealNavigationTests(n)])
 r=unittest.TextTestRunner(verbosity=2).run(suite)
 assert r.wasSuccessful()
# Geometry unit checks cover all accepted widths at the 64 boundary and reject below.
import subprocess
code="""import {markerRanges,markerMatches,mergeWitnesses} from './pixel_codec.mjs';
for(const w of [64,65,192,1920,3840])for(const h of [2,3,96,1080])for(const phase of ['a','b']){
const b=Buffer.alloc(w*h*4),t=Buffer.from(Array.from({length:48},(_,i)=>i));
const dx=phase==='a'?0:16;
for(let p=0;p<16;p++)for(const i of [(dx+p)*4,((h-1)*w+w-32+(16-dx)+p)*4]){
b[i]=t[p*3+2];b[i+1]=t[p*3+1];b[i+2]=t[p*3];b[i+3]=255;}
if(!markerMatches(b,w,h,phase,t))throw Error('coordinate mismatch');
const expected=markerRanges(w,h,phase);if(expected.some(([a,z])=>a<0||z>b.length||z-a!==64))throw Error('range');}
for(const w of [0,31,32,63]){let rejected=false;try{markerRanges(w,2,'a')}catch{rejected=true}if(!rejected)throw Error('accepted width');}
console.log('geometry PASS');"""
r=subprocess.run(['node','--input-type=module','-e',code],cwd=E/'new');assert r.returncode==0
print('VALIDATION_PASS',flush=True)
