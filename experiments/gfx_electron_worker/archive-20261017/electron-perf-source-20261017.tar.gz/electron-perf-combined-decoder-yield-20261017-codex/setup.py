from pathlib import Path
import shutil,hashlib,json,difflib
BASE=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016')
E=BASE/'electron-perf-combined-decoder-yield-20261017-codex';E.mkdir(exist_ok=True)
N=BASE/'electron-perf-native-decoder-prototype-20261017-codex';Y=BASE/'electron-perf-encode-overlap-yield-20261017-codex'
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Y/'REPORT.md')=='c1570a70a120533339e3bc4979cd57804bc94ee45290e504aadf205c853cabf8'
assert sha(Y/'ackyield/navigation_worker.mjs')=='fae95a99802daac6ed02a256d6702861e6d4373016f3671407dd164f24f56824'
assert sha(N/'native_png.node')=='0f0f7e7bc976dc460a75d0df557e8c54afe7f5bafca3073f787b4cf7c4af754a'
assert sha(N/'native_png.c')=='fafaadd9793cb3c6c1710f8c45137fd7cc0537bdc1318fe07b57832876beaa41'
for side in ['old','new']:
 d=E/side;d.mkdir(exist_ok=True)
 for name in ['navigation_worker.mjs','page_error_gate.mjs','pixel_codec.mjs']:
  src=T/'experiments/gfx_electron_worker'/name
  if side=='new' and name=='navigation_worker.mjs':src=Y/'ackyield'/name
  if side=='new' and name=='pixel_codec.mjs':src=N/'new'/name
  s=src.read_text()
  if side=='new' and name=='pixel_codec.mjs':s=''.join(line for line in s.splitlines(True) if "import fs from 'node:fs'" not in line and 'fs.writeFileSync' not in line)
  (d/name).write_text(s)
for name in ['native_png.node','native_png.c','build-command.json','build.log','build-exit.json','supply-chain.json']:
 shutil.copyfile(N/name,E/('inherited-'+name if name in ['build-command.json','supply-chain.json'] else name))
(E/'build-command.json').write_text(json.dumps(['cc','-std=c11','-O3','-fPIC','-shared','-Wall','-Wextra','-Werror','-I/usr/include/node','-I/usr/include/libpng16',str(E/'native_png.c'),'-o',str(E/'native_png.node'),'-lpng16','-lz'],indent=2))
for d in ['tmp','xdg-config','xdg-cache','maps']:(E/d).mkdir(exist_ok=True)
# Extra maps only in an untimed probe copy.
shutil.copytree(E/'new',E/'probe')
p=E/'probe/pixel_codec.mjs';s=p.read_text();s="import fs from 'node:fs';\n"+s;s=s.replace("if (!isMainThread && workerData?.vtxNativePngDecoder === 1) {","if (!isMainThread && workerData?.vtxNativePngDecoder === 1) {\n  fs.writeFileSync(new URL('../maps/combo-worker.maps',import.meta.url),fs.readFileSync('/proc/self/maps'));\n  fs.writeFileSync(new URL('../maps/combo-versions.json',import.meta.url),JSON.stringify(process.versions));");p.write_text(s)
shutil.copyfile(T/'experiments/gfx_electron_worker/test_navigation.py',E/'new/test_navigation.py');shutil.copytree(T/'experiments/gfx_electron_worker/pages',E/'new/pages')
runner=(N/'run.py').read_text();(E/'run.py').write_text(runner)
bench=(N/'bench.py').read_text();(E/'bench.py').write_text(bench)
alpha=(N/'alpha.py').read_text();(E/'alpha.py').write_text(alpha)
basic=(Y/'ack_basic.py').read_text().replace("E/'ackyield'","E/'new'").replace("E/'ack-basic'","E/'basic'")
basic=basic.replace("'test_static_page_no_starvation_and_security',", "'test_navigation_generation_and_cross_recovery','test_resource_error_never_old_file_success','test_static_page_no_starvation_and_security',")
(E/'basic.py').write_text(basic)
negative=(Y/'ack_negative.py').read_text().replace("E/'ackyield'","E/'new'")
(E/'negative.py').write_text(negative)
(E/'source-pins-before.json').write_text(json.dumps({str(p.relative_to(E)):sha(p) for p in [E/'native_png.c',E/'native_png.node',*E.glob('old/*.mjs'),*E.glob('new/*.mjs'),*E.glob('probe/*.mjs')]},indent=2))
for name in ['navigation_worker.mjs','pixel_codec.mjs','page_error_gate.mjs']:
 a=(E/'old'/name).read_text().splitlines(True);b=(E/'new'/name).read_text().splitlines(True);(E/(name+'.diff')).write_text(''.join(difflib.unified_diff(a,b,fromfile='old/'+name,tofile='new/'+name)))
print('SETUP_DONE')
