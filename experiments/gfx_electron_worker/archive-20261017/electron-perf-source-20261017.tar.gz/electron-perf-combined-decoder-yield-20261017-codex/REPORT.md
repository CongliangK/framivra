# EE-PERF-5B combined decoder + ackyield qualification

**性能不合格，后续不采用。PERFORMANCE_SAMPLE_ADMISSION_FAIL / PIXEL_TARGETED_CONTROLS_PASS / NO_PRODUCTION_INTEGRATION.**

Fresh single-worker aggregate combo 8.430914839s / CEF 6.355429893s = **1.326568774 > 1.25**. Round1 1.282207483; round2 1.373550570. The aggregate is the requested admission criterion. User subsequently stopped performance pursuit; no further tuning/new bench/46/450/SDK fork/production wiring/full-film/PR was performed by this subtask. The controller owns later functional full-film and submission/merge work.

## Frozen combination

old/ is original d32310853d6136f3f621a356b0c2718c7fab1a25 worker/gate/codec. new/ combines frozen ackyield navigation (fae95a99802daac6ed02a256d6702861e6d4373016f3671407dd164f24f56824) and the prior C N-API/libpng decode in the existing single host decoder worker. The original ackyield report SHA c1570a70a120533339e3bc4979cd57804bc94ee45290e504aadf205c853cabf8 and SDK-source report were read before setup.

Ackyield keeps a strong NativeImage reference for each exact paint, waits installation ack+invalidate then yields once before encoding previous baseline/A/AA; B encoding stays before original40ms wait. Locked SDK source supports per-paint allocation lifetime. NativeImage never moves to decoder worker. All six independent real Electron NativeImage.toPNG operations and complete RGBA decodes remain, four nonce ABAB, baseline-only veto, fresh single document/frame,40ms/100ms/15s, original JS/Promise/three-child/final fences and atomic publish remain. No extra render worker. The addon uses low-level libpng RGB/RGBA8/noninterlaced exact geometry, RGB adds255/RGBA raw, no gamma/ICC/background/premultiply transforms; bounded memory/chunks/CRC/error semantics inherited unchanged.

Formal sources have no extra maps/timing instrumentation. Separate untimed probe/ proves actual combined worker loaded libraries. Full sources and exact navigation_worker.mjs.diff, pixel_codec.mjs.diff, page_error_gate.mjs.diff are retained; source-pins-before/after.json match byte-for-byte. All repositories/originals/experimental media/prior E stayed read-only; no install/network/manifest/git writes.

| frozen file | SHA256 |
|---|---|
| old/navigation_worker.mjs | 779cef67cf9e0a848afb6f0f08e797b77dfcc1386b2cbc9ce1de084c7810d5e2 |
| old/pixel_codec.mjs | 9a8a4cc448dccfc0d541f56977150272a058d61adba1cbf0d2cb50c9c13c2142 |
| new/navigation_worker.mjs | fae95a99802daac6ed02a256d6702861e6d4373016f3671407dd164f24f56824 |
| new/pixel_codec.mjs | cf364a495da30104332232b0bb32679671037c05bdb77ea7313af636dd72b209 |
| new/page_error_gate.mjs | baec46139eeba8f0c52488018d71867d4b8c07bfd104d2b6d20eb688aef49425 |
| native_png.c | fafaadd9793cb3c6c1710f8c45137fd7cc0537bdc1318fe07b57832876beaa41 |
| native_png.node | 0f0f7e7bc976dc460a75d0df557e8c54afe7f5bafca3073f787b4cf7c4af754a |

## Build and loaded dependencies

The unchanged .node was copied byte-for-byte from prior POC, not rebuilt here. inherited-build-command.json/inherited-build.log/inherited-build-exit.json/inherited-supply-chain.json preserve actual original build/compiler/header provenance. build-command.json gives the corresponding rebuild argv for this E, not a command executed in this experiment. GCC16.2.1/N-API8/libpng header1.6.58/zlib header1.3.1.zlib-ng. setup.py preserves combination assembly.

Actual Electron44.7.2/Node24.21.0 combined worker load proved by maps/combo-worker.maps and combo-versions.json; actual-loaded-deps.json rechecks binary/system library SHA:

- /usr/lib64/libpng16.so.16.58.0: 65cb04d6c4ec5c031f2f43a58ec5adc4bc9652be5703bb9fa1178f84a2e40446
- /usr/lib64/libz.so.1.3.1.zlib-ng: bbde8faec092a7c67b8bd76bbba4a826e61b05c171b97004ce6b308c5a090351

Dynamic libraries can change with system updates; pins are POC evidence, not production identity/platform packaging. No production cache identity wiring exists; these outputs are not current cache. Prior48reference/18malformed tests were not rerun here and remain inherited evidence, not a new combined full-regression claim.

## Pixel/basic/error controls

Probe3 small frames passed six decode/four witness and actual load. Six real tests passed0skip: generation/cross-recovery with geometry/alpha pixels, missing-resource stale-output protection, static/security, marker DOM side-effect veto, :has third-child veto, occlusion timeout. Tests assert supervisor cache/tmp cleanup.

12 original-vs-combo alpha pairs had exact PNG bytes and fullRGBA: e1_pain_card81/82/84 alpha[0,0]/[0,31]/[0,94]; llm_post414/415/417 alpha234/213/170; w_title0/1/3 [0,255];128alpha fixture0/1/3 each5000alpha128 pixels. Original HTML unchanged.

A/AA encode-injection mutants each first genuine3-frame control rc0, then f1-only injection after next installation Promise started. Both tampered rc1/failed[1], f0/f2 successful, stale f1 unchanged/cachetmp empty;0.774/0.824s, no hang. Mutants/raw failures preserved; negative harness rc0 means expected-failure assertions passed.

## Uninstrumented d323 vs combo AB/BA36

Same three read-only original HTMLs, frames30/60/90,1920x1080/b0/native_toPNG/15s/PAGES1. AB then BA,18frames/backend; every page new profile/output, startup included, no artifact hit. OS/font caches not physically cleared.18/18 paired PNG bytes and independently decoded fullRGBA exact. Four witness/six completion/gates verified.

| page | d323 fps | combo fps | speedup |
|---|---:|---:|---:|
| nav_two_pillars | 1.959361 | 2.173491 | 1.109285x |
| open_source_card | 1.682827 | 1.896187 | 1.126787x |
| u2_backends | 2.060630 | 2.254063 | 1.093871x |

Aggregate 9.539383200→8.586640361s = 1.110956x. Separate prior native/yield ratios cannot be multiplied; no direct native-only-vs-combined comparison was run.

## Fresh CEF qualification AB/BA36

Round1 combo→CEF; round2 CEF→combo, each side9frames/round, same three pages/frames/geometry/X11, every page new profile/output, one worker/startup included. CEF tree91f41b35eed2ab592a7125c1640ff5c20149f64b, binary SHA c728509d359e2194450e7d6c440e005cebdeeec8e9441e95876a5fca7b87160c. Original CefWorkerClient/SupervisedProcessGroup, actual mode=a0/serve/sync/n/exact, no encoder override. Every helloPID equals launchedPID, request-id/canary/target-frame exact,1920x1080/stride7680/status0 verified; sequential requests only. Per-page actual argv/env/hello/PID/requests/receipts/log/sync retained, no max2worker or warmhit.

| round | combo wall s | freshCEF wall s | ratio |
|---|---:|---:|---:|
| 1 | 4.191381291 | 3.268879138 | 1.282207483 |
| 2 | 4.239533548 | 3.086550755 | 1.373550570 |
| aggregate | 8.430914839 | 6.355429893 | **1.326568774 FAIL** |

Cross-Chromium RGBA comparisons were observed, never forced to zero; all18 pairs happen to be fullRGBA exact (different_channels0/max_delta0). PNG compression differs, so no cross-backend PNG-byte equality claim. Full differences preserved in qualification-cross-backend-comparisons.json. Real round variation disclosed; no statistical interval/full-film extrapolation.

Observed rusage CPU (not complete process-tree CPU; non-parent-reaped descendants may be absent):

| experiment/backend | child user s | child system s | Python user s | Python system s |
|---|---:|---:|---:|---:|
| ABBA/d323 | 6.505656 | 3.811189 | 0.034101 | 0.035194 |
| ABBA/combo | 4.592936 | 3.026101 | 0.032960 | 0.035238 |
| qualification/combo | 4.664041 | 3.015472 | 0.032940 | 0.026881 |
| qualification/CEF | 2.995207 | 1.538391 | 0.023262 | 0.052392 |

## Isolation, exits and cleanup

rootRO bwrap/private net+PID+dev/tmp/X11socketRO/only this E RW. Exact actual argv/whitelist env each *.command.json; XDG_CONFIG_HOME/CACHE_HOME under E, HOME not overwritten. SDK SHA433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f checked by runner.

probe.py/basic.py/alpha.py/negative.py/bench.py/qualification.py each personally reaped harness0. Expected mutant frame failures rc1 preserved. Harness0 records completed collection; performance sample is FAIL. Original exits/raw logs retained in command-exit-ledger.json. No native session was running at interruption. Final host-/proc check found no E-associated Electron/CEF/bwrap/runner residuals; all supervisor cache/tmp directories empty (cleanup.json). No kill/deletion needed. Before/after source hashes and bench source hashes verified unchanged.

A first report-writing functions.exec tool input failed JavaScript parsing before executing any shell/filesystem command; it did not start a native job or mutate evidence. This corrected report-only command completed0. All actual native exits above are unchanged.

User stopped performance pursuit: no additional optimization/bench/46/450, no production combination. Performance FAIL retained. Report completed; agent stops writing.
