from pathlib import Path
import json,hashlib
from vtx.infra import Ctx
from vtx import gfx_electron as ee
E=Path(__file__).resolve().parent
root=E/'context';root.mkdir(exist_ok=True)
(root/'page.html').write_text('<html><body></body></html>')
(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))
c=Ctx(root/'timeline.json');ee.WORKER_DIR=E/'probe'
page=root/'probe.html';page.write_text('<!doctype html><style>html,body{margin:0;background:rgba(90,120,160,0.5)}</style>')
st=ee.render_page(page,E/'probe-output',3,width=192,height=96,frames=[0,1,2],ctx=c,timeout_s=15)
assert st['exit_code']==0 and st['failed']==[],st
raw=json.loads((Path(st['evidence_dir'])/'result.json').read_text());assert all(r['png_decode_count']==6 and r['witnesses']==4 for r in raw['frames'])
libs=sorted(set(line.split()[-1] for line in (E/'maps/combo-worker.maps').read_text().splitlines() if 'libpng16.so' in line or 'libz.so' in line))
assert libs==['/usr/lib64/libpng16.so.16.58.0','/usr/lib64/libz.so.1.3.1.zlib-ng'],libs
source={'adapter':st,'libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in libs},'addon_sha256':hashlib.sha256((E/'native_png.node').read_bytes()).hexdigest()}
(E/'actual-loaded-deps.json').write_text(json.dumps(source,indent=2));print('PROBE_PASS')
