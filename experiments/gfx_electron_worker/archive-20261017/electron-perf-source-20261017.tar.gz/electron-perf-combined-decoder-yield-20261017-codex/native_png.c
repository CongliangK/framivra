#define NAPI_VERSION 8
#include <node_api.h>
#include <png.h>
#include <zlib.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#define CAP ((size_t)64*1024*1024)
typedef struct { const unsigned char *src; size_t size, off, allocated; unsigned char *rgba; char error[192]; } Context;
typedef union { size_t n; max_align_t align; } Allocation;
static void fail(png_structp p, png_const_charp msg) { Context *c=png_get_error_ptr(p); snprintf(c->error,sizeof(c->error),"PNG:%.180s",msg); png_longjmp(p,1); }
static void warning(png_structp p,png_const_charp msg) { fail(p,msg); }
static png_voidp alloc_png(png_structp p,png_alloc_size_t n) { Context *c=png_get_mem_ptr(p); if(n>CAP || c->allocated>CAP-n || n>SIZE_MAX-sizeof(Allocation))return NULL; Allocation *a=malloc(sizeof(*a)+n); if(!a)return NULL; a->n=n;c->allocated+=n;return a+1; }
static void free_png(png_structp p,png_voidp ptr) { if(!ptr)return;Context *c=png_get_mem_ptr(p);Allocation *a=(Allocation *)ptr-1;c->allocated-=a->n;free(a); }
static void read_png(png_structp p,png_bytep dst,png_size_t n) { Context *c=png_get_io_ptr(p);if(n>c->size-c->off)png_error(p,"truncated input");memcpy(dst,c->src+c->off,n);c->off+=n; }
static uint32_t be32(const unsigned char *p) { return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3]; }
static const char *scan(const unsigned char *p,size_t n) {
 if(n<45 || n>CAP || memcmp(p,"\211PNG\r\n\032\n",8))return "PNG signature/size";
 size_t off=8; unsigned chunks=0;int ihdr=0,idat=0,ended_idat=0,iend=0;
 while(off<n){if(++chunks>4096 || n-off<12)return "PNG chunk bound";uint32_t len=be32(p+off);if(len>CAP || len>n-off-12)return "PNG chunk length";const unsigned char *t=p+off+4;
  for(int i=0;i<4;i++)if(!((t[i]>='a'&&t[i]<='z')||(t[i]>='A'&&t[i]<='Z')))return "PNG chunk type";
  if(t[2]&32)return "PNG reserved bit";
  if((uint32_t)crc32(crc32(0L,Z_NULL,0),t,(uInt)len+4)!=be32(p+off+8+len))return "PNG CRC";
  if(!memcmp(t,"IHDR",4)){if(ihdr||off!=8||len!=13)return "PNG IHDR";ihdr=1;}
  else if(!memcmp(t,"IDAT",4)){if(!ihdr||ended_idat)return "PNG IDAT order";idat=1;}
  else {if(idat)ended_idat=1;if(!memcmp(t,"IEND",4)){if(!idat||len||off+12!=n)return "PNG IEND";iend=1;}}
  off+=(size_t)len+12;
 }
 return ihdr&&idat&&iend?NULL:"PNG missing chunks";
}
static napi_value error(napi_env env,const char *msg){napi_throw_error(env,NULL,msg);return NULL;}
static napi_value decode(napi_env env,napi_callback_info info){
 size_t argc=3; napi_value argv[3], result;bool isbuffer=false;double wd,hd;void *data;size_t size;
 if(napi_get_cb_info(env,info,&argc,argv,NULL,NULL)!=napi_ok||argc!=3||napi_is_buffer(env,argv[0],&isbuffer)!=napi_ok||!isbuffer||napi_get_buffer_info(env,argv[0],&data,&size)!=napi_ok||napi_get_value_double(env,argv[1],&wd)!=napi_ok||napi_get_value_double(env,argv[2],&hd)!=napi_ok)return error(env,"PNG arguments");
 if(!(wd>=1&&wd<=3840&&hd>=1&&hd<=2160)||wd!=(unsigned)wd||hd!=(unsigned)hd||wd*hd>8294400)return error(env,"PNG geometry bounds");
 unsigned width=(unsigned)wd,height=(unsigned)hd;const char *bad=scan(data,size);if(bad)return error(env,bad);
 const unsigned char *ih=(unsigned char *)data+16;
 if(be32(ih)!=width||be32(ih+4)!=height||ih[8]!=8||(ih[9]!=2&&ih[9]!=6)||ih[10]||ih[11]||ih[12])return error(env,"PNG geometry/format");
 Context *c=calloc(1,sizeof(*c));if(!c)return error(env,"PNG allocation");c->src=data;c->size=size;
 size_t bytes=(size_t)width*height*4;if(napi_create_buffer(env,bytes,(void **)&c->rgba,&result)!=napi_ok){free(c);return error(env,"PNG output buffer");}
 png_structp p=png_create_read_struct_2(PNG_LIBPNG_VER_STRING,c,fail,warning,c,alloc_png,free_png);if(!p){free(c);return error(env,"PNG read allocation");}
 png_infop pi=png_create_info_struct(p);if(!pi){png_destroy_read_struct(&p,NULL,NULL);free(c);return error(env,"PNG info allocation");}
 if(setjmp(png_jmpbuf(p))){char message[192];snprintf(message,sizeof(message),"%s",c->error);png_destroy_read_struct(&p,&pi,NULL);free(c);return error(env,message);}
 png_set_read_fn(p,c,read_png);png_set_user_limits(p,3840,2160);png_set_chunk_malloc_max(p,CAP);png_set_chunk_cache_max(p,128);png_set_crc_action(p,PNG_CRC_ERROR_QUIT,PNG_CRC_ERROR_QUIT);
 png_read_info(p,pi);
 if(png_get_image_width(p,pi)!=width||png_get_image_height(p,pi)!=height||png_get_bit_depth(p,pi)!=8||png_get_interlace_type(p,pi)!=PNG_INTERLACE_NONE)png_error(p,"geometry/format");
 int type=png_get_color_type(p,pi);if(type==PNG_COLOR_TYPE_RGB)png_set_add_alpha(p,255,PNG_FILLER_AFTER);else if(type!=PNG_COLOR_TYPE_RGBA)png_error(p,"color type");
 // Deliberately no gamma/ICC/background/alpha association transform.
 png_read_update_info(p,pi);if(png_get_rowbytes(p,pi)!=(size_t)width*4||png_get_channels(p,pi)!=4)png_error(p,"RGBA geometry");
 
 for(unsigned y=0;y<height;y++)png_read_row(p,c->rgba+(size_t)y*width*4,NULL);
 png_read_end(p,pi);if(c->off!=size)png_error(p,"unread input");png_destroy_read_struct(&p,&pi,NULL);
 free(c);return result;
}
static napi_value init(napi_env env,napi_value exports){napi_value fn;if(napi_create_function(env,"decode",NAPI_AUTO_LENGTH,decode,NULL,&fn)!=napi_ok||napi_set_named_property(env,exports,"decode",fn)!=napi_ok)return NULL;return exports;}
NAPI_MODULE(NODE_GYP_MODULE_NAME,init)
