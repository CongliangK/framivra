import os,json,time,hashlib,resource,struct
from pathlib import Path
from PIL import Image,ImageChops
from vtx.infra import Ctx
from vtx import gfx_electron as ee
from vtx.cef_client import CefWorkerClient
from vtx.proc_supervisor import SupervisedProcessGroup
E=Path(__file__).resolve().parent
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-cef-final-20261016')
CEF=T/'experiments/gfx_cef_worker/build/bin/vtx_cef_worker'
PAGES=['nav_two_pillars','open_source_card','u2_backends'];FRAMES=[30,60,90]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(CEF)=='c728509d359e2194450e7d6c440e005cebdeeec8e9441e95876a5fca7b87160c'
c=Ctx(E/'context/timeline.json');ee.WORKER_DIR=E/'new'
def cpu():
 a=resource.getrusage(resource.RUSAGE_CHILDREN);b=resource.getrusage(resource.RUSAGE_SELF)
 return dict(child_user=a.ru_utime,child_system=a.ru_stime,self_user=b.ru_utime,self_system=b.ru_stime)
def cef(page,out):
 out.mkdir(parents=True);fds=[];env=dict(os.environ);rows=[];hello=None;record={}
 def argv(run,profile):
  fd=os.open(run,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);fds.append(fd);env['TMPDIR']=f'/proc/{os.getpid()}/fd/{fd}'
  args=[str(CEF),'--mode=a0','--serve','--sync','--sync-mode=n','--sync-canary=exact','--sync-log=sync.jsonl','--ipc-socket=ipc.sock',f'--root-cache-path={profile}',f'--url-template={page.as_uri()}?f={{f}}','--width=1920','--height=1080']
  record.update(argv=args,environment=env.copy(),profile=str(profile),run_dir=str(run));return args
 try:
  with open(out/'worker.log','wb') as log:
   with SupervisedProcessGroup(c,argv,backend_id='qualification_cef_a0',stdout=log,stderr=log,env=env) as g:
    record['pid']=g.proc.pid;(out/'request.json').write_text(json.dumps(record,indent=2))
    with CefWorkerClient.connect(f'/proc/{os.getpid()}/fd/{fds[-1]}/ipc.sock',connect_timeout=45) as client:
     hello=client.hello.copy();assert hello['pid']==g.proc.pid,hello
     assert hello['max_width']>=1920 and hello['max_height']>=1080
     for rid,f in enumerate(FRAMES,1):
      t=time.perf_counter();r=client.request_png(f,'frame.png',request_id=rid,expected_wh=(1920,1080),worker_relative=True)
      h=r.header;assert h['canary_frame_index']==f and h['target_frame_index']==f and h['request_id']==rid and h['width']==1920 and h['height']==1080 and h['stride']==7680 and h['status_code']==0,h
      target=out/f'f{f:04d}.png';payload=(g.run_dir/'frame.png').read_bytes();assert payload[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',payload[16:24])==(1920,1080);target.write_bytes(payload)
      rows.append(dict(frame=f,request_wall_s=time.perf_counter()-t,receipt=h,png_sha256=sha(target)))
    rc=g.proc.wait(timeout=15);assert rc==0
    if (g.run_dir/'sync.jsonl').exists():(out/'sync.jsonl').write_bytes((g.run_dir/'sync.jsonl').read_bytes())
    record.update(exit_code=rc,hello=hello,receipts=rows);(out/'result.json').write_text(json.dumps(record,indent=2))
 finally:
  for fd in fds:os.close(fd)
 return rows
rows=[]
for rnd,order in enumerate((('combo','cef'),('cef','combo')),1):
 for backend in order:
  for name in PAGES:
   page=SRC/(name+'.html');before=sha(page);out=E/f'qualification-round{rnd}'/backend/name
   t=time.perf_counter();b=cpu();started=time.time();print('BEGIN',rnd,backend,name,flush=True)
   if backend=='combo':
    st=ee.render_page(page,out,91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15,mode='b0',output='electron_native_topng');assert st['exit_code']==0 and st['failed']==[] and st['errors']=={},st
    raw=json.loads((Path(st['evidence_dir'])/'result.json').read_text());detail=raw['frames'];assert raw['max_inflight']==1 and raw['decoder_threads']==1
    assert all(r['witnesses']==4 and r['png_decode_count']==6 and all(r[k] for k in ['baseline_veto_passed','png_semantics_passed','page_error_fence_passed']) for r in detail)
   else:detail=cef(page,out)
   a=cpu();r=dict(round=rnd,backend=backend,page=name,frames=FRAMES,source_sha256=before,started_epoch=started,wall_s=time.perf_counter()-t,cpu_delta_s={k:a[k]-b[k] for k in a},frame_receipts=detail)
   assert sha(page)==before;rows.append(r);(E/'qualification-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('END',rnd,backend,name,r['wall_s'],flush=True)
comparisons=[]
for rnd in (1,2):
 for name in PAGES:
  for f in FRAMES:
   paths=[E/f'qualification-round{rnd}'/b/name/f'f{f:04d}.png' for b in ('combo','cef')];ims=[Image.open(p).convert('RGBA') for p in paths];raw=[im.tobytes() for im in ims];diff=ImageChops.difference(*ims);hist=diff.histogram()
   count=sum(x!=y for x,y in zip(*raw));mae=sum(i%256*v for i,v in enumerate(hist))/(1920*1080*4)
   comparisons.append(dict(round=rnd,page=name,frame=f,png_sha256=[sha(p) for p in paths],rgba_sha256=[hashlib.sha256(x).hexdigest() for x in raw],different_channels=count,mae=mae,max_channel_delta=max(max(ch.getextrema()) for ch in diff.split())))
(E/'qualification-cross-backend-comparisons.json').write_text(json.dumps(comparisons,indent=2))
rounds=[]
for rnd in (1,2):
 totals={b:sum(r['wall_s'] for r in rows if r['backend']==b and r['round']==rnd) for b in ['combo','cef']};rounds.append(dict(round=rnd,**totals,ratio=totals['combo']/totals['cef']))
totals={b:sum(r['wall_s'] for r in rows if r['backend']==b) for b in ['combo','cef']};ratio=totals['combo']/totals['cef']
(E/'qualification-summary.json').write_text(json.dumps(dict(scope='fresh single-worker cold startup, 9frames/backend/round, combo then CEF / CEF then combo',rounds=rounds,aggregate=totals,aggregate_ratio=ratio,threshold=1.25,performance_sample_admission='PASS' if ratio<=1.25 else 'FAIL',cef_binary_sha256=sha(CEF)),indent=2));print('QUALIFICATION_DONE',ratio,flush=True)
