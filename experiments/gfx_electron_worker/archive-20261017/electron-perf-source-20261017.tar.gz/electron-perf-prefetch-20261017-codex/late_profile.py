import os,sys,json,time,hashlib,resource
from pathlib import Path
from PIL import Image
from vtx.infra import Ctx
from vtx import gfx_electron as candidate_ee
import importlib.util
spec=importlib.util.spec_from_file_location('vtx.baseline_electron', '/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/vtx/gfx_electron.py')
baseline_ee=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline_ee)
E=Path(__file__).resolve().parent
SRC=Path('/home/liangruochong/文档/04_bilibili视频/voice-ime-alpha-electron-20261016/gfx')
ROOT=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees')
WORKERS={'old':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker','new':E/'diag-after_witnesses'}
PAGES=['nav_two_pillars','open_source_card','u2_backends'];FRAMES=[30,60,90]
root=E/'context';root.mkdir(exist_ok=True)
(root/'page.html').write_text('<html><body></body></html>')
(root/'timeline.json').write_text(json.dumps(dict(version=2,project=dict(fps=30,width=1920,height=1080,duration_frames=91),sources=[],subtitles=[],audio_tracks=[],video_tracks=[dict(name='g',kind='gfx',clips=[dict(src='page.html',dst_in=0,dur=91)])])))
c=Ctx(root/'timeline.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cpu():
 a=resource.getrusage(resource.RUSAGE_CHILDREN);b=resource.getrusage(resource.RUSAGE_SELF)
 return dict(child_user=a.ru_utime,child_system=a.ru_stime,self_user=b.ru_utime,self_system=b.ru_stime)
ee=candidate_ee;ee.WORKER_DIR=E/'diag-late-profile'
page=SRC/'open_source_card.html';st=ee.render_page(page,E/'late-profile-output',91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15)
(E/'late-profile-summary.json').write_text(json.dumps(st,indent=2))
assert st['exit_code']==0 and not st['failed'],st
