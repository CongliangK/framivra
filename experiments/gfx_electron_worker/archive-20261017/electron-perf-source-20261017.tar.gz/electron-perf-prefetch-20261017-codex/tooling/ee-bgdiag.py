from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
d=E/'diag-explicit_bg';shutil.copytree(E/'diag-refresh',d)
p=d/'navigation_worker.mjs';s=p.read_text().replace('show:false, frame:false, transparent:true,',"show:false, frame:false, transparent:true, backgroundColor:'#00000000',");p.write_text(s)
s=(E/'diag_fixture.py').read_text().replace('range(5)','range(12)').replace("['base','no_refresh','refresh']", "['base','refresh','explicit_bg']").replace("f'diag-runs/{i}/{label}'", "f'diag-bg-runs/{i}/{label}'").replace("E/'diag-results.json'", "E/'diag-bg-results.json'")
(E/'diag_bg.py').write_text(s)
