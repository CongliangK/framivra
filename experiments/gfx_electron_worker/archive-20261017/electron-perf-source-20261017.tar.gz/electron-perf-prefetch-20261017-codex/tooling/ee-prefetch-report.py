from pathlib import Path
import hashlib,json,subprocess,os
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra');E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
ledger={p.name.removesuffix('.exit.json'):json.loads(p.read_text())['exit_code'] for p in E.glob('*.exit.json')}
ledger.update({'non_native_wrong_test_class':1,'non_native_adapter_suite_attempt1':0,'non_native_adapter_suite_attempt2':0,'evidence_source_reconstruction_attempt1':1,'evidence_source_reconstruction_corrected':0,'git_diff_check':0})
(E/'command-exit-ledger.json').write_text(json.dumps(ledger,indent=2))
# Summarize causal controls; all published candidate frames have explicit exact comparisons.
summary={}
for name in ['diag-results','diag-bg-results','diag-late-results']:
 rows=json.loads((E/(name+'.json')).read_text());out={}
 for r in rows:
  z=out.setdefault(r['label'],{'runs':0,'requested_frames':0,'failed_frames':[]});z['runs']+=1;z['requested_frames']+=3;z['failed_frames']+=r['result']['failed']
 summary[name]=out
(E/'causal-summary.json').write_text(json.dumps(summary,indent=2))
# Failed byte data: compare raw RGBA against full native witness reconstruction.
diffs=[]
for p in E.glob('diag*-runs/*/*/diag-*-baseline.bin'):
 a=p.read_bytes();b=p.with_name(p.name.replace('baseline','expected')).read_bytes();ids=[i//4 for i in range(0,len(a),4) if a[i:i+4]!=b[i:i+4]]
 diffs.append({'path':str(p.relative_to(E)),'differing_pixels':len(ids),'bbox':[min(x%192 for x in ids),min(x//192 for x in ids),max(x%192 for x in ids),max(x//192 for x in ids)],'first_16':[[j%192,j//192,list(a[j*4:j*4+4]),list(b[j*4:j*4+4])] for j in ids[:16]],'baseline_sha256':hashlib.sha256(a).hexdigest(),'witness_expected_sha256':hashlib.sha256(b).hexdigest()})
(E/'transparent-failure-pixel-analysis.json').write_text(json.dumps(diffs,indent=2))
# Existing diagnostic successes plus late group's success comparisons.
from PIL import Image
pairs=[]
for d in (E/'diag-late-runs').glob('*'):
 for label in ['no_refresh','after_witnesses']:
  for f in [3,0,2]:
   a=d/'base'/f'f{f:04d}.png';b=d/label/a.name
   if b.exists():
    equal=a.read_bytes()==b.read_bytes() and Image.open(a).convert('RGBA').tobytes()==Image.open(b).convert('RGBA').tobytes();assert equal
    pairs.append({'round':int(d.name),'candidate':label,'frame':f,'png_and_full_rgba_equal':equal,'sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
(E/'late-diagnostic-success-comparisons.json').write_text(json.dumps(pairs,indent=2))
# Runtime profiles and known command lines after supervised cleanup.
cleanup={'remaining_profiles':[str(p) for p in E.rglob('cache/tmp/*')],'source_frozen':True,'note':'No native sessions or complete process-tree RSS were measured. No 450 batch was started after explicit stage restriction.'}
# Match only executable command argv, not this inspection's script text.
alive=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:
   args=(p/'cmdline').read_bytes().split(b'\0');first=args[0].decode(errors='replace')
   if ('electron' in Path(first).name or 'vtx_cef_worker' in Path(first).name) and any(str(E).encode() in a or str(T).encode() in a for a in args):alive.append({'pid':int(p.name),'argv':[a.decode(errors='replace') for a in args if a]})
  except (OSError,IndexError):pass
cleanup['live_matching_native_processes']=alive
(E/'cleanup-check.json').write_text(json.dumps(cleanup,indent=2))
files=json.loads((E/'pre-late-source-snapshot.json').read_text())['files'];assert all(hashlib.sha256((T/p).read_bytes()).hexdigest()==h for p,h in files.items())
(E/'candidate.diff').write_bytes(subprocess.check_output(['git','diff'],cwd=T))
source={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for pattern in ['run2-source/**/*','initial-reconstruction/**/*','diag-*/*.mjs','tooling/*.py','*.py','initial-bench-worker.mjs'] for p in E.glob(pattern) if p.is_file()}
(E/'source-sha256.json').write_text(json.dumps({'worktree_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=T,text=True).strip(),'candidate_files':files,'evidence_files':source},indent=2))
report='''# EE-PERF-3: bounded document prefetch — HOLD / NOT ACCEPTED

Task ID EE-PERF-3. Base `d32310853d6136f3f621a356b0c2718c7fab1a25`; managed worktree `/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra`. No add/commit/reset/checkout/stash/branch/push, original HTML/timeline/fonts/style/audio edits, full-film restart, PR update, or merge. Current source is the **failed run2 implementation**, frozen for review, and MUST NOT be integrated. Late after-witnesses exists only as an evidence copy, not an accepted implementation.

## Implemented candidate and explicit limits

Five modified files: worker runtime/tests, Python adapter and completion reader, integration tests. create context → isolated session/window/document preparation → promotion readiness recheck → exclusive baseline/nonce/decode capture → close/drain. It prepares only one next document, never reuses document/navigation, preserves six native PNG encodes/full RGBA decodes, four nonce paints, baseline veto, Promise/child page gates, 40ms/100ms/15s thresholds. Decoder begin occurs only in current's ordered turn; failed pre-capture generations get explicit empty begin/drain to retain generation continuity.

Schema `/2` and caller `scheduling` explicitly bind max_inflight=2, max_live_documents=2, max_capture_inflight=1, prefetch_limit=1, decoder_threads=1, max_pending_decodes=6. Adapter validates declared values/type and in-flight range, completion reader requires live/capture zero. Observed peak counters were 2 documents/1 capture. These are runtime counters, not independent native enumeration. Unique nonpersistent session per generation isolates resource pending/errors/epoch and CDP error gate. `sessions_created` is lifetime created count; native retained session count and complete-tree RSS are UNKNOWN because 450 acceptance was explicitly deferred after correctness failure.

Deadline uses monotonic time from before context creation; promotion does not reset it. Each bounded prep await uses remaining time, and the original whole-batch watchdog exits 72 on 15s deadline, including a timed-out ahead document. A timed_out latch prevents teardown reentrancy from overriding 72 with final app.exit(1). Ordinary prep error closes only its context, is recorded in ordered turn, and does not contaminate current page errors/resources. There is no new await from final page/resource fence to atomic PNG publication.

## Initial exploratory native AB/BA (early prefetch)

Same three read-only original experimental HTMLs, f30/60/90, 1920×1080, b0/PAGES1/15s, two AB/BA rounds = 36 frames. New cold profile/output per invocation, no cached result reuse. Actual binary SHA is pinned by run.py to `433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f`. rootRO/private PID+net+dev/physical tmp/X11 socket RO/only this E writable. Actual argv/environment in `*.command.json`. HOME was not repurposed; XDG_CONFIG_HOME/XDG_CACHE_HOME point into this E.

| Page | d323-equivalent base fps | Early candidate fps | Speedup |
|---|---:|---:|---:|
| nav_two_pillars | 1.928 | 2.489 | 1.291× |
| open_source_card | 1.683 | 2.059 | 1.224× |
| u2_backends | 2.096 | 2.390 | 1.140× |

18 pairs PNG bytes and full decoded RGBA identical. `initial-native-results.json` preserves child/self user/system CPU separately; CPU figures are observed rusage, not whole-tree CPU. This is a failed early design's exploratory performance sample, **not an accepted final benchmark or evidence for late prefetch**. Current identity is not allowed to reuse older cache. No fresh CEF sample was taken; historical CEF is not asserted as contemporary.

## Real transparent regression and causal controls

Initial regression: 48 tests / 48.002s / rc1 / 7 failures / 0 skips. Real bugs included skipped decoder generation after prep failure and watchdog teardown overriding exit72. The first delayed-error fixture was too late for fast 192×96 capture, and one child fixture tried document.body before it existed. All failures remain. Run2 corrected those issues: 48 / 51.985s / rc1 / 2 failures / 0 skips. Remaining failures are the existing transparent navigation fixture and real 1s all/QC path, both baseline-veto rejection. It is NOT a functional pass.

Evidence-only copies preserve actual baseline PNG/full RGBA and native-witness-derived ar/br/expected/clean buffers on rejection; no baseline is used to recover output. A representative failure has 18,021 changed pixels, bbox x0..191/y1..94: baseline RGBA [199,100,40,128] became witness RGBA [227,177,147,255], exactly compatible with white compositing; formerly alpha0 pixels became opaque white. **White compositing is observed; native compositor root cause is NOT proven.**

Same unmodified transparent navigation fixture f3/0/2 in separate cold invocations:

| Group | Base | Early no refresh | Early extra unmarked refresh | Explicit native transparent background | After all four witness PNGs |
|---|---|---|---|---|---|
| Initial 5 repeats | 0/15 failed | 2/15 failed | 0/15 failed | — | — |
| Further 12 repeats | 0/36 failed | — | 4/36 failed | 3/36 failed | — |
| Late causal 12 repeats | 0/36 failed | 3/36 failed | — | — | 0/36 failed |

Extra unmarked refresh and explicit BrowserWindow backgroundColor=#00000000 are rejected as reliable fixes. The late evidence copy starts next context only after bb's fourth nonce native PNG is already captured, before joining five decodes and reconstructing/final-decode/publish. It omits the extra refresh. All 36 late PNGs exactly match base bytes and full RGBA; successfully published early diagnostic outputs also match their own base controls (93 earlier + late comparison file). Twelve repeats are limited evidence, not proof over arbitrary content or real fractional pages. Remaining capture overlap is only decode join/reconstruction/final decode/fence/write, so original early gains cannot be carried over. The late 1080p benchmark/profile scripts are prepared but **unrun**, per controller restriction to the causal group and transfer of the native window to the next experiment.

## Regression scope and missing acceptance

Run2 passed existing marker-sideeffect/JS/Promise/three-child, genuine whole-batch 15s=72, parent liveness/SIGKILL cleanup, caller source/config/tamper checks and per-frame ordinary error recovery. New ordinary error tests genuine rc0-control first, then missing resource/JS throw/Promise/child error confined to f1 with f0/f2 receipts. These delayed injections used 1080p for reliable duration, but exact injection-vs-capture timestamps were not independently recorded; the new fixture has one child while prior gate tests cover three children. Do not claim fully witnessed late third-child isolation coverage.

Not completed/NOT PASS: 450-frame batch, native retained sessions/full-tree RSS/CPU, final 36-frame late performance, real original fractional alpha +128 late acceptance, fresh CEF, frozen final regression, final identity release/cache admission, independent review, full-film or PR merge. Controller explicitly deferred long validation until a minimal correct late design shows worthwhile gain. This report stops at the requested causal group. Current production source remains failed/HOLD.

## Stable sources, command exits, and cleanup

`run2-source/` contains all five complete source files and matches pre-late-source-snapshot byte-for-byte. `initial-reconstruction/` is complete initial-regression source rebuilt deterministically from d323 and the preserved actual edit scripts. `initial-bench-worker.mjs` matches the exact SHA recorded by the original benchmark. `attempt-source-sha256.json`, `source-sha256.json`, `pre-late.diff`, and `candidate.diff` pin them and all diagnostic modules/scripts. No candidate runtime source changed during any native or regression invocation.

Evidence reconstruction itself first failed because exec reused a script variable and reran the contract editor on the current worktree while this task held no native job. It was immediately restored from complete run2-source and all five hashes reverified; that failure and corrected script are preserved. An initial host unittest command named a nonexistent class (rc1), followed by two correct module invocations (rc0, 13 pass/2 native opt-in skips); these are not final native regressions.

Every native invocation has a collected `*.exit.json`, log, command argv/environment; aggregate `command-exit-ledger.json`. Native run exits: initial_bench=0, regression_initial=1, regression_run2=1, diag_fixture=0, diag_bg=0, diag_late=0. No failed attempt or output was removed. `cleanup-check.json` records no matching live native processes/profiles after the final group. Native timing window has been released to controller. No background job remains.
'''
(E/'REPORT.md').write_text(report)
print(json.dumps({'ledger':ledger,'causal_summary':summary,'cleanup':cleanup},indent=2))
