from pathlib import Path
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra')
p=T/'experiments/gfx_electron_worker/navigation_worker.mjs'
s=p.read_text().replace('// One fresh WebContents per frame, one in-flight frame, no SHM/native helper.','// Two fresh isolated documents at most; only one capture/decoder generation.')
s=s.replace("import crypto from 'node:crypto';", "import crypto from 'node:crypto';\nimport { performance } from 'node:perf_hooks';")
s=s.replace('async function renderFrame(f, generation, ses, pageErrors, decoder) {\n  const start = Date.now();\n  decoder.begin(f, generation);', '''function createFrameContext(f, generation, pageErrors, decoder, result) {
  // Start before session/window creation; promotion NEVER resets this budget.
  const start = performance.now();
  const remaining = () => Math.max(1, timeoutMs-(performance.now()-start));
  const ses = createSession(`vtx-${runId}-${generation}`);
  result.sessions_created++;
  let closed = false, capturing = false;
  const watchdog = setTimeout(() => {
    if (!result.failed.includes(f)) result.failed.push(f);
    result.errors[f]='timeout:frame';
    atomicWrite(job.result,JSON.stringify(result,null,2));
    // Preserve the existing whole-batch timeout exit contract, including a
    // timeout in the ahead document while current capture is still running.
    app.exit(72);
  }, remaining());''')
s=s.replace('  const wc = win.webContents;', '''  result.live_documents++;
  result.peak_live_documents=Math.max(result.peak_live_documents,result.live_documents);
  if (result.live_documents>2) throw Error('live_document_limit');
  const wc = win.webContents;''')
s=s.replace("Math.max(1, timeoutMs-(Date.now()-start))", "remaining()")
start=s.index('  try {\n    // Materialize a script-free renderer')
end=s.index('    const resourceEpoch = ses._vtxEpoch;',start)
prep=s[start:end]
prep=prep.replace('  try {','  async function prepare() {',1).replace(', timeoutMs,',', remaining(),')
# Resource checks need repeated again at promotion, without loading any document.
resource_start=prep.index('    await deadline(isolated(wc,')
checks=prep[resource_start:]
prep=prep[:resource_start]+'    await ready();\n  }\n  async function ready() {\n'+checks+'  }\n'
s=s[:start]+prep+'''  async function capture() {
    if (closed) throw fatal || Error('closed_context');
    capturing = true;
    result.capture_inflight++;
    result.peak_capture_inflight=Math.max(result.peak_capture_inflight,result.capture_inflight);
    if (result.capture_inflight!==1) throw Error('capture_limit');
    decoder.begin(f,generation);
    // Recheck all readiness and the error checkpoint after waiting in the
    // ahead slot. The epoch is frozen only AFTER this promotion fence.
    await ready();
'''+s[end:]
s=s.replace('elapsed_ms:Date.now()-start','elapsed_ms:performance.now()-start')
a=s.index('  } finally {\n    errorGate?.close();')
b=s.index('async function main() {',a)
s=s[:a]+'''  }
  async function close() {
    if (closed) return;
    closed=true;
    errorGate?.close(); if (!win.isDestroyed()) win.destroy();
    result.live_documents--;
    // Only the exclusive capture owner may touch/drain the shared decoder.
    if (capturing) {
      await decoder.drain();
      result.capture_inflight--;
    }
    clearTimeout(watchdog);
  }
  // Observe prep rejection immediately: ahead errors are private until their
  // ordered turn and must never become host unhandled Promise rejections.
  const prepared=prepare().then(() => null, async e => {
    fatal ||= e; await close(); return fatal;
  });
  return {f, prepared, capture, close};
}
function createSession(partition) {
  // Unique session per generation prevents worker/request/late callback state
  // from ever being inherited by another document. Native registry lifetime is
  // batch-scoped; report session count honestly rather than claim two sessions.
  const ses = session.fromPartition(partition, {cache:false});
'''+s[b:]
# pull session listener setup out of main and make factory return
s=s.replace("async function main() {\n  fs.mkdirSync(job.out_dir,{recursive:true});\n  const ses = session.fromPartition(`vtx-${runId}`, {cache:false});\n",'')
s=s.replace("  const result = {schema:'vtx.electron.navigation/1'", "  return ses;\n}\nasync function main() {\n  fs.mkdirSync(job.out_dir,{recursive:true});\n  const result = {schema:'vtx.electron.navigation/2'")
s=s.replace('max_inflight:1,decoder_threads:1,max_pending_decodes:6,','max_inflight:2,max_live_documents:2,max_capture_inflight:1,prefetch_limit:1,\n    live_documents:0,peak_live_documents:0,capture_inflight:0,peak_capture_inflight:0,sessions_created:0,\n    decoder_threads:1,max_pending_decodes:6,')
a=s.index('  let generation=0;');b=s.index('  atomicWrite(job.result,JSON.stringify(result,null,2));\n  await decoder.close();',a)
s=s[:a]+'''  let generation=0;
  const create = f => {
    result.page_errors[f]=[];
    return createFrameContext(f,++generation,result.page_errors[f],decoder,result);
  };
  let current=frames.length ? create(frames[0]) : null;
  for (let i=0;i<frames.length;i++) {
    const f=frames[i];
    let next=null;
    try {
      const preparationError=await current.prepared;
      if (preparationError) throw preparationError;
      // Launch only one ahead; no nonce/baseline/decode until prior close.
      if (i+1<frames.length) next=create(frames[i+1]);
      result.frames.push(await current.capture());
    } catch(e) {
      if (!result.failed.includes(f)) result.failed.push(f);
      result.errors[f] ||= String(e?.stack||e).slice(0,4000);
    } finally { await current.close(); }
    atomicWrite(job.result,JSON.stringify(result,null,2));
    current=next || (i+1<frames.length ? create(frames[i+1]) : null);
  }
'''+s[b:]
p.write_text(s)
