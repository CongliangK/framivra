from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex');E.mkdir(exist_ok=True)
P=E.parent/'electron-perf-pipeline-20261017-codex';T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra');B=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron/dist/electron')
r=(P/'tooling/run.py').read_text();r=r.replace(str(P),str(E)).replace("T=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017');B=T.parent/'alpha-electron-fix2-20261016/experiments/gfx_electron_worker/node_modules/electron/dist/electron'",f'T=Path({str(T)!r});B=Path({str(B)!r})');r=r.replace("HOME=str(E/'home'),", "XDG_CONFIG_HOME=str(E/'home/config'),XDG_CACHE_HOME=str(E/'home/cache'),")
# Current observed Xauthority, no inherited unsupported state.
auth=next(Path('/run/user/1000').glob('.mutter-Xwaylandauth.*'));r=r.replace('/run/user/1000/.mutter-Xwaylandauth.9B7LX3',str(auth));(E/'run.py').write_text(r)
b=(P/'final_bench.py').read_text();b=b.replace("'old':ROOT/'alpha-electron-perf-20261017/experiments/gfx_electron_worker','new':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker'",f"'old':ROOT/'alpha-electron-pipeline-20261017/experiments/gfx_electron_worker','new':Path({str(T/'experiments/gfx_electron_worker')!r})")
b=b.replace('from vtx import gfx_electron as ee','''from vtx import gfx_electron as candidate_ee
import importlib.util
spec=importlib.util.spec_from_file_location('vtx.baseline_electron', '/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017/vtx/gfx_electron.py')
baseline_ee=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline_ee)''');b=b.replace('  ee.WORKER_DIR=WORKERS[backend]','  ee=baseline_ee if backend=="old" else candidate_ee\n  ee.WORKER_DIR=WORKERS[backend]');(E/'initial_bench.py').write_text(b.replace('final-native','initial-native').replace('final-rgba','initial-rgba'))
(E/'regression_initial.py').write_text((P/'regression_final.py').read_text().replace('regression-final','regression-initial'))
