from pathlib import Path
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra')
p=T/'experiments/gfx_electron_worker/navigation_worker.mjs';s=p.read_text();s=s.replace("result.errors[f]='timeout:frame';", "result.errors[f]='timeout:frame'; result.timed_out=true;")
s=s.replace('let fatal = null, paints = 0, rejected = 0, active = null;','let fatal = null, paints = 0, rejected = 0, active = null, unmarkedPaint = null;')
s=s.replace('    paints++;\n    if (!active) return;', '    paints++;\n    unmarkedPaint?.(); unmarkedPaint=null;\n    if (!active) return;')
s=s.replace('    const baselineImage = await wc.capturePage();', '''    // A prepared OSR document may have completed resources without producing
    // a new compositor frame. Refresh the unmarked veto snapshot before asking
    // capturePage; this paint is never used as attested output pixel evidence.
    await deadline(new Promise(resolve => { unmarkedPaint=resolve; wc.invalidate(); }), remaining(), 'unmarked_refresh');
    const baselineImage = await wc.capturePage();''')
s=s.replace('return {f, prepared, capture, close};', '''return {f, prepared, capture, close,
    skip: async () => { decoder.begin(f,generation); await decoder.drain(); }};''')
s=s.replace('      if (preparationError) throw preparationError;', '      if (result.timed_out) return;\n      if (preparationError) { await current.skip(); throw preparationError; }')
s=s.replace('    atomicWrite(job.result,JSON.stringify(result,null,2));\n    current=next', '    if (result.timed_out) return;\n    atomicWrite(job.result,JSON.stringify(result,null,2));\n    current=next')
p.write_text(s)
p=T/'vtx/gfx_electron.py';s=p.read_text().replace('raw["live_documents"] == 0','0 <= raw["live_documents"] <= 2').replace('raw["capture_inflight"] == 0','0 <= raw["capture_inflight"] <= 1');p.write_text(s)
p=T/'vtx/gfx_electron_stage.py';s=p.read_text().replace('or not valid_schedule(raw)', 'or not valid_schedule(raw) or raw.get("live_documents") != 0\n                or raw.get("capture_inflight") != 0 or raw.get("timed_out")');p.write_text(s)
p=T/'experiments/gfx_electron_worker/test_navigation.py';s=p.read_text().replace('width=192,height=96,frames=list(frames),ctx=self.ctx,**kwargs)',"width=kwargs.pop('width',192),height=kwargs.pop('height',96),frames=list(frames),ctx=self.ctx,**kwargs)")
s=s.replace('document.body.append(child)', 'document.documentElement.append(child)')
# Full native capture ensures the delayed error genuinely happens while ahead.
s=s.replace('self.render(page,frames=[0,1,2],n=3)', 'self.render(page,frames=[0,1,2],n=3,width=1920,height=1080)')
p.write_text(s)
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex');s=(E/'regression_initial.py').read_text().replace('regression-initial','regression-run2');(E/'regression_run2.py').write_text(s)
