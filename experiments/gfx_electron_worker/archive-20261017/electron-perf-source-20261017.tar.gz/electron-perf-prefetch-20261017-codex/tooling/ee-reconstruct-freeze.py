from pathlib import Path
import subprocess,json,hashlib
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra');E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
files=subprocess.check_output(['git','diff','--name-only'],cwd=T,text=True).splitlines()
for label in ['run2-source','initial-reconstruction']:
 root=E/label
 for f in files:
  p=root/f;p.parent.mkdir(parents=True,exist_ok=True)
  p.write_bytes((T/f).read_bytes() if label=='run2-source' else subprocess.check_output(['git','show','HEAD:'+f],cwd=T))
recon=E/'initial-reconstruction'
for file in ['ee-prefetch-patch.py','ee-prefetch-contract.py']:
 s=(Path('/tmp')/file).read_text().replace(str(T),str(recon));exec(compile(s,file,'exec'))
bench_worker=(recon/'experiments/gfx_electron_worker/navigation_worker.mjs').read_bytes()
observed=json.loads((E/'initial-native-results.json').read_text());expected=next(r['worker_hashes']['navigation_worker.mjs'] for r in observed if r['backend']=='new')
assert hashlib.sha256(bench_worker).hexdigest()==expected
(E/'initial-bench-worker.mjs').write_bytes(bench_worker)
s=Path('/tmp/ee-prefetch-tests.py').read_text().replace(str(T),str(recon));exec(compile(s,'ee-prefetch-tests.py','exec'))
manifest={}
for label in ['run2-source','initial-reconstruction']:
 manifest[label]={f:hashlib.sha256((E/label/f).read_bytes()).hexdigest() for f in files}
manifest['initial-bench-worker.mjs']=hashlib.sha256(bench_worker).hexdigest()
manifest['reconstruction_scope']='initial-reconstruction executes preserved deterministic patch, contract and tests scripts from HEAD d323; initial benchmark exact SHA matches receipts; initial-regression full files reconstructed from same actual scripts. run2-source is byte-exact full copy of pre-late snapshot.'
assert manifest['run2-source']==json.loads((E/'pre-late-source-snapshot.json').read_text())['files']
(E/'attempt-source-sha256.json').write_text(json.dumps(manifest,indent=2))
D=E/'tooling';D.mkdir(exist_ok=True)
for file in ['ee-prefetch-patch.py','ee-prefetch-contract.py','ee-prefetch-tests.py','ee-prefetch-fix.py','ee-reconstruct-freeze.py']:
 (D/file).write_bytes((Path('/tmp')/file).read_bytes())
