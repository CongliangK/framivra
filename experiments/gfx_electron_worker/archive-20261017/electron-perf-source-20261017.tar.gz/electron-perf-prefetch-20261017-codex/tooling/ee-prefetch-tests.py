from pathlib import Path
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra')
p=T/'experiments/gfx_electron_worker/navigation_worker.mjs';s=p.read_text();s=s.replace("if (JSON.stringify(job.scheduling)!==JSON.stringify(scheduling))", "if (!job.scheduling || Object.keys(job.scheduling).length!==Object.keys(scheduling).length || Object.entries(scheduling).some(([k,v]) => job.scheduling[k]!==v))")
# Absolute monotonic bounds on gate and readiness checkpoints as well.
s=s.replace('errorGate = await installPageErrorGate(wc, pageErrors, fail);','errorGate = await deadline(installPageErrorGate(wc, pageErrors, fail), remaining(), \'error_gate\');')
s=s.replace('    await checkPageErrors();','    await deadline(checkPageErrors(), remaining(), \'page_checkpoint\');')
s=s.replace('    decoder.begin(f,generation);','    decoder.begin(f,generation);\n    const captureStarted=performance.now();')
s=s.replace('page_error_fence_passed:true,png_decode_count:6,elapsed_ms:', 'page_error_fence_passed:true,png_decode_count:6,prefetch_age_ms:captureStarted-start,elapsed_ms:')
p.write_text(s)
p=T/'vtx/gfx_electron.py';s=p.read_text().replace('and raw.get("live_documents") == 0 and raw.get("capture_inflight") == 0)', 'and type(raw.get("live_documents")) is int and raw["live_documents"] == 0\n            and type(raw.get("capture_inflight")) is int and raw["capture_inflight"] == 0)');p.write_text(s)
p=T/'tests/test_electron_integration.py';s=p.read_text();s=s.replace('from vtx import gfx_electron\n','');idx=s.index('import contextlib');s=s[:idx]+'from vtx import gfx_electron\n'+s[idx:];s=s.replace("cases = [\n            ('result.json'", "cases = [\n            ('result.json', lambda o: o.update(max_inflight=1)),\n            ('result.json', lambda o: o.update(max_capture_inflight=2)),\n            ('result.json', lambda o: o.update(prefetch_limit=True)),\n            ('result.json', lambda o: o.update(peak_live_documents=3)),\n            ('request.json', lambda o: o['scheduling'].update(max_inflight=1)),\n            ('result.json'");p.write_text(s)
p=T/'experiments/gfx_electron_worker/test_navigation.py';s=p.read_text();a=s.index('    def test_static_page_no_starvation_and_security(self):');s=s[:a]+'''    def test_prefetch_ordinary_failure_isolation_and_bounds(self):
        # Genuine rc0 first. Timed failures happen only in the ahead f1 document.
        base="<style>html{background:rgb(12,35,78)}</style><script>const f=+new URL(location).searchParams.get('f');"
        for kind,script in [
            ('resource', "setTimeout(()=>{new Image().src='missing-prefetch-resource.png'},180)"),
            ('throw', "setTimeout(()=>{throw Error('ahead-only-error')},180)"),
            ('promise', "setTimeout(()=>{Promise.reject(Error('ahead-only-promise'))},180)"),
            ('thirdchild', "const child=document.createElement('iframe');child.srcdoc='<script>setTimeout(()=>{throw Error(\\\"ahead-child\\\")},180)<\\\\/script>';document.body.append(child)")
        ]:
            with self.subTest(kind=kind):
                page=self.page(base+'if(f===1){/*CONTROL*/}</script><body></body>')
                control=self.render(page,frames=[0,1,2],n=3)
                self.assertEqual(control['exit_code'],0,control)
                self.assertEqual(control['failed'],[],control)
                page.write_text(base+'if(f===1){'+script+'}</script><body></body>')
                r=self.render(page,frames=[0,1,2],n=3)
                self.assertEqual(r['exit_code'],1,r)
                self.assertEqual(r['failed'],[1],r)
                raw=json.loads((Path(r['evidence_dir'])/'result.json').read_text())
                self.assertEqual([x['frame'] for x in raw['frames']],[0,2])
                self.assertEqual(raw['page_errors']['0'],[])
                self.assertEqual(raw['page_errors']['2'],[])
                self.assertLessEqual(raw['peak_live_documents'],2)
                self.assertEqual(raw['peak_capture_inflight'],1)
                self.assertEqual(raw['live_documents'],0)
                self.assertEqual(raw['capture_inflight'],0)
                self.assertEqual(raw['sessions_created'],3)

    def test_prefetch_timeout_keeps_absolute_whole_batch_budget(self):
        page=self.page("<style>html{background:rgb(12,35,78)}</style>")
        control=self.render(page,frames=[0,1],n=2,timeout_s=15)
        self.assertEqual(control['exit_code'],0,control)
        page.write_text("<style>html{background:rgb(12,35,78)}</style><script>if(+new URL(location).searchParams.get('f')===1)while(true){}</script>")
        started=time.monotonic()
        r=self.render(page,frames=[0,1],n=2,timeout_s=15)
        elapsed=time.monotonic()-started
        self.assertEqual(r['exit_code'],72,r)
        self.assertIn('timeout:frame',str(r['errors']))
        self.assertGreater(elapsed,14)
        self.assertLess(elapsed,18)
        # Crash policy invalidates adapter successes, but raw current f0 must
        # have published before the independent ahead document timed out.
        raw=json.loads((Path(r['evidence_dir'])/'result.json').read_text())
        self.assertEqual([x['frame'] for x in raw['frames']],[0])
        self.assertEqual(raw['failed'],[1])

'''+s[a:];p.write_text(s)
