from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex');T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra');OLD=Path('/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017')
for label,root in [('base',OLD),('refresh',T),('no_refresh',T)]:
 d=E/('diag-'+label);d.mkdir(exist_ok=True)
 for p in (root/'experiments/gfx_electron_worker').glob('*.mjs'):shutil.copyfile(p,d/p.name)
 p=d/'navigation_worker.mjs';s=p.read_text()
 if label=='no_refresh':
  a=s.index('    // A prepared OSR document');b=s.index('    const baselineImage',a);s=s[:a]+s[b:]
 s=s.replace("const baselinePending = decoder.decode(baselineImage.toPNG(),'baseline');", "const baselinePng=baselineImage.toPNG(); const baselinePending=decoder.decode(baselinePng,'baseline');")
 s=s.replace("if (!expected.equals(baseline)) throw Error('marker_side_effect_or_unstable_baseline');", "if (!expected.equals(baseline)) { for (const [k,v] of Object.entries({baseline,expected,baselinePng,ar,br,clean})) atomicWrite(path.join(job.out_dir,`diag-${f}-${k}.bin`),v); throw Error('marker_side_effect_or_unstable_baseline'); }")
 p.write_text(s)
script='''import os,json,importlib.util,hashlib
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as current
E=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('vtx.diagbase', OLD+'/vtx/gfx_electron.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
page=Path(T+'/experiments/gfx_electron_worker/pages/navigation_fixture.html')
rows=[]
for i in range(5):
 for label in ['base','no_refresh','refresh']:
  ee=base if label=='base' else current;ee.WORKER_DIR=E/('diag-'+label)
  ctx=SimpleNamespace(root=E,cache=E/'diag-cache',out=E/'diag-out')
  st=ee.render_page(page,E/f'diag-runs/{i}/{label}',4,width=192,height=96,frames=[3,0,2],ctx=ctx,timeout_s=15)
  rows.append(dict(round=i,label=label,result=st));print(i,label,st['failed'],flush=True)
  (E/'diag-results.json').write_text(json.dumps(rows,indent=2))
'''.replace('OLD',repr(str(OLD))).replace('T+',repr(str(T))+'+')
(E/'diag_fixture.py').write_text(script)
