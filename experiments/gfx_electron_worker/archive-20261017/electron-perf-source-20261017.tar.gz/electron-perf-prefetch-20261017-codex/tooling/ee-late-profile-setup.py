from pathlib import Path
import shutil
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex');d=E/'diag-late-profile';shutil.copytree(E/'diag-after_witnesses',d)
p=d/'navigation_worker.mjs';s=p.read_text()
s=s.replace('  const start = performance.now();', '''  const start = performance.now();
  const trace=phase => fs.appendFileSync(path.join(job.out_dir,'profile-events.jsonl'),JSON.stringify({frame:f,generation,phase,ms:performance.now()})+'\\n');
  trace('context_start');''')
replacements=[
('  async function prepare() {',"  async function prepare() { trace('prepare_start');"),
('    await ready();\n  }',"    await ready(); trace('prepare_end');\n  }"),
('  async function capture(prefetch) {',"  async function capture(prefetch) { trace('capture_start');"),
('    const resourceEpoch = ses._vtxEpoch;',"    trace('promotion_ready');\n    const resourceEpoch = ses._vtxEpoch;"),
('    const baselineImage = await wc.capturePage();',"    trace('baseline_start');\n    const baselineImage = await wc.capturePage();"),
("    const a = await witness('a','a'); const b = await witness('b','b');", "    trace('baseline_submitted');\n    const a = await witness('a','a'); trace('a_end'); const b = await witness('b','b'); trace('b_end');"),
('    await delay(40);',"    trace('stable_wait_start'); await delay(40); trace('stable_wait_end');"),
("    const aa = await witness('a','aa');", "    const aa = await witness('a','aa'); trace('aa_end');"),
("    const bb = await witness('b','bb');", "    const bb = await witness('b','bb'); trace('bb_end');"),
('    const [baseline, ar, br, aar, bbr] = await Promise.all([baselinePending,a.rgba,b.rgba,aa.rgba,bb.rgba]);', "    trace('decode_join_start');\n    const [baseline, ar, br, aar, bbr] = await Promise.all([baselinePending,a.rgba,b.rgba,aa.rgba,bb.rgba]); trace('decode_join_end');"),
('    const rebuilt = nativeImage.createFromBitmap(clean,{width,height,scaleFactor:1});', "    trace('merge_end');\n    const rebuilt = nativeImage.createFromBitmap(clean,{width,height,scaleFactor:1});"),
("    if (!(await decoder.decode(png,'final')).equals(expected)) throw Error('native_png_semantics_mismatch');", "    trace('final_decode_start'); const finalRgba=await decoder.decode(png,'final'); trace('final_decode_end');\n    if (!finalRgba.equals(expected)) throw Error('native_png_semantics_mismatch');"),
('    decoder.assertComplete();', "    trace('final_fence_end'); decoder.assertComplete();"),
('    atomicWrite(out,png);', "    atomicWrite(out,png); trace('published');"),
('    clearTimeout(watchdog);',"    clearTimeout(watchdog); trace('closed');")]
for old,new in replacements:
 assert old in s,old;s=s.replace(old,new)
p.write_text(s)
s=(E/'late_bench.py').read_text();idx=s.index('rows=[]');s=s[:idx]+'''ee=candidate_ee;ee.WORKER_DIR=E/'diag-late-profile'
page=SRC/'open_source_card.html';st=ee.render_page(page,E/'late-profile-output',91,width=1920,height=1080,frames=FRAMES,ctx=c,timeout_s=15)
(E/'late-profile-summary.json').write_text(json.dumps(st,indent=2))
assert st['exit_code']==0 and not st['failed'],st
'''
(E/'late_profile.py').write_text(s)
