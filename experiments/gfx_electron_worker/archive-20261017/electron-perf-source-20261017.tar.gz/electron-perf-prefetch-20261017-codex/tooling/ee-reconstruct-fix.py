from pathlib import Path
import subprocess,json,hashlib
real=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra');evidence=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
files=json.loads((evidence/'pre-late-source-snapshot.json').read_text())['files']
for f,digest in files.items():
 src=evidence/'run2-source'/f
 assert hashlib.sha256(src.read_bytes()).hexdigest()==digest
 (real/f).write_bytes(src.read_bytes())
recon=evidence/'initial-reconstruction'
for f in files:
 p=recon/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','HEAD:'+f],cwd=real))
for name in ['ee-prefetch-patch.py','ee-prefetch-contract.py']:
 script=(Path('/tmp')/name).read_text().replace(str(real),str(recon));exec(compile(script,name,'exec'),{'__builtins__':__builtins__})
worker=(recon/'experiments/gfx_electron_worker/navigation_worker.mjs').read_bytes()
expected=next(r['worker_hashes']['navigation_worker.mjs'] for r in json.loads((evidence/'initial-native-results.json').read_text()) if r['backend']=='new')
assert hashlib.sha256(worker).hexdigest()==expected
(evidence/'initial-bench-worker.mjs').write_bytes(worker)
script=Path('/tmp/ee-prefetch-tests.py').read_text().replace(str(real),str(recon));exec(compile(script,'ee-prefetch-tests.py','exec'),{'__builtins__':__builtins__})
manifest={label:{f:hashlib.sha256((evidence/label/f).read_bytes()).hexdigest() for f in files} for label in ['run2-source','initial-reconstruction']}
manifest['initial-bench-worker.mjs']=expected
manifest['scope']='initial benchmark exact recorded worker SHA; initial-regression source reproduced by preserved deterministic actual edit scripts from d323; run2 full files match pre-late-source-snapshot exactly.'
(evidence/'attempt-source-sha256.json').write_text(json.dumps(manifest,indent=2))
d=evidence/'tooling';d.mkdir(exist_ok=True)
for name in ['ee-prefetch-patch.py','ee-prefetch-contract.py','ee-prefetch-tests.py','ee-prefetch-fix.py','ee-reconstruct-freeze.py','ee-reconstruct-fix.py']:(d/name).write_bytes((Path('/tmp')/name).read_bytes())
assert all(hashlib.sha256((real/f).read_bytes()).hexdigest()==h for f,h in files.items())
print('RESTORED_AND_FROZEN_EXACT')
