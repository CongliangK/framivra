from pathlib import Path
T=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra')
p=T/'vtx/gfx_electron.py';s=p.read_text();s=s.replace('PAGE_ERROR_GATE = "cdp-html-unhandled-exceptions/2"','''PAGE_ERROR_GATE = "cdp-html-unhandled-exceptions/2"
SCHEDULING = {"max_inflight": 2, "max_live_documents": 2,
              "max_capture_inflight": 1, "prefetch_limit": 1,
              "decoder_threads": 1, "max_pending_decodes": 6}


def valid_schedule(raw):
    return (all(type(raw.get(k)) is int and raw[k] == v for k, v in SCHEDULING.items())
            and type(raw.get("peak_live_documents")) is int
            and 0 <= raw["peak_live_documents"] <= 2
            and type(raw.get("peak_capture_inflight")) is int
            and 0 <= raw["peak_capture_inflight"] <= 1
            and raw.get("live_documents") == 0 and raw.get("capture_inflight") == 0)
''')
s=s.replace('"source_sha256": hashlib.sha256(page.read_bytes()).hexdigest()}', '"source_sha256": hashlib.sha256(page.read_bytes()).hexdigest(),\n            "scheduling": dict(SCHEDULING)}')
s=s.replace('"vtx.electron.navigation/1"','"vtx.electron.navigation/2"').replace('and raw.get("requested_backend") == "electron"','and valid_schedule(raw)\n                 and raw.get("requested_backend") == "electron"')
s=s.replace('"mode": "N", "raster_mode": mode, "max_inflight": 1}', '"mode": "N", "raster_mode": mode, **SCHEDULING}')
p.write_text(s)
p=T/'vtx/gfx_electron_stage.py';s=p.read_text();print(s[:1200]);s=s.replace('"vtx.electron.navigation/1"','"vtx.electron.navigation/2"').replace('or raw.get("max_inflight") != 1','or not valid_schedule(raw)');s=s.replace('from .gfx_electron import ', 'from .gfx_electron import valid_schedule, ');p.write_text(s)
p=T/'experiments/gfx_electron_worker/navigation_worker.mjs';s=p.read_text().replace('const { width, height, frames, timeout_ms: timeoutMs, run_id: runId } = job;', '''const { width, height, frames, timeout_ms: timeoutMs, run_id: runId } = job;
const scheduling={max_inflight:2,max_live_documents:2,max_capture_inflight:1,prefetch_limit:1,decoder_threads:1,max_pending_decodes:6};
if (JSON.stringify(job.scheduling)!==JSON.stringify(scheduling)) throw Error('invalid scheduling');''');p.write_text(s)
# Existing direct worker tests need explicit request schedule.
p=T/'experiments/gfx_electron_worker/test_navigation.py';s=p.read_text();s=s.replace('from vtx.', 'from vtx.',1);p.write_text(s)
p=T/'tests/test_electron_integration.py';s=p.read_text().replace("schema='vtx.electron.navigation/1'", "schema='vtx.electron.navigation/2'").replace('frames=receipts, max_inflight=1, shared_memory=False,','frames=receipts, **gfx_electron.SCHEDULING, shared_memory=False,\n                   peak_live_documents=2, peak_capture_inflight=1, live_documents=0, capture_inflight=0,');s=s.replace("source_sha256=hashlib.sha256(Path(html).read_bytes()).hexdigest())", "source_sha256=hashlib.sha256(Path(html).read_bytes()).hexdigest(), scheduling=dict(gfx_electron.SCHEDULING))");
# module imports check below
if 'from vtx import gfx_electron\n' not in s:s='from vtx import gfx_electron\n'+s
p.write_text(s)
