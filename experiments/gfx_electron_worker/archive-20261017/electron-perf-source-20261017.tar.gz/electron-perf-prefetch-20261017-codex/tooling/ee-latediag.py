from pathlib import Path
import shutil,json,hashlib
E=Path('/home/liangruochong/文档/04_bilibili视频/_alpha-evidence-20261016/electron-perf-prefetch-20261017-codex')
d=E/'diag-after_witnesses';shutil.copytree(E/'diag-no_refresh',d)
p=d/'navigation_worker.mjs';s=p.read_text().replace('async function capture() {','async function capture(prefetch) {')
s=s.replace("    const bb = await witness('b','bb');", "    const bb = await witness('b','bb');\n    prefetch?.();")
s=s.replace('      if (i+1<frames.length) next=create(frames[i+1]);\n      result.frames.push(await current.capture());', '      result.frames.push(await current.capture(() => { if (i+1<frames.length) next=create(frames[i+1]); }));')
p.write_text(s)
s=(E/'diag_fixture.py').read_text().replace('range(5)','range(12)').replace("['base','no_refresh','refresh']", "['base','no_refresh','after_witnesses']").replace("f'diag-runs/{i}/{label}'", "f'diag-late-runs/{i}/{label}'").replace("E/'diag-results.json'", "E/'diag-late-results.json'")
# Verify successes against the matching real base pixels, never just receipt rc.
s=s.replace("(E/'diag-late-results.json').write_text(json.dumps(rows,indent=2))", "(E/'diag-late-results.json').write_text(json.dumps(rows,indent=2))\n  if label!='base':\n   from PIL import Image\n   for f in [3,0,2]:\n    a=E/f'diag-late-runs/{i}/base/f{f:04d}.png';b=E/f'diag-late-runs/{i}/{label}/f{f:04d}.png'\n    if b.exists(): assert a.read_bytes()==b.read_bytes() and Image.open(a).convert('RGBA').tobytes()==Image.open(b).convert('RGBA').tobytes(),(i,label,f)")
(E/'diag_late.py').write_text(s)
# Snapshot every diagnostic source; initial runtime failure remains frozen too.
rows={str(p.relative_to(E)):hashlib.sha256(p.read_bytes()).hexdigest() for p in E.glob('diag-*/*.mjs')}
(E/'diagnostic-copy-sha256.json').write_text(json.dumps(rows,indent=2))
