# EE-PERF-3: bounded document prefetch — HOLD / NOT ACCEPTED

Task ID EE-PERF-3. Base `d32310853d6136f3f621a356b0c2718c7fab1a25`; managed worktree `/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra`. No add/commit/reset/checkout/stash/branch/push, original HTML/timeline/fonts/style/audio edits, full-film restart, PR update, or merge. Current source is the **failed run2 implementation**, frozen for review, and MUST NOT be integrated. Late after-witnesses exists only as an evidence copy, not an accepted implementation.

## Implemented candidate and explicit limits

Five modified files: worker runtime/tests, Python adapter and completion reader, integration tests. create context → isolated session/window/document preparation → promotion readiness recheck → exclusive baseline/nonce/decode capture → close/drain. It prepares only one next document, never reuses document/navigation, preserves six native PNG encodes/full RGBA decodes, four nonce paints, baseline veto, Promise/child page gates, 40ms/100ms/15s thresholds. Decoder begin occurs only in current's ordered turn; failed pre-capture generations get explicit empty begin/drain to retain generation continuity.

Schema `/2` and caller `scheduling` explicitly bind max_inflight=2, max_live_documents=2, max_capture_inflight=1, prefetch_limit=1, decoder_threads=1, max_pending_decodes=6. Adapter validates declared values/type and in-flight range, completion reader requires live/capture zero. Observed peak counters were 2 documents/1 capture. These are runtime counters, not independent native enumeration. Unique nonpersistent session per generation isolates resource pending/errors/epoch and CDP error gate. `sessions_created` is lifetime created count; native retained session count and complete-tree RSS are UNKNOWN because 450 acceptance was explicitly deferred after correctness failure.

Deadline uses monotonic time from before context creation; promotion does not reset it. Each bounded prep await uses remaining time, and the original whole-batch watchdog exits 72 on 15s deadline, including a timed-out ahead document. A timed_out latch prevents teardown reentrancy from overriding 72 with final app.exit(1). Ordinary prep error closes only its context, is recorded in ordered turn, and does not contaminate current page errors/resources. There is no new await from final page/resource fence to atomic PNG publication.

## Initial exploratory native AB/BA (early prefetch)

Same three read-only original experimental HTMLs, f30/60/90, 1920×1080, b0/PAGES1/15s, two AB/BA rounds = 36 frames. New cold profile/output per invocation, no cached result reuse. Actual binary SHA is pinned by run.py to `433b343850ed9087fdb6548c48e1bb30011a87210cc3609f7b03061a7ac36c4f`. rootRO/private PID+net+dev/physical tmp/X11 socket RO/only this E writable. Actual argv/environment in `*.command.json`. HOME was not repurposed; XDG_CONFIG_HOME/XDG_CACHE_HOME point into this E.

| Page | d323-equivalent base fps | Early candidate fps | Speedup |
|---|---:|---:|---:|
| nav_two_pillars | 1.928 | 2.489 | 1.291× |
| open_source_card | 1.683 | 2.059 | 1.224× |
| u2_backends | 2.096 | 2.390 | 1.140× |

18 pairs PNG bytes and full decoded RGBA identical. `initial-native-results.json` preserves child/self user/system CPU separately; CPU figures are observed rusage, not whole-tree CPU. This is a failed early design's exploratory performance sample, **not an accepted final benchmark or evidence for late prefetch**. Current identity is not allowed to reuse older cache. No fresh CEF sample was taken; historical CEF is not asserted as contemporary.

## Real transparent regression and causal controls

Initial regression: 48 tests / 48.002s / rc1 / 7 failures / 0 skips. Real bugs included skipped decoder generation after prep failure and watchdog teardown overriding exit72. The first delayed-error fixture was too late for fast 192×96 capture, and one child fixture tried document.body before it existed. All failures remain. Run2 corrected those issues: 48 / 51.985s / rc1 / 2 failures / 0 skips. Remaining failures are the existing transparent navigation fixture and real 1s all/QC path, both baseline-veto rejection. It is NOT a functional pass.

Evidence-only copies preserve actual baseline PNG/full RGBA and native-witness-derived ar/br/expected/clean buffers on rejection; no baseline is used to recover output. A representative failure has 18,021 changed pixels, bbox x0..191/y1..94: baseline RGBA [199,100,40,128] became witness RGBA [227,177,147,255], exactly compatible with white compositing; formerly alpha0 pixels became opaque white. **White compositing is observed; native compositor root cause is NOT proven.**

Same unmodified transparent navigation fixture f3/0/2 in separate cold invocations:

| Group | Base | Early no refresh | Early extra unmarked refresh | Explicit native transparent background | After all four witness PNGs |
|---|---|---|---|---|---|
| Initial 5 repeats | 0/15 failed | 2/15 failed | 0/15 failed | — | — |
| Further 12 repeats | 0/36 failed | — | 4/36 failed | 3/36 failed | — |
| Late causal 12 repeats | 0/36 failed | 4/36 failed | — | — | 0/36 failed |

Extra unmarked refresh and explicit BrowserWindow backgroundColor=#00000000 are rejected as reliable fixes. The late evidence copy starts next context only after bb's fourth nonce native PNG is already captured, before joining five decodes and reconstructing/final-decode/publish. It omits the extra refresh. All 36 late PNGs exactly match base bytes and full RGBA; successfully published early diagnostic outputs also match their own base controls (93 earlier + late comparison file). Twelve repeats are limited evidence, not proof over arbitrary content or real fractional pages. Remaining capture overlap is only decode join/reconstruction/final decode/fence/write, so original early gains cannot be carried over. The late 1080p benchmark/profile scripts are prepared but **unrun**, per controller restriction to the causal group and transfer of the native window to the next experiment.

## Regression scope and missing acceptance

Run2 passed existing marker-sideeffect/JS/Promise/three-child, genuine whole-batch 15s=72, parent liveness/SIGKILL cleanup, caller source/config/tamper checks and per-frame ordinary error recovery. New ordinary error tests genuine rc0-control first, then missing resource/JS throw/Promise/child error confined to f1 with f0/f2 receipts. These delayed injections used 1080p for reliable duration, but exact injection-vs-capture timestamps were not independently recorded; the new fixture has one child while prior gate tests cover three children. Do not claim fully witnessed late third-child isolation coverage.

Not completed/NOT PASS: 450-frame batch, native retained sessions/full-tree RSS/CPU, final 36-frame late performance, real original fractional alpha +128 late acceptance, fresh CEF, frozen final regression, final identity release/cache admission, independent review, full-film or PR merge. Controller explicitly deferred long validation until a minimal correct late design shows worthwhile gain. This report stops at the requested causal group. Current production source remains failed/HOLD.

## Stable sources, command exits, and cleanup

`run2-source/` contains all five complete source files and matches pre-late-source-snapshot byte-for-byte. `initial-reconstruction/` is complete initial-regression source rebuilt deterministically from d323 and the preserved actual edit scripts. `initial-bench-worker.mjs` matches the exact SHA recorded by the original benchmark. `attempt-source-sha256.json`, `source-sha256.json`, `pre-late.diff`, and `candidate.diff` pin them and all diagnostic modules/scripts. No candidate runtime source changed during any native or regression invocation.

Evidence reconstruction itself first failed because exec reused a script variable and reran the contract editor on the current worktree while this task held no native job. It was immediately restored from complete run2-source and all five hashes reverified; that failure and corrected script are preserved. An initial host unittest command named a nonexistent class (rc1), followed by two correct module invocations (rc0, 13 pass/2 native opt-in skips); these are not final native regressions.

Every native invocation has a collected `*.exit.json`, log, command argv/environment; aggregate `command-exit-ledger.json`. Native run exits: initial_bench=0, regression_initial=1, regression_run2=1, diag_fixture=0, diag_bg=0, diag_late=0. No failed attempt or output was removed. `cleanup-check.json` records no matching live native processes/profiles after the final group. Native timing window has been released to controller. No background job remains.
