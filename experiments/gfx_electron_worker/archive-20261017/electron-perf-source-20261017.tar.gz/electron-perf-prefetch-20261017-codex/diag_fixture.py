import os,json,importlib.util,hashlib
from pathlib import Path
from types import SimpleNamespace
from vtx import gfx_electron as current
E=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('vtx.diagbase', '/home/liangruochong/文档/01_活跃项目/framivra/.agents/worktrees/alpha-electron-pipeline-20261017'+'/vtx/gfx_electron.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
page=Path('/home/liangruochong/.codex/worktrees/electron-prefetch-perf/framivra'+'/experiments/gfx_electron_worker/pages/navigation_fixture.html')
rows=[]
for i in range(5):
 for label in ['base','no_refresh','refresh']:
  ee=base if label=='base' else current;ee.WORKER_DIR=E/('diag-'+label)
  ctx=SimpleNamespace(root=E,cache=E/'diag-cache',out=E/'diag-out')
  st=ee.render_page(page,E/f'diag-runs/{i}/{label}',4,width=192,height=96,frames=[3,0,2],ctx=ctx,timeout_s=15)
  rows.append(dict(round=i,label=label,result=st));print(i,label,st['failed'],flush=True)
  (E/'diag-results.json').write_text(json.dumps(rows,indent=2))
